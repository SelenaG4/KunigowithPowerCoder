alter table public.services
  add column if not exists eligibility_notes text,
  add column if not exists cost_notes text,
  add column if not exists external_ref text,
  add column if not exists has_flyer boolean;

create or replace function public.check_eligibility(p_service_id uuid, p_profile jsonb)
returns table (eligible boolean, unknown boolean, reasons text[])
language sql stable set search_path = public as $$
  with rules as (
    select r.*, p_profile ->> r.rule_type::text as person_value
    from public.eligibility_rules r
    where r.service_id = p_service_id
  ), matched as (
    select r.*,
      person_value is not null and (
        lower(person_value) = lower(value)
        or (rule_type = 'place_of_residence'
          and lower(value) = 'canton_of_lucerne'
          and lower(person_value) = 'city_of_lucerne')
      ) as hit
    from rules r
  ), excl as (
    select explanation from matched where condition = 'excludes' and hit
  ), req as (
    select rule_type,
      bool_or(hit) as ok,
      max(person_value) is null as missing,
      string_agg(distinct explanation, ' / ') as explanation
    from matched where condition = 'requires' group by rule_type
  )
  select
    not exists (select 1 from excl)
      and not exists (select 1 from req where not missing and not ok) as eligible,
    exists (select 1 from req where missing)
      or exists (select 1 from matched where condition = 'excludes' and person_value is null) as unknown,
    coalesce(array(
      select explanation from excl
      union all select explanation from req where not missing and not ok
      union all select explanation from matched where person_value is null
    ), '{}') as reasons;
$$;

create type public.import_batch_status as enum ('staged', 'partly_published', 'published', 'discarded');
create type public.import_row_status as enum ('section', 'note', 'ready', 'needs_review', 'approved', 'duplicate', 'skipped', 'published');

create table public.import_column_aliases (
  alias text primary key,
  target_field text not null check (target_field in (
    'section', 'external_ref', 'coverage_text', 'organisation_name', 'service_name',
    'description', 'contact_text', 'website', 'has_flyer', 'eligibility_text',
    'cost_text', 'opening_hours', 'address', 'postal_city'
  ))
);
grant select, insert, update, delete on public.import_column_aliases to authenticated;
grant all on public.import_column_aliases to service_role;

insert into public.import_column_aliases (alias, target_field) values
  ('Art des Angebots', 'section'), ('Kategorie', 'section'), ('Bereich', 'section'), ('Rubrik', 'section'),
  ('Nr.', 'external_ref'), ('Nr', 'external_ref'), ('Nummer', 'external_ref'), ('ID', 'external_ref'),
  ('Ort/Zuständigkeit', 'coverage_text'), ('Zuständigkeit', 'coverage_text'), ('Ort', 'coverage_text'),
  ('Region', 'coverage_text'), ('Gebiet', 'coverage_text'), ('Einzugsgebiet', 'coverage_text'),
  ('Name', 'organisation_name'), ('Organisation', 'organisation_name'), ('Institution', 'organisation_name'),
  ('Anbieter', 'organisation_name'), ('Stelle', 'organisation_name'), ('Organisation / Institution', 'organisation_name'),
  ('Angebot', 'service_name'), ('Angebotsname', 'service_name'), ('Dienstleistung', 'service_name'),
  ('Kurzbeschreibung', 'description'), ('Beschreibung', 'description'), ('Thema', 'description'), ('Inhalt', 'description'),
  ('Kontakt', 'contact_text'), ('Kontakt/Website', 'contact_text'), ('Kontaktangaben', 'contact_text'),
  ('Telefon', 'contact_text'), ('E-Mail', 'contact_text'),
  ('Internet', 'website'), ('Website', 'website'), ('Webseite', 'website'), ('Homepage', 'website'),
  ('Link', 'website'), ('URL', 'website'), ('Flyer', 'has_flyer'),
  ('Voraussetzung', 'eligibility_text'), ('Voraussetzungen', 'eligibility_text'), ('Zielgruppe', 'eligibility_text'),
  ('Für wen', 'eligibility_text'), ('Zugang', 'eligibility_text'),
  ('Kosten', 'cost_text'), ('Preis', 'cost_text'), ('Gebühr', 'cost_text'),
  ('Öffnungszeiten / Zeiten Angebot', 'opening_hours'), ('Öffnungszeiten', 'opening_hours'),
  ('Zeiten', 'opening_hours'), ('Sprechzeiten', 'opening_hours'),
  ('Postadresse', 'address'), ('Adresse', 'address'), ('Strasse', 'address'),
  ('PLZ', 'postal_city'), ('PLZ/Ort', 'postal_city'), ('PLZ Ort', 'postal_city');

create table public.import_category_mappings (
  source_label text primary key,
  category_slug text not null references public.categories (slug) on update cascade on delete cascade
);
grant select, insert, update, delete on public.import_category_mappings to authenticated;
grant all on public.import_category_mappings to service_role;
create index import_category_mappings_cat_idx on public.import_category_mappings (category_slug);

insert into public.import_category_mappings (source_label, category_slug) values
  ('Allgemeine Hilfsangebote', 'counselling'), ('Sozialberatung', 'counselling'),
  ('Kirchliche Sozialberatung', 'counselling'), ('Sozial- und Rechtsberatung', 'counselling'),
  ('Rechtsberatung', 'counselling'), ('Sozialberatung Asyl', 'counselling'),
  ('Integrationsberatung', 'counselling'), ('Lese- und Schreibdienst', 'counselling'),
  ('Spezialisierte Beratung', 'counselling'), ('Selbsthilfe', 'health'),
  ('Schuldenberatung', 'finances'), ('Übersetzungsbüro', 'counselling'),
  ('Ombudsstelle', 'counselling'), ('Ärzte', 'health'),
  ('Finanzierung Deutschkurse', 'german-courses'), ('Stiftung', 'finances'),
  ('Bildung, Deutsch lernen und Austausch/Treffen', 'german-courses'),
  ('Schreibdienste und Beratungsstellen', 'counselling'), ('Familie & Kinder', 'family'), ('Gewalt', 'counselling');

update public.categories set keywords = '{deutsch,german,deutschkurs,sprachkurs,sprachcafe,sprache,language}' where slug = 'german-courses';
update public.categories set keywords = keywords || '{religi,kultur,gemeinschaft,community,cafe,treff,begegnung,moschee,kirche,frauen,musik,chor,kunst,tanz}' where slug = 'community';
update public.categories set keywords = keywords || '{gewalt,opfer,schreibdienst,briefe,formular,ombuds,anlaufstelle,rechtsauskunft}' where slug = 'counselling';
update public.categories set keywords = keywords || '{eltern,jugend,mutter,vater,baby,spielgruppe,kesb}' where slug = 'family';
update public.categories set keywords = keywords || '{stellensuch,bewerbung,erwerbslos,arbeitslos,lebenslauf,selbstandig}' where slug = 'work';
update public.categories set keywords = keywords || '{sucht,psychisch,beeintrachtigung,behinderung,arzt,praxis}' where slug = 'health';
update public.categories set keywords = keywords || '{schulden,finanz,kultur-legi,kulturlegi,gutschein,stiftung}' where slug = 'finances';
update public.categories set keywords = keywords || '{migrationsamt,asyl,fluchtling,aufenthalt}' where slug = 'permits';

create table public.import_batches (
  id uuid primary key default gen_random_uuid(),
  file_name text not null,
  sheet_name text,
  storage_path text,
  header_row int,
  column_map jsonb not null default '{}'::jsonb,
  status public.import_batch_status not null default 'staged',
  source_id uuid references public.sources (id) on delete set null,
  uploaded_by uuid default auth.uid(),
  created_at timestamptz not null default now(),
  published_at timestamptz
);
grant select, insert, update, delete on public.import_batches to authenticated;
grant all on public.import_batches to service_role;
create index import_batches_source_idx on public.import_batches (source_id);
create index import_batches_uploaded_by_idx on public.import_batches (uploaded_by);

create table public.import_rows (
  id uuid primary key default gen_random_uuid(),
  batch_id uuid not null references public.import_batches (id) on delete cascade,
  row_number int not null,
  section text,
  raw jsonb not null,
  fields jsonb not null default '{}'::jsonb,
  parsed jsonb not null default '{}'::jsonb,
  status public.import_row_status not null default 'needs_review',
  issues text[] not null default '{}',
  organisation_id uuid references public.organisations (id) on delete set null,
  service_id uuid references public.services (id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (batch_id, row_number)
);
grant select, insert, update, delete on public.import_rows to authenticated;
grant all on public.import_rows to service_role;
create index import_rows_status_idx on public.import_rows (batch_id, status);
create index import_rows_org_idx on public.import_rows (organisation_id);
create index import_rows_service_idx on public.import_rows (service_id);
create trigger import_rows_updated_at before update on public.import_rows
  for each row execute function public.set_updated_at();
