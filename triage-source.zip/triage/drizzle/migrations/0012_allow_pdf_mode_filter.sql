CREATE OR REPLACE FUNCTION public.create_shared_guide(p_language text, p_filters jsonb, p_service_ids uuid[])
 RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
declare v_code text;
begin
  p_filters := (select coalesce(jsonb_object_agg(key, value), '{}'::jsonb)
    from jsonb_each(coalesce(p_filters, '{}'::jsonb))
    where key in ('residence_status', 'place_of_residence', 'citizenship', 'municipality',
      'social_assistance_provider', 'arrival_stage', 'age_group', 'categories', 'query', 'pdf_mode'));
  insert into public.shared_guides (language, filters, service_ids)
  values (coalesce(p_language, 'de'), p_filters, coalesce(p_service_ids[1:50], '{}'))
  returning code into v_code;
  return v_code;
end;
$function$;