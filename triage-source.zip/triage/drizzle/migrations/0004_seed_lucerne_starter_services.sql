insert into public.categories (slug, name, name_i18n, keywords, icon, sort_order) values
  ('registration', 'Anmeldung & Wohnsitz', '{"en":"Registration & residence","de":"Anmeldung & Wohnsitz"}', '{registration,anmeldung,wohnsitz,einwohnerdienste}', 'clipboard-check', 5),
  ('education', 'Studium & Bildung', '{"en":"Studies & education","de":"Studium & Bildung"}', '{education,studies,school,bildung,studium}', 'graduation-cap', 45)
on conflict (slug) do nothing;

insert into public.municipalities (municipality_name, canton, bfs_number) values
  ('Emmen', 'LU', 1024), ('Kriens', 'LU', 1059), ('Horw', 'LU', 1058),
  ('Ebikon', 'LU', 1054), ('Sursee', 'LU', 1088)
on conflict do nothing;

insert into public.sources (id, source_name, source_url, source_type, last_checked_at) values
  ('30000000-0000-4000-8000-000000000001', 'Triage starter examples', 'https://github.com/SelenaG4/KunigowithPowerCoder', 'partner_import', null)
on conflict (id) do nothing;

insert into public.organisations (id, name, description, website, organisation_type, verification_status) values
  ('10000000-0000-4000-8000-000000000001', 'ECAP Luzern', 'Language and integration courses in Lucerne.', 'https://www.ecap.ch/', 'association', 'verified'),
  ('10000000-0000-4000-8000-000000000002', 'Fachstelle fabia', 'Advice on work, qualifications and integration.', 'https://www.fabia-luzern.ch/', 'ngo', 'verified'),
  ('10000000-0000-4000-8000-000000000003', 'Einwohnerdienste Emmen', 'Municipal registration and residence services.', 'https://www.emmen.ch/', 'city_service', 'verified'),
  ('10000000-0000-4000-8000-000000000004', 'Caritas Luzern', 'Social, housing and financial counselling.', 'https://www.caritas-luzern.ch/', 'ngo', 'verified'),
  ('10000000-0000-4000-8000-000000000005', 'Sentitreff', 'Community, meeting and integration activities.', 'https://www.sentitreff.ch/', 'association', 'verified'),
  ('10000000-0000-4000-8000-000000000006', 'Kanton Luzern', 'Cantonal information and public services.', 'https://www.lu.ch/', 'cantonal_service', 'verified'),
  ('10000000-0000-4000-8000-000000000007', 'RAV Luzern', 'Regional employment services.', 'https://www.rav.lu.ch/', 'cantonal_service', 'verified'),
  ('10000000-0000-4000-8000-000000000008', 'Klubschule Migros Luzern', 'Courses for language, learning and leisure.', 'https://www.klubschule.ch/', 'private', 'verified'),
  ('10000000-0000-4000-8000-000000000009', 'Familienberatung Luzern', 'Counselling for parents, children and families.', 'https://www.lu.ch/', 'cantonal_service', 'verified'),
  ('10000000-0000-4000-8000-000000000010', 'Volkshochschule Luzern', 'Adult education and study guidance.', 'https://www.vhs-luzern.ch/', 'association', 'verified')
on conflict (id) do nothing;

insert into public.services (id, slug, organisation_id, name, short_description, full_description, category_id, direct_url, contact_details, cost_type, appointment_required, available_languages, geographical_coverage, service_status, source_id) values
  ('20000000-0000-4000-8000-000000000001', 'ecap-german-courses', '10000000-0000-4000-8000-000000000001', 'German courses in Lucerne', 'German courses for different levels, budgets and daily schedules.', 'Find beginner and advanced German courses, conversation practice and integration support. Ask ECAP which course and level fits your situation.', (select id from public.categories where slug='german-courses'), 'https://www.ecap.ch/', '{"address":"Lucerne","opening_hours":"Contact the course office for current course times"}', 'varies', true, '{de,en}', 'canton_of_lucerne', 'active', '30000000-0000-4000-8000-000000000001'),
  ('20000000-0000-4000-8000-000000000002', 'fabia-work-employment', '10000000-0000-4000-8000-000000000002', 'Work & employment advice', 'Job search support, qualification recognition and guidance on working in Switzerland.', 'Fachstelle fabia supports migrants with job applications, recognition of foreign qualifications and questions about working life.', (select id from public.categories where slug='work'), 'https://www.fabia-luzern.ch/', '{"address":"Lucerne"}', 'free', true, '{de,en}', 'canton_of_lucerne', 'active', '30000000-0000-4000-8000-000000000001'),
  ('20000000-0000-4000-8000-000000000003', 'emmen-residents-registration', '10000000-0000-4000-8000-000000000003', 'Register at the residents'' office', 'Register your arrival and residence with the Emmen residents'' office.', 'New Emmen residents contact the Einwohnerdienste to register, ask which documents are required and arrange the next steps.', (select id from public.categories where slug='registration'), 'https://www.emmen.ch/', '{"address":"Emmen"}', 'varies', true, '{de,en}', 'specific_municipalities', 'active', '30000000-0000-4000-8000-000000000001'),
  ('20000000-0000-4000-8000-000000000004', 'caritas-housing-advice', '10000000-0000-4000-8000-000000000004', 'Housing advice', 'Help with finding accommodation, rental questions and tenant rights.', 'Get independent guidance on housing searches, rental contracts, housing costs and difficulties with a tenancy.', (select id from public.categories where slug='housing'), 'https://www.caritas-luzern.ch/', '{"address":"Lucerne"}', 'free', true, '{de,en}', 'canton_of_lucerne', 'active', '30000000-0000-4000-8000-000000000001'),
  ('20000000-0000-4000-8000-000000000005', 'lucerne-health-insurance-reduction', '10000000-0000-4000-8000-000000000006', 'Health insurance premium reduction', 'Check whether you can receive support with compulsory health insurance premiums.', 'The canton provides information about premium reductions, eligibility and the documents needed for an application.', (select id from public.categories where slug='health-insurance'), 'https://www.lu.ch/', '{"address":"Canton of Lucerne"}', 'free', false, '{de,en}', 'canton_of_lucerne', 'active', '30000000-0000-4000-8000-000000000001'),
  ('20000000-0000-4000-8000-000000000006', 'sentitreff-community-meetups', '10000000-0000-4000-8000-000000000005', 'Community & neighbourhood meetings', 'Meet people, join neighbourhood activities and practise German informally.', 'Sentitreff offers welcoming meeting places and activities that make it easier to build local connections.', (select id from public.categories where slug='community'), 'https://www.sentitreff.ch/', '{"address":"Lucerne"}', 'free', false, '{de,en}', 'city_of_lucerne', 'active', '30000000-0000-4000-8000-000000000001'),
  ('20000000-0000-4000-8000-000000000007', 'rav-lucerne-job-support', '10000000-0000-4000-8000-000000000007', 'RAV job-search support', 'Personal employment advice and job-search support for eligible residents.', 'The regional employment centre advises registered jobseekers on applications, employment programmes and next steps.', (select id from public.categories where slug='work'), 'https://www.rav.lu.ch/', '{"address":"Lucerne"}', 'free', true, '{de,en}', 'canton_of_lucerne', 'active', '30000000-0000-4000-8000-000000000001'),
  ('20000000-0000-4000-8000-000000000008', 'klubschule-language-courses', '10000000-0000-4000-8000-000000000008', 'Flexible language courses', 'Daytime and evening language courses at different levels.', 'Compare current language courses, schedules and prices and choose a course that fits your availability.', (select id from public.categories where slug='german-courses'), 'https://www.klubschule.ch/', '{"address":"Lucerne"}', 'paid', true, '{de,en}', 'canton_of_lucerne', 'active', '30000000-0000-4000-8000-000000000001'),
  ('20000000-0000-4000-8000-000000000009', 'family-children-counselling', '10000000-0000-4000-8000-000000000009', 'Family & children counselling', 'Confidential guidance for parents and families on everyday challenges.', 'Families can ask about parenting, schooling, childcare and local support options and receive help finding the right service.', (select id from public.categories where slug='family'), 'https://www.lu.ch/', '{"address":"Lucerne"}', 'free', true, '{de,en}', 'canton_of_lucerne', 'active', '30000000-0000-4000-8000-000000000001'),
  ('20000000-0000-4000-8000-000000000010', 'adult-education-guidance', '10000000-0000-4000-8000-000000000010', 'Studies & adult education guidance', 'Explore courses, further education and study options in the Lucerne region.', 'Get an overview of adult education, basic skills and continuing education opportunities and find a suitable learning path.', (select id from public.categories where slug='education'), 'https://www.vhs-luzern.ch/', '{"address":"Lucerne"}', 'varies', false, '{de,en}', 'canton_of_lucerne', 'active', '30000000-0000-4000-8000-000000000001'),
  ('20000000-0000-4000-8000-000000000011', 'caritas-social-financial-help', '10000000-0000-4000-8000-000000000004', 'Social support & financial advice', 'Confidential help with budgeting, debt, benefits and difficult life situations.', 'Caritas offers social counselling and helps people understand available financial support and referral options.', (select id from public.categories where slug='finances'), 'https://www.caritas-luzern.ch/', '{"address":"Lucerne"}', 'free', true, '{de,en}', 'canton_of_lucerne', 'active', '30000000-0000-4000-8000-000000000001')
on conflict (id) do nothing;

insert into public.translations (service_id, language, translated_name, translated_short_description, translated_description, translation_status) values
  ('20000000-0000-4000-8000-000000000001', 'de', 'Deutschkurse in Luzern', 'Deutschkurse für verschiedene Niveaus, Budgets und Tageszeiten.', 'Finden Sie Anfänger- und Fortgeschrittenenkurse, Konversationsangebote und Integrationsunterstützung.', 'published'),
  ('20000000-0000-4000-8000-000000000002', 'de', 'Beratung Arbeit & Beruf', 'Unterstützung bei der Stellensuche, Anerkennung von Diplomen und Arbeitsfragen.', 'Die Fachstelle fabia unterstützt Migrantinnen und Migranten bei Bewerbungen, Diplomanerkennung und Fragen zum Arbeitsleben.', 'published'),
  ('20000000-0000-4000-8000-000000000003', 'de', 'Anmeldung beim Einwohneramt', 'Melden Sie Ihren Wohnsitz bei den Einwohnerdiensten Emmen an.', 'Neue Einwohnerinnen und Einwohner erfahren, welche Dokumente sie für die Anmeldung benötigen.', 'published'),
  ('20000000-0000-4000-8000-000000000004', 'de', 'Wohnberatung', 'Hilfe bei der Wohnungssuche, Mietfragen und Mieterrechten.', 'Unabhängige Beratung zu Wohnungssuche, Mietvertrag, Wohnkosten und Problemen im Mietverhältnis.', 'published'),
  ('20000000-0000-4000-8000-000000000005', 'de', 'Prämienverbilligung Krankenkasse', 'Prüfen Sie, ob Sie Unterstützung bei den Krankenkassenprämien erhalten können.', 'Informationen zu Prämienverbilligung, Voraussetzungen und den nötigen Dokumenten.', 'published'),
  ('20000000-0000-4000-8000-000000000006', 'de', 'Begegnung & Nachbarschaft', 'Menschen treffen, Aktivitäten im Quartier und informell Deutsch üben.', 'Sentitreff bietet offene Treffpunkte und Aktivitäten für neue lokale Kontakte.', 'published'),
  ('20000000-0000-4000-8000-000000000007', 'de', 'RAV Unterstützung bei der Stellensuche', 'Persönliche Beratung und Unterstützung für berechtigte Stellensuchende.', 'Das regionale Arbeitsvermittlungszentrum berät zu Bewerbungen, Programmen und nächsten Schritten.', 'published'),
  ('20000000-0000-4000-8000-000000000008', 'de', 'Flexible Sprachkurse', 'Sprachkurse am Tag und am Abend auf verschiedenen Niveaus.', 'Vergleichen Sie aktuelle Sprachkurse, Kurszeiten und Preise.', 'published'),
  ('20000000-0000-4000-8000-000000000009', 'de', 'Beratung Familie & Kinder', 'Vertrauliche Beratung für Eltern und Familien im Alltag.', 'Beratung zu Erziehung, Schule, Kinderbetreuung und passenden Angeboten.', 'published'),
  ('20000000-0000-4000-8000-000000000010', 'de', 'Beratung Studium & Weiterbildung', 'Entdecken Sie Kurse und Weiterbildungsmöglichkeiten in der Region Luzern.', 'Überblick über Erwachsenenbildung, Grundkompetenzen und Weiterbildung.', 'published'),
  ('20000000-0000-4000-8000-000000000011', 'de', 'Soziale & finanzielle Beratung', 'Vertrauliche Hilfe bei Budget, Schulden, Sozialhilfe und schwierigen Lebenssituationen.', 'Caritas berät zu finanzieller Unterstützung und passenden Anlaufstellen.', 'published')
on conflict (service_id, language) do nothing;

insert into public.eligibility_rules (service_id, rule_type, condition, value, explanation) values
  ('20000000-0000-4000-8000-000000000002', 'social_assistance_provider', 'excludes', 'daf', 'Not available for people receiving social assistance from DAF. Please contact your DAF advisor.'),
  ('20000000-0000-4000-8000-000000000003', 'municipality', 'requires', 'emmen', 'This registration service is for residents of Emmen.'),
  ('20000000-0000-4000-8000-000000000005', 'place_of_residence', 'requires', 'canton_of_lucerne', 'You must live in the Canton of Lucerne.'),
  ('20000000-0000-4000-8000-000000000007', 'residence_status', 'requires', 'B', 'RAV registration depends on your residence status.'),
  ('20000000-0000-4000-8000-000000000007', 'residence_status', 'requires', 'C', 'RAV registration depends on your residence status.')
on conflict do nothing;

insert into public.service_municipalities (service_id, municipality_id)
select '20000000-0000-4000-8000-000000000003', id from public.municipalities where municipality_name='Emmen' and canton='LU'
on conflict do nothing;

create or replace function public.create_shared_guide(p_language text, p_filters jsonb, p_service_ids uuid[])
returns text language plpgsql security definer set search_path = public as $$
declare v_code text;
begin
  p_filters := (select coalesce(jsonb_object_agg(key, value), '{}'::jsonb)
    from jsonb_each(coalesce(p_filters, '{}'::jsonb))
    where key in ('residence_status', 'place_of_residence', 'citizenship', 'municipality',
      'social_assistance_provider', 'arrival_stage', 'age_group', 'categories', 'query'));
  insert into public.shared_guides (language, filters, service_ids)
  values (coalesce(p_language, 'de'), p_filters, coalesce(p_service_ids[1:50], '{}'))
  returning code into v_code;
  return v_code;
end;
$$;
