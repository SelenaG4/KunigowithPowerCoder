create or replace function private.import_parse_eligibility(t text, out rules jsonb, out issues text[])
language plpgsql stable as $$
declare
  n text := private.norm(t);
  v_open boolean;
  v_family boolean;
  v_cap text;
  v_letters text[];
  v_cond text;
  v_tok text[];
  v_place text;
  r jsonb := '[]'::jsonb;
  iss text[] := '{}';
begin
  rules := '[]'::jsonb; issues := '{}';
  if n is null then return; end if;

  v_open := n ~ '^(keine|fur alle|offen fur alle|alle\M)';
  v_family := n ~ '(famil|eltern)';

  v_cap := coalesce(
    substring(n from '(?:ausweis|status|aufenthaltsbewilligung(?:en)?|aufenthaltsstatus|bewilligung(?:en)?)\s*((?:\m[bcflnsg]\M(?:-?fl\.?)?\s*(?:,|/|und|oder)?\s*)+)'),
    substring(n from '((?:\m[bcflnsg]\M-?\s*(?:,|/|und|oder)?\s*)+)-?status'));
  if v_cap is not null then
    v_letters := array(select distinct upper(m[1]) from regexp_matches(v_cap, '\m([bcflnsg])\M', 'g') m order by 1);
    if array_length(v_letters, 1) > 0 then
      v_cond := case when n ~ '(keine personen|ausgeschlossen|nicht fur|nicht offen)[^.]{0,40}(ausweis|status|bewillig)'
        then 'excludes' else 'requires' end;
      select r || jsonb_agg(jsonb_build_object(
        'rule_type', 'residence_status', 'condition', v_cond, 'value', l,
        'explanation', case when v_cond = 'excludes'
          then 'Nicht für Personen mit Ausweis ' || array_to_string(v_letters, ', ')
          else 'Nur für Personen mit Ausweis ' || array_to_string(v_letters, ', ') end))
        into r from unnest(v_letters) l;
      if v_cond = 'excludes' or n ~ '\d+ jahr' or n ~ '\mch\M' then
        iss := iss || ('review: check residence-permit rule (' || v_cond || ' ' || array_to_string(v_letters, ', ') || ')');
      end if;
    end if;
  end if;

  v_cap := substring(n from '(?:wohnsitz|wohnhaft|einwohner\w*|bewohner\w*|aus dem)\s*(?:in|im|der|des|von|dem)?\s*(?:der|dem|den)?\s*([^.(!|;]+)');
  if v_cap is not null then
    v_cap := regexp_replace(v_cap, '\m(mehr|siehe|genugend|deren|die|mit|ausgeschlossen|keine|vorprufung|wahrend)\M.*$', '');
    v_cap := regexp_replace(v_cap, '\m(kirchgemeinden?|gemeinden?|bezirk|stadt|einwohner\w*|bewohner\w*|der|dem|den|des)\M', '', 'g');
    v_cap := trim(regexp_replace(regexp_replace(v_cap, '\s+', ' ', 'g'), '^(und|in|im|,)\s*', ''));
    v_cap := trim(both ' ,' from v_cap);
    if v_cap ~ '^kanton\s*(luzern)?$' then
      v_place := 'canton_of_lucerne';
    elsif v_cap ~ '^kanton' then
      iss := iss || ('info: residence in several cantons ("' || left(t, 80) || '")');
    elsif v_cap ~ '^(luzern|stadtluzern|stadluzern)$' and n ~ '(stadt ?luzern|stadluzern)' then
      v_place := 'city_of_lucerne';
    else
      v_tok := array(
        select distinct case when trim(x) in ('stadtluzern', 'stadluzern') then 'luzern' else trim(x) end
        from regexp_split_to_table(v_cap, '\s*(,|/|\mund\M)\s*') x
        where trim(x) ~ '^[a-z][a-z .-]{1,30}$' and trim(x) !~ '\m(personen|alle|menschen)\M');
      if array_length(v_tok, 1) > 0 then
        select r || jsonb_agg(jsonb_build_object(
          'rule_type', 'municipality', 'condition', 'requires', 'value', m,
          'explanation', 'Nur für Personen mit Wohnsitz in: ' || array_to_string(array(select initcap(x) from unnest(v_tok) x), ', ')))
          into r from unnest(v_tok) m;
        if array_length(v_tok, 1) > 1 or v_tok = '{luzern}'
          or exists (select 1 from unnest(v_tok) x where x !~ '^[a-z]+( [a-z]+)?$') then
          iss := iss || ('review: check municipality list (' || array_to_string(v_tok, ', ') || ')');
        end if;
      end if;
    end if;
    if v_place is not null then
      r := r || jsonb_build_array(jsonb_build_object(
        'rule_type', 'place_of_residence', 'condition', 'requires', 'value', v_place,
        'explanation', case v_place when 'city_of_lucerne' then 'Nur für Personen mit Wohnsitz in der Stadt Luzern'
          else 'Nur für Personen mit Wohnsitz im Kanton Luzern' end));
    end if;
  end if;

  if not v_family then
    if n ~ '\m(frauen|migrantinnen|schwangere)\M' and n !~ '\m(manner|vater)\M' and n !~ 'alle religionen|frauen und manner' then
      r := r || jsonb_build_array(jsonb_build_object('rule_type', 'gender', 'condition', 'requires',
        'value', 'female', 'explanation', 'Angebot für Frauen'));
    elsif n ~ '\m(manner|vater)\M' and n !~ '\mfrauen\M' then
      r := r || jsonb_build_array(jsonb_build_object('rule_type', 'gender', 'condition', 'requires',
        'value', 'male', 'explanation', 'Angebot für Männer'));
    end if;
  end if;

  if not v_family and n !~ 'vor dem ahv' then
    if n ~ '(ab 18|altersjahr 18|\merwachsene|volljahrig)' and n !~ 'kinder' then
      r := r || jsonb_build_array(jsonb_build_object('rule_type', 'age_group', 'condition', 'requires',
        'value', 'adult', 'explanation', 'Nur für Erwachsene (ab 18)'));
    elsif n ~ '(^fur kinder|^kinder\M|kinder ab|kinder und jugendliche)' then
      r := r || jsonb_build_array(jsonb_build_object('rule_type', 'age_group', 'condition', 'requires',
        'value', 'child', 'explanation', 'Angebot für Kinder'));
    elsif n ~ '(ab 60|senior|altere menschen|ab ahv)' then
      r := r || jsonb_build_array(jsonb_build_object('rule_type', 'age_group', 'condition', 'requires',
        'value', 'senior', 'explanation', 'Angebot für ältere Menschen'));
    end if;
  end if;

  if n ~ '(ohne (gultige )?aufenthalts|sans.?papiers|ohne aufenthaltsrecht)' then
    r := r || jsonb_build_array(jsonb_build_object('rule_type', 'residence_status', 'condition', 'requires',
      'value', 'none', 'explanation', 'Für Menschen ohne gültige Aufenthaltsbewilligung'));
  end if;

  if n ~ '(werden an (die )?daf verwiesen|nicht fur personen.*daf)' then
    r := r || jsonb_build_array(jsonb_build_object('rule_type', 'social_assistance_provider', 'condition', 'excludes',
      'value', 'daf', 'explanation', 'Nicht für Personen, die von der DAF betreut werden (Verweis an DAF)'));
    iss := iss || 'review: check DAF exclusion'::text;
  elsif n ~ '(uber die dienststelle asyl|zuweisung durch sozialdienst des daf|betreut sind)' then
    r := r || jsonb_build_array(jsonb_build_object('rule_type', 'social_assistance_provider', 'condition', 'requires',
      'value', 'daf', 'explanation', 'Nur für Personen, die von der DAF betreut werden'));
    iss := iss || 'review: check DAF requirement'::text;
  end if;
  if n ~ '(ohne wsh|ohne (wirtschaftliche )?sozialhilfe)' then
    r := r || jsonb_build_array(jsonb_build_object('rule_type', 'social_assistance_provider', 'condition', 'excludes',
      'value', 'municipal', 'explanation', 'Nicht für Personen mit wirtschaftlicher Sozialhilfe der Gemeinde'));
    iss := iss || 'review: check social-assistance exclusion'::text;
  end if;

  if n ~ '(ausgeschlossen|ausgenommen|keine personen|nicht fur)' and not exists (
    select 1 from jsonb_array_elements(r) e where e->>'condition' = 'excludes') then
    iss := iss || 'review: text mentions an exclusion that is not a rule yet'::text;
  end if;
  if n ~ 'mitgliedschaft' then iss := iss || 'info: membership required'::text; end if;
  if jsonb_array_length(r) = 0 and not v_open then iss := iss || 'info: target group kept as text only'::text; end if;

  rules := r; issues := iss;
end;
$$;

create or replace function private.import_guess_category(
  p_section text, p_text text, out category_slug text, out extra_slugs text[])
language plpgsql stable set search_path = public as $$
declare
  n text := private.norm(concat_ws(' ', p_section, p_text));
begin
  select m.category_slug into category_slug
  from public.import_category_mappings m
  where private.norm(m.source_label) = private.norm(p_section);

  extra_slugs := array(
    select c.slug from public.categories c
    cross join lateral (
      select coalesce(sum(length(private.norm(k))), 0) as hits from unnest(c.keywords) k
      where n like '%' || private.norm(k) || '%'
    ) s
    where s.hits > 0
    order by s.hits desc, c.sort_order
  );
  if category_slug is null then category_slug := extra_slugs[1]; end if;
  extra_slugs := array(select x from unnest(extra_slugs) x where x is distinct from category_slug limit 2);
end;
$$;
