create or replace function public.import_publish_batch(p_batch_id uuid, p_activate boolean default false)
returns jsonb language plpgsql set search_path = public as $$
declare
  b public.import_batches;
  r record;
  v_org uuid;
  v_svc uuid;
  v_cat uuid;
  v_muni uuid;
  v_slug text;
  v_name text;
  v_orgs_created int := 0;
  v_services int := 0;
  v_rules int := 0;
  x text;
  rule jsonb;
begin
  perform private.assert_admin();

  select * into b from public.import_batches where id = p_batch_id for update;
  if b.id is null then raise exception 'Import batch % not found', p_batch_id; end if;

  if b.source_id is null then
    insert into public.sources (source_name, source_type, import_date, last_checked_at)
    values (b.file_name, 'partner_import', now(), now())
    returning id into b.source_id;
    update public.import_batches set source_id = b.source_id where id = b.id;
  end if;

  for r in
    select * from public.import_rows
    where batch_id = p_batch_id and status in ('ready', 'approved')
    order by row_number
  loop
    v_name := r.parsed ->> 'organisation_name';
    if v_name is null then continue; end if;

    select id into v_org from public.organisations
    where private.norm(name) = private.norm(v_name) limit 1;
    if v_org is null then
      insert into public.organisations (name, website, address, phone, email, organisation_type, verification_status)
      values (v_name, r.parsed ->> 'website', r.parsed ->> 'address',
        r.parsed -> 'phones' ->> 0, r.parsed -> 'emails' ->> 0,
        case when private.norm(v_name) ~ '(stadt luzern|gemeinde|sozialdienst [a-z]+$)' then 'city_service'
          when private.norm(v_name) ~ '(kanton|dienststelle|\mdaf\M|amt fur)' then 'cantonal_service'
          when private.norm(v_name) ~ '(kirch|pfarr|pastoral|seelsorge|moschee|dzemat)' then 'church'
          when private.norm(v_name) ~ '(verein|association)' then 'association'
          else 'other' end::public.organisation_type,
        'verified')
      returning id into v_org;
      v_orgs_created := v_orgs_created + 1;
    end if;

    select id into v_cat from public.categories where slug = r.parsed ->> 'category_slug';
    v_slug := private.slugify(r.parsed ->> 'service_name') || '-' || left(md5(r.id::text), 6);

    insert into public.services (
      slug, organisation_id, name, short_description, full_description, category_id,
      direct_url, contact_details, cost_type, appointment_required, available_languages,
      geographical_coverage, service_status, source_id, eligibility_notes, cost_notes,
      external_ref, has_flyer)
    values (
      v_slug, v_org, r.parsed ->> 'service_name', r.parsed ->> 'short_description',
      r.parsed ->> 'full_description', v_cat, r.parsed ->> 'website',
      jsonb_strip_nulls(jsonb_build_object(
        'phone', r.parsed -> 'phones' ->> 0, 'email', r.parsed -> 'emails' ->> 0,
        'phones', r.parsed -> 'phones', 'emails', r.parsed -> 'emails',
        'address', r.parsed ->> 'address', 'opening_hours', r.parsed ->> 'opening_hours')),
      coalesce((r.parsed ->> 'cost_type')::public.cost_type, 'varies'),
      coalesce(private.norm(concat_ws(' ', r.parsed ->> 'short_description', r.parsed ->> 'opening_hours'))
        ~ '(terminvereinbarung|voranmeldung|nach vereinbarung|anmeldung)', false),
      '{de}',
      coalesce((r.parsed ->> 'geographical_coverage')::public.geographical_coverage, 'canton_of_lucerne'),
      (case when p_activate then 'active' else 'draft' end)::public.service_status,
      b.source_id, r.parsed ->> 'eligibility_notes', r.parsed ->> 'cost_notes',
      r.parsed ->> 'external_ref', (r.parsed ->> 'has_flyer')::boolean)
    returning id into v_svc;
    v_services := v_services + 1;

    insert into public.service_categories (service_id, category_id)
    select v_svc, c.id from public.categories c
    where c.slug in (select jsonb_array_elements_text(coalesce(r.parsed -> 'extra_category_slugs', '[]')))
      and c.id is distinct from v_cat
    on conflict do nothing;

    for x in select jsonb_array_elements_text(coalesce(r.parsed -> 'municipalities', '[]')) loop
      select id into v_muni from public.municipalities where private.norm(municipality_name) = private.norm(x) limit 1;
      if v_muni is null then
        insert into public.municipalities (municipality_name, canton) values (initcap(x), 'LU')
        on conflict (municipality_name, canton) do update set municipality_name = excluded.municipality_name
        returning id into v_muni;
      end if;
      insert into public.service_municipalities (service_id, municipality_id) values (v_svc, v_muni)
      on conflict do nothing;
      v_muni := null;
    end loop;

    for rule in select jsonb_array_elements(coalesce(r.parsed -> 'rules', '[]')) loop
      insert into public.eligibility_rules (service_id, rule_type, condition, value, explanation, source_id, verified_at)
      values (v_svc, (rule ->> 'rule_type')::public.eligibility_rule_type,
        (rule ->> 'condition')::public.eligibility_condition,
        rule ->> 'value', rule ->> 'explanation', b.source_id,
        case when r.status = 'approved' then now() end)
      on conflict do nothing;
      v_rules := v_rules + 1;
    end loop;

    update public.import_rows set status = 'published', organisation_id = v_org, service_id = v_svc
    where id = r.id;
    v_org := null; v_cat := null;
  end loop;

  update public.import_batches set
    status = case when exists (select 1 from public.import_rows
      where batch_id = p_batch_id and status in ('ready', 'approved', 'needs_review'))
      then 'partly_published' else 'published' end::public.import_batch_status,
    published_at = now()
  where id = p_batch_id;

  return jsonb_build_object(
    'services_created', v_services,
    'organisations_created', v_orgs_created,
    'rules_created', v_rules,
    'still_needs_review', (select count(*) from public.import_rows
      where batch_id = p_batch_id and status = 'needs_review'),
    'service_status', case when p_activate then 'active' else 'draft' end);
end;
$$;

revoke execute on function public.import_publish_batch(uuid, boolean) from public, anon;
grant execute on function public.import_publish_batch(uuid, boolean) to authenticated;

revoke all on public.import_column_aliases from public, anon;
revoke all on public.import_category_mappings from public, anon;
revoke all on public.import_batches from public, anon;
revoke all on public.import_rows from public, anon;

alter table public.import_column_aliases enable row level security;
alter table public.import_category_mappings enable row level security;
alter table public.import_batches enable row level security;
alter table public.import_rows enable row level security;

create policy "admins manage column aliases" on public.import_column_aliases for all to authenticated using (private.is_admin()) with check (private.is_admin());
create policy "admins manage category mappings" on public.import_category_mappings for all to authenticated using (private.is_admin()) with check (private.is_admin());
create policy "admins manage import batches" on public.import_batches for all to authenticated using (private.is_admin()) with check (private.is_admin());
create policy "admins manage import rows" on public.import_rows for all to authenticated using (private.is_admin()) with check (private.is_admin());

grant usage on schema private to authenticated;
grant execute on all functions in schema private to authenticated;
revoke execute on all functions in schema private from anon;
grant execute on function private.is_admin() to anon;

create policy "admins read imports" on storage.objects for select to authenticated using (bucket_id = 'imports' and private.is_admin());
create policy "admins upload imports" on storage.objects for insert to authenticated with check (bucket_id = 'imports' and private.is_admin());
create policy "admins delete imports" on storage.objects for delete to authenticated using (bucket_id = 'imports' and private.is_admin());
