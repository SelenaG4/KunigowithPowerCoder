create or replace function public.import_stage_sheet(
  p_file_name text,
  p_sheet_name text,
  p_rows jsonb,
  p_storage_path text default null
)
returns uuid language plpgsql set search_path = public as $$
declare
  v_batch uuid;
  v_header int;
  v_best int := 0;
  v_hits int;
  v_map jsonb := '{}'::jsonb;
  v_headers text[];
  v_field text;
  v_cell text;
  v_row jsonb;
  v_raw jsonb;
  v_fields jsonb;
  v_section text;
  v_nonempty int;
  v_prev uuid;
  v_only text;
  v_ncols int;
  i int; j int;
begin
  perform private.assert_admin();

  if jsonb_typeof(p_rows) <> 'array' or jsonb_array_length(p_rows) = 0 then
    raise exception 'p_rows must be a non-empty array of rows';
  end if;

  for i in 0 .. least(jsonb_array_length(p_rows), 15) - 1 loop
    select count(distinct a.target_field) into v_hits
    from jsonb_array_elements_text(p_rows -> i) e(v)
    join public.import_column_aliases a on private.norm(a.alias) = private.norm(e.v);
    if v_hits > v_best then v_best := v_hits; v_header := i; end if;
  end loop;
  if v_best < 3 then
    raise exception 'No header row found. Add your column names to import_column_aliases (e.g. Name, Kontakt, Website).';
  end if;

  v_ncols := (select max(jsonb_array_length(x)) from jsonb_array_elements(p_rows) x);
  for j in 0 .. v_ncols - 1 loop
    v_cell := nullif(trim(p_rows -> v_header ->> j), '');
    v_headers[j + 1] := coalesce(v_cell, 'col_' || (j + 1));
    select a.target_field into v_field
    from public.import_column_aliases a where private.norm(a.alias) = private.norm(v_cell) limit 1;
    if v_field is not null and not exists (select 1 from jsonb_each_text(v_map) e where e.value = v_field) then
      v_map := v_map || jsonb_build_object(j::text, v_field);
    end if;
    v_field := null;
  end loop;
  if not exists (select 1 from jsonb_each_text(v_map) e where e.value = 'section')
    and nullif(trim(p_rows -> v_header ->> 0), '') is null then
    v_map := v_map || jsonb_build_object('0', 'section');
  end if;

  insert into public.import_batches (file_name, sheet_name, storage_path, header_row, column_map)
  values (p_file_name, p_sheet_name, p_storage_path, v_header + 1, v_map)
  returning id into v_batch;

  for i in v_header + 1 .. jsonb_array_length(p_rows) - 1 loop
    v_row := p_rows -> i;
    v_raw := '{}'::jsonb; v_fields := '{}'::jsonb; v_nonempty := 0; v_only := null;

    for j in 0 .. jsonb_array_length(v_row) - 1 loop
      v_cell := nullif(trim(v_row ->> j), '');
      if v_cell is not null then
        v_nonempty := v_nonempty + 1;
        v_only := v_cell;
        v_raw := v_raw || jsonb_build_object(coalesce(v_headers[j + 1], 'col_' || (j + 1)), v_cell);
        if v_map ? j::text then
          v_fields := v_fields || jsonb_build_object(v_map ->> j::text, v_cell);
        end if;
      end if;
    end loop;

    continue when v_nonempty = 0;

    if v_fields ? 'section' then
      v_section := private.clean(v_fields ->> 'section', ' ');
      if v_nonempty = 1 then
        insert into public.import_rows (batch_id, row_number, section, raw, fields, status)
        values (v_batch, i + 1, v_section, v_raw, v_fields, 'section');
        continue;
      end if;
    end if;

    if v_prev is not null and (v_nonempty = 1 or (
      v_nonempty <= 2 and not (v_fields ? 'organisation_name' or v_fields ? 'service_name'))) then
      update public.import_rows
      set fields = jsonb_set(fields, '{notes}', to_jsonb(concat_ws(E'\n', fields ->> 'notes',
        (select string_agg(value, ' ') from jsonb_each_text(v_raw)))))
      where id = v_prev;
      insert into public.import_rows (batch_id, row_number, section, raw, fields, status)
      values (v_batch, i + 1, v_section, v_raw, v_fields, 'note');
      continue;
    end if;

    insert into public.import_rows (batch_id, row_number, section, raw, fields, status)
    values (v_batch, i + 1, v_section, v_raw, v_fields, 'needs_review')
    returning id into v_prev;
  end loop;

  perform private.import_parse_batch(v_batch);
  return v_batch;
end;
$$;

create or replace function public.import_reparse_batch(p_batch_id uuid)
returns void language plpgsql set search_path = public as $$
begin
  perform private.assert_admin();
  perform private.import_parse_batch(p_batch_id);
end;
$$;

create or replace function public.import_batch_summary(p_batch_id uuid)
returns jsonb language sql stable set search_path = public as $$
  select jsonb_build_object(
    'batch', to_jsonb(b) - 'column_map',
    'column_map', b.column_map,
    'counts', (select jsonb_object_agg(status, n) from (
      select status, count(*) n from public.import_rows where batch_id = b.id group by status) s),
    'top_issues', (select jsonb_agg(x) from (
      select regexp_replace(i, ' \(.*$|"[^"]*"', '') as issue, count(*) as n
      from public.import_rows, unnest(issues) i
      where batch_id = b.id and status in ('needs_review', 'ready')
      group by 1 order by 2 desc limit 10) x)
  )
  from public.import_batches b where b.id = p_batch_id;
$$;

revoke execute on function public.import_stage_sheet(text, text, jsonb, text) from public, anon;
revoke execute on function public.import_reparse_batch(uuid) from public, anon;
revoke execute on function public.import_batch_summary(uuid) from public, anon;
grant execute on function public.import_stage_sheet(text, text, jsonb, text) to authenticated;
grant execute on function public.import_reparse_batch(uuid) to authenticated;
grant execute on function public.import_batch_summary(uuid) to authenticated;
