create or replace function private.import_parse_row(p_fields jsonb, p_section text, out parsed jsonb, out issues text[])
language plpgsql stable set search_path = public as $$
declare
  f_org text := private.clean(p_fields->>'organisation_name', ' ');
  f_service text := private.clean(p_fields->>'service_name', ' ');
  f_desc text := private.clean(concat_ws(E'\n', p_fields->>'description', p_fields->>'notes'), ' ');
  f_contact text := p_fields->>'contact_text';
  f_web text := p_fields->>'website';
  f_addr text := p_fields->>'address';
  f_plz text := p_fields->>'postal_city';
  f_hours text := p_fields->>'opening_hours';
  f_elig text := private.clean(p_fields->>'eligibility_text', ' ');
  f_all text;
  v_cost record;
  v_cov record;
  v_elig record;
  v_cat record;
  v_urls text[];
  v_address text;
  iss text[] := '{}';
begin
  if f_org is null and f_service is not null then f_org := f_service; end if;
  if f_org is null then iss := iss || 'review: no organisation name'::text; end if;

  if f_hours ~* '(@|https?://|www\.)' then
    iss := iss || 'review: opening hours column contains contact data (columns shifted?)'::text;
  end if;
  if f_plz is not null and f_plz !~ '^\s*\d{4}' then
    iss := iss || ('review: postcode column looks wrong ("' || left(f_plz, 40) || '")');
  end if;

  f_all := concat_ws(E'\n', f_contact, f_web, f_addr, f_plz, f_hours);
  v_urls := private.extract_urls(concat_ws(E'\n', f_web, f_contact));
  if f_addr is not null and private.norm(f_addr) !~ '^(internetseite|siehe webs?ite|je nach( dem)?|-|–)$' and f_addr !~* '(https?://|www\.|@)' then
    v_address := concat_ws(', ', private.clean(f_addr), private.clean(f_plz));
  else
    v_address := private.extract_address(concat_ws(E'\n', f_contact, f_addr, f_plz));
  end if;
  if coalesce(array_length(v_urls, 1), 0) = 0
    and coalesce(array_length(private.extract_emails(f_all), 1), 0) = 0
    and coalesce(array_length(private.extract_phones(f_all), 1), 0) = 0 then
    iss := iss || 'review: no website, email or phone found'::text;
  end if;
  if f_web is not null and coalesce(array_length(private.extract_urls(f_web), 1), 0) = 0 then
    iss := iss || ('info: website column is not a link ("' || left(f_web, 40) || '")');
  end if;

  if p_fields ? 'cost_text' then
    select * into v_cost from private.import_parse_cost(p_fields->>'cost_text');
  else
    select * into v_cost from private.import_parse_cost(
      substring(private.norm(f_desc) from '(kostenlos|gratis|unentgeltlich|kostenpflichtig)'));
    v_cost.issue := null;
  end if;
  select * into v_cov from private.import_parse_coverage(p_fields->>'coverage_text');
  select * into v_elig from private.import_parse_eligibility(
    coalesce(f_elig, case when private.norm(f_desc) ~ '(voraussetzung|nur fur|wohnhaft in|ausgeschlossen)' then f_desc end));
  select * into v_cat from private.import_guess_category(p_section, concat_ws(' ', f_org, f_service, f_desc, f_elig));

  if p_fields->>'coverage_text' is null then
    if exists (select 1 from jsonb_array_elements(v_elig.rules) e
      where e->>'rule_type' = 'place_of_residence' and e->>'value' = 'city_of_lucerne') then
      v_cov.coverage := 'city_of_lucerne'; v_cov.issue := null;
    elsif exists (select 1 from jsonb_array_elements(v_elig.rules) e where e->>'rule_type' = 'municipality') then
      v_cov.coverage := 'specific_municipalities'; v_cov.issue := null;
      v_cov.municipalities := array(select initcap(e->>'value') from jsonb_array_elements(v_elig.rules) e
        where e->>'rule_type' = 'municipality');
    end if;
  end if;

  if v_cost.issue is not null then iss := iss || v_cost.issue; end if;
  if v_cov.issue is not null then iss := iss || v_cov.issue; end if;
  iss := iss || v_elig.issues;
  if v_cat.category_slug is null then iss := iss || 'review: no category found'::text; end if;

  parsed := jsonb_strip_nulls(jsonb_build_object(
    'organisation_name', f_org,
    'service_name', coalesce(f_service, f_org),
    'short_description', case when length(f_desc) > 280 then left(f_desc, 277) || '…' else f_desc end,
    'full_description', case when length(f_desc) > 280 then f_desc end,
    'category_slug', v_cat.category_slug,
    'extra_category_slugs', to_jsonb(v_cat.extra_slugs),
    'website', v_urls[1],
    'emails', to_jsonb(private.extract_emails(f_all)),
    'phones', to_jsonb(private.extract_phones(f_all)),
    'address', v_address,
    'opening_hours', private.clean(f_hours, '; '),
    'cost_type', v_cost.cost_type,
    'cost_notes', private.clean(p_fields->>'cost_text', ' '),
    'geographical_coverage', v_cov.coverage,
    'municipalities', to_jsonb(v_cov.municipalities),
    'eligibility_notes', f_elig,
    'rules', v_elig.rules,
    'has_flyer', case when private.norm(p_fields->>'has_flyer') ~ '^(ja|yes|x)' then true
      when private.norm(p_fields->>'has_flyer') ~ '^(nein|no)' then false end,
    'external_ref', private.clean(p_fields->>'external_ref', ' ')
  ));
  issues := iss;
end;
$$;

create or replace function private.import_parse_batch(p_batch_id uuid)
returns void language plpgsql set search_path = public as $$
declare
  r record;
  p record;
  v_seen text[] := '{}';
  v_key text;
  v_dup uuid;
begin
  for r in
    select * from public.import_rows
    where batch_id = p_batch_id and status in ('ready', 'needs_review', 'duplicate', 'skipped')
    order by row_number
  loop
    select * into p from private.import_parse_row(r.fields, r.section);

    if p.parsed->>'organisation_name' is null and p.parsed->>'short_description' is null
      and p.parsed->>'website' is null and coalesce(jsonb_array_length(p.parsed->'phones'), 0) = 0 then
      update public.import_rows set parsed = p.parsed, issues = p.issues, status = 'skipped' where id = r.id;
      continue;
    end if;

    v_key := coalesce(private.norm(p.parsed->>'organisation_name'), '') || '|' ||
      coalesce(private.norm(p.parsed->>'short_description'), '');
    if v_key = any (v_seen) then
      update public.import_rows set parsed = p.parsed,
        issues = p.issues || 'info: same offer appears earlier in this file'::text,
        status = 'duplicate' where id = r.id;
      continue;
    end if;
    v_seen := v_seen || v_key;

    select s.id into v_dup
    from public.services s join public.organisations o on o.id = s.organisation_id
    where private.norm(o.name) = private.norm(p.parsed->>'organisation_name')
      and coalesce(private.norm(s.short_description), '') = coalesce(private.norm(p.parsed->>'short_description'), '')
    limit 1;
    if v_dup is not null then
      update public.import_rows set parsed = p.parsed, service_id = v_dup,
        issues = p.issues || 'info: this offer already exists in the database'::text,
        status = 'duplicate' where id = r.id;
      continue;
    end if;

    update public.import_rows set
      parsed = p.parsed,
      issues = p.issues,
      status = case when exists (select 1 from unnest(p.issues) i where i like 'review:%')
        then 'needs_review' else 'ready' end::public.import_row_status
    where id = r.id;
  end loop;

  update public.import_rows ir set parsed = jsonb_set(ir.parsed, '{service_name}', to_jsonb(
    (ir.parsed->>'organisation_name') || ' – ' ||
    case when d.sections = d.n and ir.section is not null then ir.section
      else coalesce(left(split_part(ir.parsed->>'short_description', '.', 1), 60), ir.section) end))
  from (
    select private.norm(parsed->>'organisation_name') as org,
      count(*) as n, count(distinct section) as sections
    from public.import_rows
    where batch_id = p_batch_id and status in ('ready', 'needs_review')
    group by 1 having count(*) > 1
  ) d
  where ir.batch_id = p_batch_id
    and ir.status in ('ready', 'needs_review')
    and private.norm(ir.parsed->>'organisation_name') = d.org
    and ir.parsed->>'service_name' = ir.parsed->>'organisation_name';
end;
$$;
