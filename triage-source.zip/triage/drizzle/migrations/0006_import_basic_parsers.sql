create or replace function private.assert_admin()
returns void language plpgsql stable set search_path = public as $$
begin
  if not (private.is_admin() or current_user in ('postgres', 'service_role', 'supabase_admin')) then
    raise exception 'Only administrators can import data' using errcode = '42501';
  end if;
end;
$$;

create or replace function private.norm(t text)
returns text language sql stable set search_path = public, extensions as $$
  select nullif(trim(regexp_replace(lower(extensions.unaccent(coalesce(t, ''))), '\s+', ' ', 'g')), '');
$$;

create or replace function private.clean(t text, p_sep text default ', ')
returns text language sql immutable as $$
  select nullif(array_to_string(array(
    select trim(both from x) from regexp_split_to_table(coalesce(t, ''), '\s*\n\s*') x
    where trim(both from x) not in ('', '–', '-', '|')
  ), p_sep), '');
$$;

create or replace function private.slugify(t text)
returns text language sql stable set search_path = public, extensions as $$
  select left(trim(both '-' from regexp_replace(
    lower(extensions.unaccent(coalesce(t, ''))), '[^a-z0-9]+', '-', 'g')), 60);
$$;

create or replace function private.extract_emails(t text)
returns text[] language sql immutable as $$
  select coalesce(array_agg(distinct lower(m[1])), '{}')
  from regexp_matches(coalesce(t, ''), '([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,})', 'g') m;
$$;

create or replace function private.extract_urls(t text)
returns text[] language sql immutable as $$
  select coalesce(array_agg(u order by pos), '{}') from (
    select distinct on (u) u, pos from (
      select case when m[1] ~* '^https?://' then m[1] else 'https://' || m[1] end as u,
        row_number() over () as pos
      from regexp_matches(coalesce(t, ''),
        '((?:https?://|www\.)[^\s,;<>"]+|(?<![@A-Za-z0-9._-])[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.(?:ch|com|org|net|info|swiss|lu|de|it)(?:/[^\s,;<>"]*)?)', 'g') m
    ) x order by u, pos
  ) y;
$$;

create or replace function private.extract_phones(t text)
returns text[] language sql immutable as $$
  select coalesce(array_agg(distinct regexp_replace(trim(m[1]), '\s+', ' ', 'g')), '{}')
  from regexp_matches(coalesce(t, ''),
    '((?:\+41|0041)\s?(?:\(0\)\s?)?\d{2}\s?\d{3}\s?\d{2}\s?\d{2}|0800\s?\d{3}\s?\d{3}|0\d{2}[\s-]?\d{3}[\s-]?\d{2}[\s-]?\d{2})', 'g') m;
$$;

create or replace function private.extract_address(t text)
returns text language sql immutable as $$
  select nullif(concat_ws(', ',
    substring(coalesce(t, '') from '([A-ZÄÖÜ][A-Za-zÄÖÜäöüéèß.\- ]*(?:strasse|str\.|weg|platz|quai|gasse|hof|matte|halde|rain|ring|allee|graben|berg|zentrum)\s*\d+[A-Za-z]?)'),
    substring(coalesce(t, '') from '(\m\d{4}\s+[A-ZÄÖÜ][A-Za-zÄÖÜäöüéè.\-]+(?:\s[A-ZÄÖÜ0-9][A-Za-zÄÖÜäöüéè.\-]*)?)')
  ), '');
$$;

create or replace function private.import_parse_cost(t text, out cost_type public.cost_type, out issue text)
language plpgsql stable as $$
declare
  n text := private.norm(t);
  v_free boolean; v_paid boolean; v_member boolean; v_varies boolean;
begin
  if n is null then cost_type := null; issue := 'info: no cost information'; return; end if;
  v_free := n ~ '(kostenlos|gratis|unentgeltlich|\mfrei\M|^keine?\M)';
  v_paid := n ~ '(\d+\s*(chf|fr\.|\.-|-)|\mchf\M|kostenpflichtig|unkostenbeitrag|unkostenbetrag|preis)';
  v_member := n ~ 'mitglied';
  v_varies := n ~ '(je nach|einkommen|unterschiedlich|gutschein|reduziert|verschieden)';
  cost_type := case
    when v_free and not (v_paid or v_member or v_varies) then 'free'
    when v_free then 'varies'
    when v_varies or v_member then 'varies'
    when v_paid then 'paid'
    else 'varies' end::public.cost_type;
  if n ~ '\?' or not (v_free or v_paid or v_member or v_varies) then
    issue := 'review: cost unclear ("' || left(t, 60) || '")';
  end if;
end;
$$;

create or replace function private.import_parse_coverage(
  t text, out coverage public.geographical_coverage, out municipalities text[], out issue text)
language plpgsql stable as $$
declare
  n text := private.norm(t);
  tok text[];
begin
  municipalities := '{}';
  if n is null then coverage := 'canton_of_lucerne'; issue := 'info: area not given, assumed Canton of Lucerne'; return; end if;
  if n ~ 'online' then coverage := 'online';
  elsif n ~ '(zentralschweiz)' or (n ~ 'kanton' and n ~ '(nidwalden|obwalden|\mzug\M|\muri\M|schwyz)') then
    coverage := 'central_switzerland';
  elsif n ~ '^(stadt luzern|luzern)$' then coverage := 'city_of_lucerne';
  elsif n ~ '^kanton luzern$' then coverage := 'canton_of_lucerne';
  elsif n ~ 'kanton (zurich|bern|zug|aargau|basel|st\. ?gallen)' then
    coverage := 'switzerland'; issue := 'review: offer is based outside Lucerne ("' || t || '")';
  elsif n ~ 'schweiz' then coverage := 'switzerland';
  else
    tok := array(
      select initcap(trim(x)) from regexp_split_to_table(n, '\s*(,|/|\mund\M)\s*') x
      where trim(x) <> '' and trim(x) !~ '^(offen|region|bezirk)$'
    );
    if n ~ '\moffen\M' then
      coverage := 'canton_of_lucerne';
      issue := 'info: open to everyone, located in ' || array_to_string(tok, ', ');
    else
      coverage := 'specific_municipalities';
      municipalities := tok;
      issue := 'info: limited to ' || array_to_string(tok, ', ');
      if exists (select 1 from unnest(tok) x where private.norm(x) in ('bern', 'zurch', 'zurich', 'basel')) then
        issue := 'review: area includes places outside Lucerne ("' || t || '")';
      end if;
    end if;
  end if;
end;
$$;
