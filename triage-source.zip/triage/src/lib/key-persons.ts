import type { LanguageCode } from "./guide-types";

export type KeyPerson = {
  id: string;
  name: string;
  organisation: string;
  languages: LanguageCode[];
  bookingUrl: string;
  provider: "Cal.com" | "Microsoft Bookings" | "Zoom";
  videoBookingConfigured: boolean;
};

// Only add real, consented public contacts after their booking page has
// been configured to create a video meeting automatically.
export const KEY_PERSONS: readonly KeyPerson[] = [];

export function matchingKeyPersons(people: readonly KeyPerson[], language: LanguageCode) {
  return people.filter((person) => {
    if (!person.languages.includes(language) || !person.videoBookingConfigured) return false;
    try {
      const url = new URL(person.bookingUrl);
      return url.protocol === "https:" && !url.username && !url.password;
    } catch {
      return false;
    }
  });
}