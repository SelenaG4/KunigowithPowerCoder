import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";
import type { Database } from "@/integrations/supabase/types";
import type { Category, Service, ServiceDetail, ShareFilters } from "./guide-types";

function makePublicClient(url: string, key: string) {
  return createClient<Database>(url, key, {
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
    global: {
      fetch: (input, init) => {
        const headers = new Headers(init?.headers);
        if (key.startsWith("sb_") && headers.get("Authorization") === `Bearer ${key}`) {
          headers.delete("Authorization");
        }
        headers.set("apikey", key);
        return fetch(input, { ...init, headers });
      },
    },
  });
}

const searchSchema = z.object({
  query: z.string().trim().max(100).optional(),
  language: z.string().regex(/^[a-z]{2}$/).default("en"),
  category: z.string().trim().max(60).nullable().optional(),
  profile: z.record(z.string(), z.string()).default({}),
  onlyEligible: z.boolean().default(false),
  limit: z.number().int().min(1).max(50).default(50),
});

export type SearchInput = z.input<typeof searchSchema>;

export const getServices = createServerFn({ method: "GET" })
  .inputValidator((input: SearchInput) => searchSchema.parse(input))
  .handler(async ({ data }) => {
    const client = makePublicClient(process.env["SUPABASE_URL"]!, process.env["SUPABASE_PUBLISHABLE_KEY"]!);
    const { data: services, error } = await client.rpc("search_services", {
      ...(data.query ? { p_query: data.query } : {}),
      p_language: data.language,
      ...(data.category ? { p_category: data.category } : {}),
      p_profile: data.profile,
      p_only_eligible: data.onlyEligible,
      p_limit: data.limit,
      p_offset: 0,
    });
    if (error) {
      console.error("Service search failed", error.message);
      throw new Error("Services are temporarily unavailable. Please try again.");
    }
    return services as Service[];
  });

export const getCategories = createServerFn({ method: "GET" }).handler(async () => {
  const client = makePublicClient(process.env["SUPABASE_URL"]!, process.env["SUPABASE_PUBLISHABLE_KEY"]!);
  const { data, error } = await client
    .from("categories")
    .select("id, slug, name, name_i18n, icon, sort_order")
    .order("sort_order");
  if (error) {
    console.error("Category loading failed", error.message);
    throw new Error("Topics are temporarily unavailable.");
  }
  return data as unknown as Category[];
});

export const getServiceBySlug = createServerFn({ method: "GET" })
  .inputValidator((input: { slug: string; language?: string }) => z.object({ slug: z.string().regex(/^[a-z0-9-]+$/).max(100), language: z.string().regex(/^[a-z]{2}$/).default("en") }).parse(input))
  .handler(async ({ data }) => {
    const client = makePublicClient(process.env["SUPABASE_URL"]!, process.env["SUPABASE_PUBLISHABLE_KEY"]!);
    const { data: service, error } = await client
      .from("services")
      .select("id, slug, name, short_description, full_description, direct_url, contact_details, cost_type, appointment_required, available_languages, geographical_coverage, organisations!inner(name, website, address, phone, email), categories!services_category_id_fkey(slug, name, name_i18n), eligibility_rules(rule_type, condition, value, explanation)")
      .eq("slug", data.slug)
      .eq("service_status", "active")
      .maybeSingle();
    if (error) {
      console.error("Service detail failed", error.message);
      throw new Error("This service could not be loaded.");
    }
    if (!service || data.language === "de") return service as unknown as ServiceDetail | null;
    const { data: translation } = await client
      .from("translations")
      .select("translated_name, translated_short_description, translated_description")
      .eq("service_id", service.id)
      .eq("language", data.language)
      .maybeSingle();
    if (!translation) return service as unknown as ServiceDetail | null;
    return {
      ...service,
      name: translation.translated_name || service.name,
      short_description: translation.translated_short_description ?? service.short_description,
      full_description: translation.translated_description ?? (translation.translated_short_description ? null : service.full_description),
    } as unknown as ServiceDetail;
  });

const shareSchema = z.object({
  language: z.string().regex(/^[a-z]{2}$/),
  filters: z.record(z.string(), z.union([z.string(), z.array(z.string())])),
  serviceIds: z.array(z.string().uuid()).max(50),
});

export const createSharedGuide = createServerFn({ method: "POST" })
  .inputValidator((input: z.input<typeof shareSchema>) => shareSchema.parse(input))
  .handler(async ({ data }) => {
    const client = makePublicClient(process.env["SUPABASE_URL"]!, process.env["SUPABASE_PUBLISHABLE_KEY"]!);
    const { data: code, error } = await client.rpc("create_shared_guide", {
      p_language: data.language,
      p_filters: data.filters,
      p_service_ids: data.serviceIds,
    });
    if (error || !code) {
      console.error("Guide sharing failed", error?.message);
      throw new Error("The share link could not be created. Please try again.");
    }
    return { code };
  });

export const getSharedGuide = createServerFn({ method: "GET" })
  .inputValidator((input: { code: string }) => z.object({ code: z.string().regex(/^[a-f0-9]{8}$/) }).parse(input))
  .handler(async ({ data }) => {
    const client = makePublicClient(process.env["SUPABASE_URL"]!, process.env["SUPABASE_PUBLISHABLE_KEY"]!);
    const { data: guide, error } = await client
      .from("shared_guides")
      .select("code, language, filters, service_ids, created_at")
      .eq("code", data.code)
      .maybeSingle();
    if (error) {
      console.error("Shared guide loading failed", error.message);
      throw new Error("This shared guide could not be loaded.");
    }
    return guide as unknown as { code: string; language: string; filters: ShareFilters; service_ids: string[]; created_at: string } | null;
  });

const submissionSchema = z.object({
  organisationName: z.string().trim().min(2).max(160),
  serviceName: z.string().trim().min(2).max(160),
  description: z.string().trim().max(2000),
  categoryId: z.string().uuid().nullable(),
  website: z.union([z.literal(""), z.string().url().max(500)]),
  contact: z.string().trim().max(500),
  eligibilityNotes: z.string().trim().max(1500),
  languages: z.array(z.string().regex(/^[a-z]{2}$/)).max(12),
  submitterNote: z.string().trim().max(1000),
});

export type SubmissionInput = z.input<typeof submissionSchema>;

export const submitService = createServerFn({ method: "POST" })
  .inputValidator((input: SubmissionInput) => submissionSchema.parse(input))
  .handler(async ({ data }) => {
    const client = makePublicClient(process.env["SUPABASE_URL"]!, process.env["SUPABASE_PUBLISHABLE_KEY"]!);
    const { error } = await client.from("service_submissions").insert({
      organisation_name: data.organisationName,
      service_name: data.serviceName,
      description: data.description || null,
      category_id: data.categoryId,
      website: data.website || null,
      contact_details: { contact: data.contact },
      eligibility_notes: data.eligibilityNotes || null,
      languages: data.languages,
      submitter_note: data.submitterNote || null,
      status: "new",
    });
    if (error) {
      console.error("Service submission failed", error.message);
      throw new Error("Your suggestion could not be sent. Please check the form and try again.");
    }
    return { ok: true };
  });

