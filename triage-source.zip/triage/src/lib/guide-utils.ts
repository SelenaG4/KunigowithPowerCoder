import type { GuideProfile, SearchProfile, ShareFilters } from "./guide-types";

export function toSearchProfile(profile: GuideProfile): SearchProfile {
  const result: SearchProfile = {};

  if (profile.citizenship) result["citizenship"] = profile.citizenship;
  if (profile.municipality) {
    result["municipality"] = profile.municipality.toLowerCase();
    result["place_of_residence"] =
      profile.municipality === "Luzern" ? "city_of_lucerne" : "canton_of_lucerne";
  }
  if (profile.arrivalStage) result["arrival_stage"] = profile.arrivalStage;
  if (profile.permit && profile.permit !== "unsure") {
    result["residence_status"] = profile.permit;
  }

  return result;
}

export function shareableFilters(profile: GuideProfile): ShareFilters {
  return {
    ...toSearchProfile(profile),
    ...(profile.needs.length > 0 ? { categories: [...profile.needs] } : {}),
  };
}

export type ChecklistItem = {
  id: string;
  title: string;
  description: string;
  category: string;
};

export function buildChecklist(profile: GuideProfile): ChecklistItem[] {
  const items: ChecklistItem[] = [];
  const needs = new Set(profile.needs);

  if (needs.has("registration") || profile.arrivalStage === "just-arrived") {
    items.push({
      id: "register",
      title: `Register at the ${profile.municipality || "local"} residents' office`,
      description: "Ask which documents you need and arrange your registration appointment.",
      category: "registration",
    });
  }

  if (needs.has("health-insurance") || items.length > 0) {
    items.push({
      id: "health-insurance",
      title: "Arrange your health insurance (Krankenversicherung)",
      description: "Compare compulsory insurance and check whether premium support is available.",
      category: "health-insurance",
    });
  }

  if (profile.permit !== "none" && profile.arrivalStage !== "settled") {
    items.push({
      id: "permit",
      title: "Check your residence permit requirements",
      description: "Confirm your documents and the next steps for your residence status.",
      category: "permits",
    });
  }

  if (needs.has("german-courses")) {
    items.push({
      id: "german-course",
      title: "Find a German language course",
      description: "Compare levels, course times and prices, then ask for a placement assessment.",
      category: "german-courses",
    });
  }

  if (needs.has("work")) {
    items.push({
      id: "work",
      title: "Prepare your job-search documents",
      description: "Collect your CV, references and qualification documents for an advice appointment.",
      category: "work",
    });
  }

  if (needs.has("housing")) {
    items.push({
      id: "housing",
      title: "Explore housing support",
      description: "Save your housing documents and ask about tenancy and accommodation advice.",
      category: "housing",
    });
  }

  return items.slice(0, 6);
}

export function filtersFromSharedGuide(guide: { filters: ShareFilters; language: string }): GuideProfile {
  const language = /^[a-z]{2}$/.test(guide.language) ? guide.language : "en";
  return {
    language: language as GuideProfile["language"],
    citizenship: typeof guide.filters["citizenship"] === "string" ? guide.filters["citizenship"] : "",
    municipality: typeof guide.filters["municipality"] === "string" ? guide.filters["municipality"] : "",
    arrivalStage: typeof guide.filters["arrival_stage"] === "string" ? guide.filters["arrival_stage"] : "",
    permit: typeof guide.filters["residence_status"] === "string" ? guide.filters["residence_status"] : "",
    needs: Array.isArray(guide.filters["categories"])
      ? guide.filters["categories"].filter((item): item is string => typeof item === "string")
      : [],
  };
}

export function profileSummary(profile: GuideProfile) {
  return [
    profile.citizenship === "eu_efta"
      ? "EU citizen"
      : profile.citizenship === "non_eu_efta"
        ? "Non-EU citizen"
        : "Citizenship not specified",
    profile.arrivalStage === "just-arrived"
      ? "Just arrived"
      : profile.arrivalStage === "recent"
        ? "Moved recently"
        : profile.arrivalStage === "settled"
          ? "Already living here"
          : "Planning to move",
    profile.permit && profile.permit !== "unsure" ? `Permit ${profile.permit}` : "Permit not specified",
    profile.municipality ? `${profile.municipality} (LU)` : "Canton of Lucerne",
  ];
}
