export const LANGUAGES = [
  { code: "en", label: "English", flag: "🇬🇧" },
  { code: "de", label: "Deutsch", flag: "🇩🇪" },
  { code: "it", label: "Italiano", flag: "🇮🇹" },
  { code: "fr", label: "Français", flag: "🇫🇷" },
  { code: "es", label: "Español", flag: "🇪🇸" },
  { code: "ar", label: "العربية", flag: "🇸🇦" },
  { code: "uk", label: "Українська", flag: "🇺🇦" },
  { code: "pt", label: "Português", flag: "🇵🇹" },
  { code: "tr", label: "Türkçe", flag: "🇹🇷" },
] as const;

export type LanguageCode = (typeof LANGUAGES)[number]["code"];

export type GuideProfile = {
  language: LanguageCode;
  citizenship: string;
  municipality: string;
  arrivalStage: string;
  permit: string;
  needs: string[];
};

export const DEFAULT_PROFILE: GuideProfile = {
  language: "en",
  citizenship: "",
  municipality: "",
  arrivalStage: "",
  permit: "",
  needs: [],
};

export type SearchProfile = Record<string, string>;
export type ShareFilters = Record<string, string | string[]>;

export type Service = {
  id: string;
  slug: string;
  name: string;
  short_description: string | null;
  organisation_name: string;
  category_slug: string | null;
  direct_url: string | null;
  cost_type: "free" | "reduced" | "paid" | "varies";
  appointment_required: boolean;
  available_languages: string[];
  geographical_coverage: string;
  eligible: boolean;
  eligibility_unknown: boolean;
  eligibility_reasons: string[];
  rank: number;
};

export type Category = {
  id: string;
  slug: string;
  name: string;
  name_i18n: Record<string, string>;
  icon: string | null;
  sort_order: number;
};

export type ServiceDetail = {
  id: string;
  slug: string;
  name: string;
  short_description: string | null;
  full_description: string | null;
  direct_url: string | null;
  contact_details: Record<string, string>;
  cost_type: Service["cost_type"];
  appointment_required: boolean;
  available_languages: string[];
  geographical_coverage: string;
  organisations: {
    name: string;
    website: string | null;
    address: string | null;
    phone: string | null;
    email: string | null;
  };
  categories: { slug: string; name: string; name_i18n: Record<string, string> } | null;
  eligibility_rules: Array<{
    rule_type: string;
    condition: string;
    value: string;
    explanation: string;
  }>;
};

export const TOPICS = [
  { slug: "registration", label: "Registration & residence", icon: "users" },
  { slug: "health-insurance", label: "Health & insurance", icon: "heart" },
  { slug: "work", label: "Work & employment", icon: "briefcase" },
  { slug: "education", label: "Studies & education", icon: "graduation" },
  { slug: "housing", label: "Housing", icon: "home" },
  { slug: "german-courses", label: "German language & integration", icon: "languages" },
  { slug: "family", label: "Family & children", icon: "family" },
  { slug: "permits", label: "Permits & administration", icon: "file" },
  { slug: "finances", label: "Social support & financial help", icon: "support" },
  { slug: "community", label: "Other / Not sure", icon: "more" },
] as const;

export const MUNICIPALITIES = [
  "Emmen",
  "Luzern",
  "Kriens",
  "Horw",
  "Ebikon",
  "Sursee",
  "Hochdorf",
  "Willisau",
] as const;
