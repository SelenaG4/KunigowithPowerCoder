import type { LanguageCode } from "./guide-types";

export const CALL_LANGUAGES = ["de", "en", "fr", "it"] as const satisfies readonly LanguageCode[];
export type CallLanguage = (typeof CALL_LANGUAGES)[number];

export function defaultCallLanguage(language: LanguageCode): CallLanguage {
  return CALL_LANGUAGES.find((code) => code === language) ?? "en";
}

// No booking provider is configured yet. Never claim a local selection is booked.
export const ADMIN_ZOOM_BOOKING_URL: string | null = null;

// A call request is only complete once the person has written the question they want answered.
export function canRequestCall({ date, time, question }: { date?: Date | undefined; time: string; question: string }) {
  return Boolean(date && time && question.trim().length > 0);
}

export const SCHEDULE_COPY = {
  en: { title: "Schedule a conversation", date: "Preferred date", time: "Preferred time", zone: "Your device’s time zone", draft: "Not booked", choose: "Choose a date and time", unavailable: "Zoom booking is not available yet. Your selected time is not confirmed and has not been sent to the admin.", continue: "Continue to Zoom booking", note: "Availability and your Zoom link are confirmed by the booking service.", admin: "Conversation with the admin", question: "Your question", questionHint: "What would you like to ask the admin?", questionRequired: "Please write your question before requesting the call." },
  de: { title: "Gespräch planen", date: "Gewünschtes Datum", time: "Gewünschte Uhrzeit", zone: "Zeitzone Ihres Geräts", draft: "Nicht gebucht", choose: "Datum und Uhrzeit wählen", unavailable: "Die Zoom-Buchung ist noch nicht verfügbar. Ihre Auswahl ist nicht bestätigt und wurde nicht an die Administration gesendet.", continue: "Weiter zur Zoom-Buchung", note: "Verfügbarkeit und Zoom-Link werden vom Buchungsdienst bestätigt.", admin: "Gespräch mit der Administration", question: "Ihre Frage", questionHint: "Was möchten Sie die Administration fragen?", questionRequired: "Bitte schreiben Sie Ihre Frage, bevor Sie das Gespräch anfragen." },
  fr: { title: "Planifier une conversation", date: "Date souhaitée", time: "Heure souhaitée", zone: "Fuseau horaire de votre appareil", draft: "Non réservé", choose: "Choisir une date et une heure", unavailable: "La réservation Zoom n’est pas encore disponible. Votre choix n’est pas confirmé et n’a pas été envoyé à l’administration.", continue: "Continuer vers la réservation Zoom", note: "La disponibilité et le lien Zoom sont confirmés par le service de réservation.", admin: "Conversation avec l’administration", question: "Votre question", questionHint: "Que souhaitez-vous demander à l’administration ?", questionRequired: "Veuillez écrire votre question avant de demander l’appel." },
  it: { title: "Programma una conversazione", date: "Data preferita", time: "Orario preferito", zone: "Fuso orario del dispositivo", draft: "Non prenotato", choose: "Scegli una data e un orario", unavailable: "La prenotazione Zoom non è ancora disponibile. La tua scelta non è confermata e non è stata inviata all’amministrazione.", continue: "Continua alla prenotazione Zoom", note: "La disponibilità e il link Zoom sono confermati dal servizio di prenotazione.", admin: "Conversazione con l’amministrazione", question: "La tua domanda", questionHint: "Cosa vuoi chiedere all’amministrazione?", questionRequired: "Scrivi la tua domanda prima di richiedere la chiamata." },
};