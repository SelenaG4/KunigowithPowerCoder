import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { DEFAULT_PROFILE, type GuideProfile } from "./guide-types";

const GUIDE_KEY = "triage-guide-v1";
const CHECKLIST_KEY = "triage-checklist-v1";

type GuideContextValue = {
  profile: GuideProfile;
  updateProfile: (patch: Partial<GuideProfile>) => void;
  resetProfile: () => void;
  hasCompletedGuide: boolean;
  setHasCompletedGuide: (value: boolean) => void;
  completedTasks: string[];
  toggleTask: (id: string) => void;
};

const GuideContext = createContext<GuideContextValue | null>(null);

export function GuideProvider({ children }: { children: ReactNode }) {
  const [profile, setProfile] = useState<GuideProfile>(DEFAULT_PROFILE);
  const [hasCompletedGuide, setHasCompletedGuide] = useState(false);
  const [completedTasks, setCompletedTasks] = useState<string[]>([]);
  const [restored, setRestored] = useState(false);

  useEffect(() => {
    try {
      const saved = sessionStorage.getItem(GUIDE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved) as { profile?: GuideProfile; completed?: boolean };
        if (parsed.profile) setProfile({ ...DEFAULT_PROFILE, ...parsed.profile });
        setHasCompletedGuide(parsed.completed === true);
      }
      const tasks = localStorage.getItem(CHECKLIST_KEY);
      if (tasks) setCompletedTasks(JSON.parse(tasks) as string[]);
    } catch {
      // A damaged or unavailable browser store should never block the guide.
    } finally {
      setRestored(true);
    }
  }, []);

  useEffect(() => {
    if (!restored) return;
    try {
      sessionStorage.setItem(GUIDE_KEY, JSON.stringify({ profile, completed: hasCompletedGuide }));
    } catch {
      // The guide still works for this visit when browser storage is unavailable.
    }
  }, [profile, hasCompletedGuide, restored]);

  useEffect(() => {
    if (!restored) return;
    try {
      localStorage.setItem(CHECKLIST_KEY, JSON.stringify(completedTasks));
    } catch {
      // Checklist persistence is optional when storage is blocked.
    }
  }, [completedTasks, restored]);

  const updateProfile = useCallback((patch: Partial<GuideProfile>) => {
    setProfile((current) => ({ ...current, ...patch }));
  }, []);

  const resetProfile = useCallback(() => {
    setProfile((current) => ({ ...DEFAULT_PROFILE, language: current.language }));
    setHasCompletedGuide(false);
  }, []);

  const toggleTask = useCallback((id: string) => {
    setCompletedTasks((current) =>
      current.includes(id) ? current.filter((item) => item !== id) : [...current, id],
    );
  }, []);

  const value = useMemo(
    () => ({ profile, updateProfile, resetProfile, hasCompletedGuide, setHasCompletedGuide, completedTasks, toggleTask }),
    [profile, updateProfile, resetProfile, hasCompletedGuide, completedTasks, toggleTask],
  );

  return <GuideContext.Provider value={value}>{children}</GuideContext.Provider>;
}

export function useGuide() {
  const context = useContext(GuideContext);
  if (!context) throw new Error("useGuide must be used inside GuideProvider");
  return context;
}
