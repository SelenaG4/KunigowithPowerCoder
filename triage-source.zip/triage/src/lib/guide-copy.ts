import type { LanguageCode } from "./guide-types";

const en = {
  tagline: "Your path to the right support.",
  welcome: "Welcome to Lucerne!",
  intro: "Discover the information and local services you need, all in one place. Simple, accessible and tailored to your needs.",
  create: "Create my personal guide",
  createHint: "Answer a few questions and get personalised support.",
  search: "Search services",
  searchHint: "Find information and services directly.",
  multilingual: "Multilingual",
  local: "Local services",
  noRegistration: "No registration",
  myGuide: "My guide",
  checklist: "My checklist",
  nearby: "Services near me",
  info: "More information",
  continue: "Continue",
  back: "Back",
  showGuide: "Show my guide",
  nextSteps: "Your next steps",
  recommended: "Recommended services for you",
  completed: "completed",
  share: "Share",
  print: "Print",
};

const de: typeof en = {
  tagline: "Ihr Weg zur richtigen Unterstützung.",
  welcome: "Willkommen in Luzern!",
  intro: "Finden Sie Informationen und lokale Angebote an einem Ort. Einfach, zugänglich und auf Ihre Bedürfnisse zugeschnitten.",
  create: "Meinen persönlichen Guide erstellen",
  createHint: "Beantworten Sie ein paar Fragen und erhalten Sie passende Unterstützung.",
  search: "Angebote suchen",
  searchHint: "Informationen und Dienstleistungen direkt finden.",
  multilingual: "Mehrsprachig",
  local: "Lokale Angebote",
  noRegistration: "Ohne Anmeldung",
  myGuide: "Mein Guide",
  checklist: "Meine Checkliste",
  nearby: "Angebote in meiner Nähe",
  info: "Weitere Informationen",
  continue: "Weiter",
  back: "Zurück",
  showGuide: "Meinen Guide anzeigen",
  nextSteps: "Ihre nächsten Schritte",
  recommended: "Empfohlene Angebote für Sie",
  completed: "erledigt",
  share: "Teilen",
  print: "Drucken",
};

const shortCopy: Partial<Record<LanguageCode, Partial<typeof en>>> = {
  fr: { welcome: "Bienvenue à Lucerne !", create: "Créer mon guide personnel", search: "Rechercher des services", continue: "Continuer", back: "Retour" },
  it: { welcome: "Benvenuti a Lucerna!", create: "Crea la mia guida personale", search: "Cerca i servizi", continue: "Continua", back: "Indietro" },
  es: { welcome: "¡Bienvenido a Lucerna!", create: "Crear mi guía personal", search: "Buscar servicios", continue: "Continuar", back: "Atrás" },
  pt: { welcome: "Bem-vindo a Lucerna!", create: "Criar o meu guia pessoal", search: "Procurar serviços", continue: "Continuar", back: "Voltar" },
  tr: { welcome: "Luzern'e hoş geldiniz!", create: "Kişisel rehberimi oluştur", search: "Hizmet ara", continue: "Devam", back: "Geri" },
  uk: { welcome: "Ласкаво просимо до Люцерна!", create: "Створити мій особистий путівник", search: "Пошук послуг", continue: "Далі", back: "Назад" },
  ar: { welcome: "مرحباً بكم في لوسيرن!", create: "إنشاء دليلي الشخصي", search: "البحث عن الخدمات", continue: "متابعة", back: "رجوع" },
};

export type Copy = typeof en;

export function getCopy(language: LanguageCode): Copy {
  if (language === "de") return de;
  return { ...en, ...(shortCopy[language] ?? {}) };
}
