import { queryOptions } from "@tanstack/react-query";
import { getCategories, getServiceBySlug, getServices, getSharedGuide, type SearchInput } from "./services.functions";

export function servicesQueryOptions(input: SearchInput) {
  return queryOptions({
    queryKey: ["services", input],
    queryFn: () => getServices({ data: input }),
  });
}

export function categoriesQueryOptions() {
  return queryOptions({ queryKey: ["categories"], queryFn: () => getCategories() });
}

export function serviceDetailQueryOptions(slug: string, language = "en") {
  return queryOptions({
    queryKey: ["service", slug, language],
    queryFn: () => getServiceBySlug({ data: { slug, language } }),
  });
}

export function sharedGuideQueryOptions(code: string) {
  return queryOptions({
    queryKey: ["shared-guide", code],
    queryFn: () => getSharedGuide({ data: { code } }),
  });
}
