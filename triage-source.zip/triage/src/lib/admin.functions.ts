import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const LANGS: Record<string, string> = { en: "English", it: "Italian", fr: "French", es: "Spanish", ar: "Modern Standard Arabic", uk: "Ukrainian", pt: "Portuguese", tr: "Turkish" };

/** Translates up to 20 active services that still lack a translation in one language. */
export const translateMissing = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i: { language: string }) => z.object({ language: z.enum(Object.keys(LANGS) as [string, ...string[]]) }).parse(i))
  .handler(async ({ data, context }) => {
    const db = context.supabase;
    const { data: me } = await db.from("admin_users").select("user_id").eq("user_id", context.userId).maybeSingle();
    if (!me) throw new Error("Only administrators can do this.");
    const { data: done } = await db.from("translations").select("service_id").eq("language", data.language);
    const doneIds = new Set((done ?? []).map((r) => r.service_id));
    const { data: all } = await db.from("services").select("id, name, short_description, full_description").eq("service_status", "active");
    const todo = (all ?? []).filter((s) => !doneIds.has(s.id));
    const batch = todo.slice(0, 20);
    if (!batch.length) return { translated: 0, remaining: 0 };
    const key = process.env["LOVABLE_API_KEY"];
    if (!key) throw new Error("Translation is not available right now.");
    const { createOpenAI } = await import("@ai-sdk/openai");
    const { streamText, Output } = await import("ai");
    const provider = createOpenAI({ baseURL: "https://ai.gateway.lovable.dev/v1", apiKey: key, headers: { "Lovable-API-Key": key, "X-Lovable-AIG-SDK": "vercel-ai-sdk" } });
    const schema = z.object({ items: z.array(z.object({ id: z.string(), name: z.string(), short_description: z.string().nullable(), full_description: z.string().nullable() })) });
    const result = streamText({
      model: provider.responses("openai/gpt-6-astra"),
      instructions: `Translate a Swiss social-services directory from German into clear, simple ${LANGS[data.language]}. Keep organisation names, brand names, places, addresses, URLs, emails, phone numbers, prices and dates unchanged. Return one item per input id; null stays null.`,
      messages: [{ role: "user", content: JSON.stringify(batch) }],
      output: Output.object({ schema }),
      providerOptions: { openai: { forceReasoning: true, reasoningEffort: "low", reasoningSummary: "auto", store: false, include: ["reasoning.encrypted_content"] } },
    });
    let parsed: z.infer<typeof schema>;
    try { parsed = await result.output; } catch { throw new Error("Translation failed, please try again."); }
    const ids = new Set(batch.map((b) => b.id));
    const rows = (parsed.items ?? []).filter((t) => ids.has(t.id) && t.name).map((t) => ({
      service_id: t.id, language: data.language, translated_name: t.name.trim(),
      translated_short_description: t.short_description?.trim() || null,
      translated_description: t.full_description?.trim() || null,
      translation_status: "machine" as const,
    }));
    if (rows.length) {
      const { error } = await db.from("translations").insert(rows);
      if (error) throw new Error("Saving translations failed.");
    }
    return { translated: rows.length, remaining: todo.length - rows.length };
  });
