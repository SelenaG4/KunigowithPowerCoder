import { describe, expect, it } from "vitest";
import { DEFAULT_PROFILE, type GuideProfile } from "@/lib/guide-types";
import { buildChecklist, shareableFilters, toSearchProfile } from "@/lib/guide-utils";

const emmenProfile: GuideProfile = {
  language: "en",
  citizenship: "eu_efta",
  municipality: "Emmen",
  arrivalStage: "just-arrived",
  permit: "B",
  needs: ["registration", "health-insurance", "german-courses"],
};

describe("personal guide rules", () => {
  it("maps the reference EU/B/Emmen profile to deterministic eligibility filters", () => {
    expect(toSearchProfile(emmenProfile)).toEqual({
      citizenship: "eu_efta",
      municipality: "emmen",
      place_of_residence: "canton_of_lucerne",
      arrival_stage: "just-arrived",
      residence_status: "B",
    });
  });

  it("builds the four reference next steps for a newly arrived German-course user", () => {
    expect(buildChecklist(emmenProfile).map((item) => item.id)).toEqual([
      "register",
      "health-insurance",
      "permit",
      "german-course",
    ]);
  });

  it("never includes names, contact details, or unknown fields in a shared guide", () => {
    const filters = shareableFilters(emmenProfile) as Record<string, unknown>;
    filters["name"] = "Should not survive a server allow-list";
    expect(Object.keys(filters)).not.toContain("email");
    expect(Object.keys(filters)).not.toContain("phone");
    expect(filters["categories"]).toEqual(["registration", "health-insurance", "german-courses"]);
  });

  it("does not treat an unsure permit as a concrete residence status", () => {
    expect(toSearchProfile({ ...DEFAULT_PROFILE, permit: "unsure" })).not.toHaveProperty("residence_status");
  });
});
