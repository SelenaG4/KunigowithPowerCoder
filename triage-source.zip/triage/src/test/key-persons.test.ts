import { describe, expect, it } from "vitest";
import { matchingKeyPersons, type KeyPerson } from "../lib/key-persons";

const person: KeyPerson = { id: "test-contact", name: "Test contact", organisation: "Test organisation", languages: ["de", "fr"], bookingUrl: "https://cal.com/test-contact/video", provider: "Cal.com", videoBookingConfigured: true };

describe("key-person matching", () => {
  it("shows only people who speak the chosen language", () => {
    expect(matchingKeyPersons([person], "fr")).toEqual([person]);
    expect(matchingKeyPersons([person], "en")).toEqual([]);
  });
  it("requires a booking configured for automatic video meetings", () => {
    expect(matchingKeyPersons([{ ...person, videoBookingConfigured: false }], "de")).toEqual([]);
  });
  it("accepts HTTPS bookings across the three requested providers", () => {
    for (const bookingUrl of ["https://cal.com/test/video", "https://outlook.office.com/book/test", "https://scheduler.zoom.us/test"]) {
      expect(matchingKeyPersons([{ ...person, bookingUrl }], "de")).toHaveLength(1);
    }
  });
  it("rejects unsafe or malformed booking links", () => {
    for (const bookingUrl of ["javascript:alert(1)", "http://cal.com/test", "invalid", "https://user:password@cal.com/test"]) {
      expect(matchingKeyPersons([{ ...person, bookingUrl }], "de")).toEqual([]);
    }
  });
});