import { cleanup, fireEvent, render } from "@testing-library/react";
import { afterEach, describe, expect, it } from "vitest";

import { CallOfferDialog } from "@/components/CallOfferDialog";

afterEach(cleanup);

function openDialog(language: "en" | "de" = "en") {
  render(<CallOfferDialog open onOpenChange={() => {}} language={language} />);
}

describe("video call popup after a self-search PDF download", () => {
  it("shows nothing while the popup is closed", () => {
    render(<CallOfferDialog open={false} onOpenChange={() => {}} language="en" />);
    expect(document.body.textContent).not.toContain("Still need more support?");
    expect(document.querySelector("textarea")).toBeNull();
  });

  it("offers the free video call and the question box once opened", () => {
    openDialog();
    expect(document.body.textContent).toContain("Still need more support?");
    expect(document.body.textContent).toContain("1 free video call");
    const box = document.querySelector("textarea");
    expect(box).toBeTruthy();
    expect(box?.getAttribute("placeholder")).toBe("What would you like to ask the admin?");
  });

  it("keeps the appointment unconfirmed until a date, time and question are all given", () => {
    openDialog();
    const preview = [...document.querySelectorAll("button")].find((button) =>
      button.textContent?.includes("Preview appointment"),
    );
    expect(preview).toBeTruthy();
    expect(preview?.disabled).toBe(true);

    const box = document.querySelector("textarea");
    expect(box).toBeTruthy();
    if (box) fireEvent.change(box, { target: { value: "How do I register for health insurance?" } });
    // A question alone is not enough: no date or time has been chosen yet.
    expect(preview?.disabled).toBe(true);
  });

  it("shows the German offer in German", () => {
    openDialog("de");
    expect(document.body.textContent).toContain("Brauchen Sie noch mehr Unterstützung?");
    expect(document.body.textContent).toContain("Ihre Frage");
  });
});
