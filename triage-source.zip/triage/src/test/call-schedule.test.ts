import { describe, expect, it } from "vitest";
import { CALL_LANGUAGES, canRequestCall, defaultCallLanguage } from "../lib/call-schedule";

describe("admin call languages", () => {
  it("allows only German, English, French and Italian", () => {
    expect([...CALL_LANGUAGES].sort()).toEqual(["de", "en", "fr", "it"]);
  });
  it("keeps supported settings languages and defaults others to English", () => {
    expect(defaultCallLanguage("fr")).toBe("fr");
    expect(defaultCallLanguage("de")).toBe("de");
    expect(defaultCallLanguage("it")).toBe("it");
    expect(defaultCallLanguage("ar")).toBe("en");
  });
});

describe("call request completeness", () => {
  const date = new Date(2026, 10, 25);

  it("requires a written question before the call can be requested", () => {
    expect(canRequestCall({ date, time: "10:30", question: "" })).toBe(false);
    expect(canRequestCall({ date, time: "10:30", question: "   " })).toBe(false);
  });

  it("accepts a date, time and question together", () => {
    expect(canRequestCall({ date, time: "10:30", question: "Ich brauche eine Wohnungshilfe." })).toBe(true);
  });

  it("still needs a date and time even with a question", () => {
    expect(canRequestCall({ time: "10:30", question: "Wohnungshilfe?" })).toBe(false);
    expect(canRequestCall({ date, time: "", question: "Wohnungshilfe?" })).toBe(false);
  });
});
