import { cleanup, fireEvent, render, waitFor } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import type { ReactNode } from "react";

// The guide page is rendered without a live router: links become plain anchors and
// hydration is reported as done, so the page's own download logic can be exercised.
vi.mock("@tanstack/react-router", () => ({
  Link: (props: { children?: ReactNode; to?: string; className?: string }) => (
    <a href={props.to ?? "#"} className={props.className}>
      {props.children}
    </a>
  ),
  useHydrated: () => true,
}));

import { GuideOverview } from "@/components/GuideOverview";
import { GuideProvider } from "@/lib/guide-context";
import { DEFAULT_PROFILE, type Service } from "@/lib/guide-types";

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
  vi.restoreAllMocks();
});

function renderGuide() {
  Object.defineProperty(URL, "createObjectURL", {
    value: vi.fn(() => "blob:triage-guide"),
    configurable: true,
    writable: true,
  });
  Object.defineProperty(URL, "revokeObjectURL", {
    value: vi.fn(),
    configurable: true,
    writable: true,
  });
  vi.spyOn(HTMLAnchorElement.prototype, "click").mockImplementation(() => {});

  return render(
    <GuideProvider>
      <GuideOverview
        profile={DEFAULT_PROFILE}
        services={[] as Service[]}
        onShare={() => {}}
        shareCode="test123"
        sharing={false}
      />
    </GuideProvider>,
  );
}

function downloadButton() {
  return [...document.querySelectorAll("button")].find((button) =>
    button.textContent?.includes("Download PDF"),
  );
}

describe("video call offer on the personal guide page", () => {
  it("shows no video-call banner while the PDF has not been downloaded", () => {
    renderGuide();

    expect(document.body.textContent).not.toContain("Still need more support?");
    expect(document.body.textContent).not.toContain("Get my free video call");
    expect(document.querySelector("textarea")).toBeNull();
  });

  it("offers the free video call only after the PDF download starts", async () => {
    const fetchMock = vi.fn(async () => ({
      ok: true,
      blob: async () => new Blob(["pdf"], { type: "application/pdf" }),
    }));
    vi.stubGlobal("fetch", fetchMock);
    renderGuide();

    const button = downloadButton();
    expect(button).toBeTruthy();
    fireEvent.click(button as HTMLButtonElement);

    await waitFor(() => expect(document.body.textContent).toContain("Still need more support?"));
    expect(fetchMock).toHaveBeenCalledWith("/api/public/guide-pdf/test123");
    expect(document.querySelector("textarea")).toBeTruthy();
  });

  it("keeps the offer closed when the PDF cannot be downloaded", async () => {
    const fetchMock = vi.fn(async () => ({ ok: false, blob: async () => new Blob() }));
    vi.stubGlobal("fetch", fetchMock);
    renderGuide();

    const button = downloadButton();
    expect(button).toBeTruthy();
    fireEvent.click(button as HTMLButtonElement);

    await waitFor(() => expect(fetchMock).toHaveBeenCalled());
    await waitFor(() => expect((button as HTMLButtonElement).disabled).toBe(false));
    expect(document.body.textContent).not.toContain("Still need more support?");
    expect(document.querySelector("textarea")).toBeNull();
  });
});
