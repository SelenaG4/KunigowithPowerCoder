export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      admin_users: {
        Row: {
          created_at: string
          full_name: string | null
          role: string
          user_id: string
        }
        Insert: {
          created_at?: string
          full_name?: string | null
          role?: string
          user_id: string
        }
        Update: {
          created_at?: string
          full_name?: string | null
          role?: string
          user_id?: string
        }
        Relationships: []
      }
      categories: {
        Row: {
          created_at: string
          icon: string | null
          id: string
          keywords: string[]
          name: string
          name_i18n: Json
          parent_category_id: string | null
          slug: string
          sort_order: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          icon?: string | null
          id?: string
          keywords?: string[]
          name: string
          name_i18n?: Json
          parent_category_id?: string | null
          slug: string
          sort_order?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          icon?: string | null
          id?: string
          keywords?: string[]
          name?: string
          name_i18n?: Json
          parent_category_id?: string | null
          slug?: string
          sort_order?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "categories_parent_category_id_fkey"
            columns: ["parent_category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      change_log: {
        Row: {
          change_type: Database["public"]["Enums"]["change_type"]
          changed_at: string
          changed_by: string | null
          details: Json | null
          id: string
          service_id: string | null
        }
        Insert: {
          change_type: Database["public"]["Enums"]["change_type"]
          changed_at?: string
          changed_by?: string | null
          details?: Json | null
          id?: string
          service_id?: string | null
        }
        Update: {
          change_type?: Database["public"]["Enums"]["change_type"]
          changed_at?: string
          changed_by?: string | null
          details?: Json | null
          id?: string
          service_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "change_log_service_id_fkey"
            columns: ["service_id"]
            isOneToOne: false
            referencedRelation: "services"
            referencedColumns: ["id"]
          },
        ]
      }
      eligibility_rules: {
        Row: {
          condition: Database["public"]["Enums"]["eligibility_condition"]
          created_at: string
          explanation: string
          id: string
          rule_type: Database["public"]["Enums"]["eligibility_rule_type"]
          service_id: string
          source_id: string | null
          updated_at: string
          value: string
          verified_at: string | null
        }
        Insert: {
          condition: Database["public"]["Enums"]["eligibility_condition"]
          created_at?: string
          explanation: string
          id?: string
          rule_type: Database["public"]["Enums"]["eligibility_rule_type"]
          service_id: string
          source_id?: string | null
          updated_at?: string
          value: string
          verified_at?: string | null
        }
        Update: {
          condition?: Database["public"]["Enums"]["eligibility_condition"]
          created_at?: string
          explanation?: string
          id?: string
          rule_type?: Database["public"]["Enums"]["eligibility_rule_type"]
          service_id?: string
          source_id?: string | null
          updated_at?: string
          value?: string
          verified_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "eligibility_rules_service_id_fkey"
            columns: ["service_id"]
            isOneToOne: false
            referencedRelation: "services"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "eligibility_rules_source_id_fkey"
            columns: ["source_id"]
            isOneToOne: false
            referencedRelation: "sources"
            referencedColumns: ["id"]
          },
        ]
      }
      import_batches: {
        Row: {
          column_map: Json
          created_at: string
          file_name: string
          header_row: number | null
          id: string
          published_at: string | null
          sheet_name: string | null
          source_id: string | null
          status: Database["public"]["Enums"]["import_batch_status"]
          storage_path: string | null
          uploaded_by: string | null
        }
        Insert: {
          column_map?: Json
          created_at?: string
          file_name: string
          header_row?: number | null
          id?: string
          published_at?: string | null
          sheet_name?: string | null
          source_id?: string | null
          status?: Database["public"]["Enums"]["import_batch_status"]
          storage_path?: string | null
          uploaded_by?: string | null
        }
        Update: {
          column_map?: Json
          created_at?: string
          file_name?: string
          header_row?: number | null
          id?: string
          published_at?: string | null
          sheet_name?: string | null
          source_id?: string | null
          status?: Database["public"]["Enums"]["import_batch_status"]
          storage_path?: string | null
          uploaded_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "import_batches_source_id_fkey"
            columns: ["source_id"]
            isOneToOne: false
            referencedRelation: "sources"
            referencedColumns: ["id"]
          },
        ]
      }
      import_category_mappings: {
        Row: {
          category_slug: string
          source_label: string
        }
        Insert: {
          category_slug: string
          source_label: string
        }
        Update: {
          category_slug?: string
          source_label?: string
        }
        Relationships: [
          {
            foreignKeyName: "import_category_mappings_category_slug_fkey"
            columns: ["category_slug"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["slug"]
          },
        ]
      }
      import_column_aliases: {
        Row: {
          alias: string
          target_field: string
        }
        Insert: {
          alias: string
          target_field: string
        }
        Update: {
          alias?: string
          target_field?: string
        }
        Relationships: []
      }
      import_rows: {
        Row: {
          batch_id: string
          created_at: string
          fields: Json
          id: string
          issues: string[]
          organisation_id: string | null
          parsed: Json
          raw: Json
          row_number: number
          section: string | null
          service_id: string | null
          status: Database["public"]["Enums"]["import_row_status"]
          updated_at: string
        }
        Insert: {
          batch_id: string
          created_at?: string
          fields?: Json
          id?: string
          issues?: string[]
          organisation_id?: string | null
          parsed?: Json
          raw: Json
          row_number: number
          section?: string | null
          service_id?: string | null
          status?: Database["public"]["Enums"]["import_row_status"]
          updated_at?: string
        }
        Update: {
          batch_id?: string
          created_at?: string
          fields?: Json
          id?: string
          issues?: string[]
          organisation_id?: string | null
          parsed?: Json
          raw?: Json
          row_number?: number
          section?: string | null
          service_id?: string | null
          status?: Database["public"]["Enums"]["import_row_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "import_rows_batch_id_fkey"
            columns: ["batch_id"]
            isOneToOne: false
            referencedRelation: "import_batches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "import_rows_organisation_id_fkey"
            columns: ["organisation_id"]
            isOneToOne: false
            referencedRelation: "organisations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "import_rows_service_id_fkey"
            columns: ["service_id"]
            isOneToOne: false
            referencedRelation: "services"
            referencedColumns: ["id"]
          },
        ]
      }
      municipalities: {
        Row: {
          bfs_number: number | null
          canton: string
          created_at: string
          id: string
          municipality_name: string
        }
        Insert: {
          bfs_number?: number | null
          canton?: string
          created_at?: string
          id?: string
          municipality_name: string
        }
        Update: {
          bfs_number?: number | null
          canton?: string
          created_at?: string
          id?: string
          municipality_name?: string
        }
        Relationships: []
      }
      organisations: {
        Row: {
          address: string | null
          created_at: string
          description: string | null
          email: string | null
          id: string
          name: string
          organisation_type: Database["public"]["Enums"]["organisation_type"]
          phone: string | null
          updated_at: string
          verification_status: Database["public"]["Enums"]["verification_status"]
          website: string | null
        }
        Insert: {
          address?: string | null
          created_at?: string
          description?: string | null
          email?: string | null
          id?: string
          name: string
          organisation_type?: Database["public"]["Enums"]["organisation_type"]
          phone?: string | null
          updated_at?: string
          verification_status?: Database["public"]["Enums"]["verification_status"]
          website?: string | null
        }
        Update: {
          address?: string | null
          created_at?: string
          description?: string | null
          email?: string | null
          id?: string
          name?: string
          organisation_type?: Database["public"]["Enums"]["organisation_type"]
          phone?: string | null
          updated_at?: string
          verification_status?: Database["public"]["Enums"]["verification_status"]
          website?: string | null
        }
        Relationships: []
      }
      service_categories: {
        Row: {
          category_id: string
          service_id: string
        }
        Insert: {
          category_id: string
          service_id: string
        }
        Update: {
          category_id?: string
          service_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "service_categories_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "service_categories_service_id_fkey"
            columns: ["service_id"]
            isOneToOne: false
            referencedRelation: "services"
            referencedColumns: ["id"]
          },
        ]
      }
      service_municipalities: {
        Row: {
          municipality_id: string
          service_id: string
        }
        Insert: {
          municipality_id: string
          service_id: string
        }
        Update: {
          municipality_id?: string
          service_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "service_municipalities_municipality_id_fkey"
            columns: ["municipality_id"]
            isOneToOne: false
            referencedRelation: "municipalities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "service_municipalities_service_id_fkey"
            columns: ["service_id"]
            isOneToOne: false
            referencedRelation: "services"
            referencedColumns: ["id"]
          },
        ]
      }
      service_submissions: {
        Row: {
          category_id: string | null
          contact_details: Json
          created_at: string
          created_service_id: string | null
          description: string | null
          eligibility_notes: string | null
          id: string
          languages: string[]
          organisation_name: string
          reviewed_at: string | null
          reviewed_by: string | null
          service_name: string
          status: Database["public"]["Enums"]["submission_status"]
          submitter_note: string | null
          website: string | null
        }
        Insert: {
          category_id?: string | null
          contact_details?: Json
          created_at?: string
          created_service_id?: string | null
          description?: string | null
          eligibility_notes?: string | null
          id?: string
          languages?: string[]
          organisation_name: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          service_name: string
          status?: Database["public"]["Enums"]["submission_status"]
          submitter_note?: string | null
          website?: string | null
        }
        Update: {
          category_id?: string | null
          contact_details?: Json
          created_at?: string
          created_service_id?: string | null
          description?: string | null
          eligibility_notes?: string | null
          id?: string
          languages?: string[]
          organisation_name?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          service_name?: string
          status?: Database["public"]["Enums"]["submission_status"]
          submitter_note?: string | null
          website?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "service_submissions_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "service_submissions_created_service_id_fkey"
            columns: ["created_service_id"]
            isOneToOne: false
            referencedRelation: "services"
            referencedColumns: ["id"]
          },
        ]
      }
      services: {
        Row: {
          appointment_required: boolean
          available_languages: string[]
          category_id: string | null
          contact_details: Json
          cost_notes: string | null
          cost_type: Database["public"]["Enums"]["cost_type"]
          created_at: string
          direct_url: string | null
          eligibility_notes: string | null
          embedding: string | null
          external_ref: string | null
          full_description: string | null
          geographical_coverage: Database["public"]["Enums"]["geographical_coverage"]
          has_flyer: boolean | null
          id: string
          last_verified_at: string | null
          name: string
          organisation_id: string
          search_vector: unknown
          service_status: Database["public"]["Enums"]["service_status"]
          short_description: string | null
          slug: string
          source_id: string | null
          updated_at: string
        }
        Insert: {
          appointment_required?: boolean
          available_languages?: string[]
          category_id?: string | null
          contact_details?: Json
          cost_notes?: string | null
          cost_type?: Database["public"]["Enums"]["cost_type"]
          created_at?: string
          direct_url?: string | null
          eligibility_notes?: string | null
          embedding?: string | null
          external_ref?: string | null
          full_description?: string | null
          geographical_coverage?: Database["public"]["Enums"]["geographical_coverage"]
          has_flyer?: boolean | null
          id?: string
          last_verified_at?: string | null
          name: string
          organisation_id: string
          search_vector?: unknown
          service_status?: Database["public"]["Enums"]["service_status"]
          short_description?: string | null
          slug: string
          source_id?: string | null
          updated_at?: string
        }
        Update: {
          appointment_required?: boolean
          available_languages?: string[]
          category_id?: string | null
          contact_details?: Json
          cost_notes?: string | null
          cost_type?: Database["public"]["Enums"]["cost_type"]
          created_at?: string
          direct_url?: string | null
          eligibility_notes?: string | null
          embedding?: string | null
          external_ref?: string | null
          full_description?: string | null
          geographical_coverage?: Database["public"]["Enums"]["geographical_coverage"]
          has_flyer?: boolean | null
          id?: string
          last_verified_at?: string | null
          name?: string
          organisation_id?: string
          search_vector?: unknown
          service_status?: Database["public"]["Enums"]["service_status"]
          short_description?: string | null
          slug?: string
          source_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "services_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "services_organisation_id_fkey"
            columns: ["organisation_id"]
            isOneToOne: false
            referencedRelation: "organisations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "services_source_id_fkey"
            columns: ["source_id"]
            isOneToOne: false
            referencedRelation: "sources"
            referencedColumns: ["id"]
          },
        ]
      }
      shared_guides: {
        Row: {
          code: string
          created_at: string
          filters: Json
          language: string
          service_ids: string[]
        }
        Insert: {
          code?: string
          created_at?: string
          filters?: Json
          language?: string
          service_ids?: string[]
        }
        Update: {
          code?: string
          created_at?: string
          filters?: Json
          language?: string
          service_ids?: string[]
        }
        Relationships: []
      }
      sources: {
        Row: {
          created_at: string
          id: string
          import_date: string
          last_checked_at: string | null
          source_name: string
          source_type: Database["public"]["Enums"]["source_type"]
          source_url: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          import_date?: string
          last_checked_at?: string | null
          source_name: string
          source_type?: Database["public"]["Enums"]["source_type"]
          source_url?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          import_date?: string
          last_checked_at?: string | null
          source_name?: string
          source_type?: Database["public"]["Enums"]["source_type"]
          source_url?: string | null
        }
        Relationships: []
      }
      translations: {
        Row: {
          created_at: string
          id: string
          language: string
          search_vector: unknown
          service_id: string
          translated_description: string | null
          translated_name: string
          translated_short_description: string | null
          translation_status: Database["public"]["Enums"]["translation_status"]
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          language: string
          search_vector?: unknown
          service_id: string
          translated_description?: string | null
          translated_name: string
          translated_short_description?: string | null
          translation_status?: Database["public"]["Enums"]["translation_status"]
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          language?: string
          search_vector?: unknown
          service_id?: string
          translated_description?: string | null
          translated_name?: string
          translated_short_description?: string | null
          translation_status?: Database["public"]["Enums"]["translation_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "translations_service_id_fkey"
            columns: ["service_id"]
            isOneToOne: false
            referencedRelation: "services"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      check_eligibility: {
        Args: { p_profile: Json; p_service_id: string }
        Returns: {
          eligible: boolean
          reasons: string[]
          unknown: boolean
        }[]
      }
      create_shared_guide: {
        Args: { p_filters: Json; p_language: string; p_service_ids: string[] }
        Returns: string
      }
      import_batch_summary: { Args: { p_batch_id: string }; Returns: Json }
      import_publish_batch: {
        Args: { p_activate?: boolean; p_batch_id: string }
        Returns: Json
      }
      import_reparse_batch: { Args: { p_batch_id: string }; Returns: undefined }
      import_stage_sheet: {
        Args: {
          p_file_name: string
          p_rows: Json
          p_sheet_name: string
          p_storage_path?: string
        }
        Returns: string
      }
      search_services: {
        Args: {
          p_category?: string
          p_language?: string
          p_limit?: number
          p_offset?: number
          p_only_eligible?: boolean
          p_profile?: Json
          p_query?: string
        }
        Returns: {
          appointment_required: boolean
          available_languages: string[]
          category_slug: string
          cost_type: Database["public"]["Enums"]["cost_type"]
          direct_url: string
          eligibility_reasons: string[]
          eligibility_unknown: boolean
          eligible: boolean
          geographical_coverage: Database["public"]["Enums"]["geographical_coverage"]
          id: string
          name: string
          organisation_name: string
          rank: number
          short_description: string
          slug: string
        }[]
      }
    }
    Enums: {
      change_type:
        | "created"
        | "updated"
        | "verified"
        | "status_changed"
        | "deleted"
      cost_type: "free" | "reduced" | "paid" | "varies"
      eligibility_condition: "requires" | "excludes"
      eligibility_rule_type:
        | "residence_status"
        | "place_of_residence"
        | "citizenship"
        | "social_assistance_provider"
        | "arrival_stage"
        | "age_group"
        | "gender"
        | "other"
        | "municipality"
      geographical_coverage:
        | "city_of_lucerne"
        | "canton_of_lucerne"
        | "central_switzerland"
        | "switzerland"
        | "online"
        | "specific_municipalities"
      import_batch_status:
        | "staged"
        | "partly_published"
        | "published"
        | "discarded"
      import_row_status:
        | "section"
        | "note"
        | "ready"
        | "needs_review"
        | "approved"
        | "duplicate"
        | "skipped"
        | "published"
      organisation_type:
        | "association"
        | "ngo"
        | "city_service"
        | "cantonal_service"
        | "federal_service"
        | "church"
        | "private"
        | "other"
      service_status: "draft" | "active" | "paused" | "archived"
      source_type:
        | "website"
        | "pdf"
        | "phone"
        | "email"
        | "partner_import"
        | "community_submission"
        | "other"
      submission_status: "new" | "in_review" | "accepted" | "rejected"
      translation_status: "machine" | "draft" | "reviewed" | "published"
      verification_status: "pending" | "verified" | "rejected" | "archived"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      change_type: [
        "created",
        "updated",
        "verified",
        "status_changed",
        "deleted",
      ],
      cost_type: ["free", "reduced", "paid", "varies"],
      eligibility_condition: ["requires", "excludes"],
      eligibility_rule_type: [
        "residence_status",
        "place_of_residence",
        "citizenship",
        "social_assistance_provider",
        "arrival_stage",
        "age_group",
        "gender",
        "other",
        "municipality",
      ],
      geographical_coverage: [
        "city_of_lucerne",
        "canton_of_lucerne",
        "central_switzerland",
        "switzerland",
        "online",
        "specific_municipalities",
      ],
      import_batch_status: [
        "staged",
        "partly_published",
        "published",
        "discarded",
      ],
      import_row_status: [
        "section",
        "note",
        "ready",
        "needs_review",
        "approved",
        "duplicate",
        "skipped",
        "published",
      ],
      organisation_type: [
        "association",
        "ngo",
        "city_service",
        "cantonal_service",
        "federal_service",
        "church",
        "private",
        "other",
      ],
      service_status: ["draft", "active", "paused", "archived"],
      source_type: [
        "website",
        "pdf",
        "phone",
        "email",
        "partner_import",
        "community_submission",
        "other",
      ],
      submission_status: ["new", "in_review", "accepted", "rejected"],
      translation_status: ["machine", "draft", "reviewed", "published"],
      verification_status: ["pending", "verified", "rejected", "archived"],
    },
  },
} as const
