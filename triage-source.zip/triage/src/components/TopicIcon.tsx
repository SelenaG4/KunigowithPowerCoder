import { Baby, BriefcaseBusiness, CircleEllipsis, FileText, GraduationCap, HandHeart, Heart, Home, Languages, MessageCircle, Users, Wallet } from "lucide-react";
import { cn } from "@/lib/utils";

const icons = {
  registration: Users,
  "health-insurance": Heart,
  health: Heart,
  work: BriefcaseBusiness,
  education: GraduationCap,
  housing: Home,
  "german-courses": Languages,
  family: Baby,
  permits: FileText,
  finances: Wallet,
  counselling: MessageCircle,
  community: HandHeart,
};

export function TopicIcon({ category, className }: { category?: string | null; className?: string }) {
  const Icon = (category && category in icons ? icons[category as keyof typeof icons] : CircleEllipsis);
  return <Icon className={cn("h-6 w-6", className)} aria-hidden="true" />;
}
