import { useDeferredValue, useState } from "react";
import { useSuspenseQuery } from "@tanstack/react-query";
import { Check, Download, FileText, Filter, MapPin, Search, SlidersHorizontal, X } from "lucide-react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { createSharedGuide } from "@/lib/services.functions";
import { categoriesQueryOptions, servicesQueryOptions } from "@/lib/service-queries";
import { useGuide } from "@/lib/guide-context";
import { toSearchProfile } from "@/lib/guide-utils";
import { ServiceCard } from "./ServiceCard";
import { TopicIcon } from "./TopicIcon";
import { CallOfferDialog } from "./CallOfferDialog";
import { cn } from "@/lib/utils";

export function ServiceDirectory({ nearby = false }: { nearby?: boolean }) {
  const { profile } = useGuide();
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<string | null>(null);
  const [onlyEligible, setOnlyEligible] = useState(false);
  const [selected, setSelected] = useState<Map<string, string | null>>(new Map());
  const [pdfCode, setPdfCode] = useState("");
  const [callOfferOpen, setCallOfferOpen] = useState(false);
  const [creating, setCreating] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const createShare = useServerFn(createSharedGuide);
  const toggle = (id: string, cat: string | null) => {
    setPdfCode("");
    setSelected((prev) => { const next = new Map(prev); if (next.has(id)) next.delete(id); else if (next.size < 50) next.set(id, cat); else toast.error("You can pick up to 50 services."); return next; });
  };
  const createPdf = async () => {
    setCreating(true);
    try {
            const { code } = await createShare({ data: { language: profile.language, filters: { pdf_mode: "list" }, serviceIds: [...selected.keys()] } });
      setPdfCode(code);
    } catch { toast.error("The PDF could not be created. Please try again."); }
    finally { setCreating(false); }
  };
  const downloadPdf = async () => {
    if (!pdfCode) return;
    setDownloading(true);
    try {
      const response = await fetch(`/api/public/guide-pdf/${pdfCode}`);
      if (!response.ok) throw new Error("PDF download failed");
      const blobUrl = URL.createObjectURL(await response.blob());
      const link = document.createElement("a");
      link.href = blobUrl;
      link.download = `triage-lucerne-services-${pdfCode}.pdf`;
      link.style.display = "none";
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.setTimeout(() => URL.revokeObjectURL(blobUrl), 1000);
      // Open only after the PDF has been fetched and its download has started.
      setCallOfferOpen(true);
    } catch {
      toast.error("The PDF could not be downloaded. Please try again.");
    } finally {
      setDownloading(false);
    }
  };
  const deferredQuery = useDeferredValue(query);
  const searchProfile = toSearchProfile(profile);
  const { data: categories } = useSuspenseQuery(categoriesQueryOptions());
  const { data: services } = useSuspenseQuery(servicesQueryOptions({
    query: deferredQuery || undefined,
    language: profile.language,
    category,
    profile: searchProfile,
    onlyEligible,
    limit: 50,
  }));

  return (
    <div className={cn("animate-enter", selected.size > 0 && "pb-40 md:pb-0")}>
      <p className="text-xs font-extrabold uppercase tracking-[0.18em] text-primary">Lucerne service directory</p>
      <h1 className="page-title mt-2">{nearby ? "Services near you" : "Find the right support"}</h1>
      <p className="mt-3 max-w-2xl text-base leading-7 text-muted-foreground">Search by everyday topic or keyword. Clear requirements help you decide which offer fits your situation.</p>

      {nearby && <div className="mt-5 flex items-center gap-3 rounded-2xl bg-secondary p-4"><MapPin className="h-5 w-5 text-primary" /><p className="text-sm font-bold">Showing services available in {profile.municipality || "the Canton of Lucerne"} and the surrounding region.</p></div>}

      <div className="soft-card mt-6 p-4 sm:p-5">
        <div className="flex flex-col gap-3 md:flex-row">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
            <label htmlFor="service-search" className="sr-only">Search services</label>
            <input id="service-search" className="form-input pl-12 pr-12" placeholder="Search German courses, housing, work…" value={query} onChange={(event) => setQuery(event.target.value)} />
            {query && <button type="button" className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full p-2 hover:bg-secondary" aria-label="Clear search" onClick={() => setQuery("")}><X className="h-4 w-4" /></button>}
          </div>
          <button type="button" className={cn("btn-secondary", onlyEligible && "border-primary bg-secondary text-primary")} aria-pressed={onlyEligible} onClick={() => setOnlyEligible((value) => !value)}><SlidersHorizontal className="h-4 w-4" />Only matching my answers</button>
        </div>
        <div className="mt-4 flex flex-wrap gap-2 pb-1">
          <button type="button" className={cn("chip min-h-10 shrink-0 px-4", !category && "bg-primary text-primary-foreground")} onClick={() => setCategory(null)}><Filter className="h-4 w-4" />All topics</button>
          {categories.map((item) => (
            <button key={item.id} type="button" className={cn("chip min-h-10 shrink-0 px-4", category === item.slug && "bg-primary text-primary-foreground")} onClick={() => setCategory(category === item.slug ? null : item.slug)}>
              <TopicIcon category={item.slug} className="h-4 w-4" />{item.name_i18n[profile.language] ?? item.name_i18n["en"] ?? item.name}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-6 flex items-center justify-between"><p className="text-sm font-extrabold">{services.length} {services.length === 1 ? "service" : "services"}</p><p className="text-xs text-muted-foreground">Free and paid offers are clearly marked.</p></div>
      {services.length > 0 ? <div className="mt-4 grid items-start gap-4 md:grid-cols-2 2xl:grid-cols-3">{services.map((service) => { const on = selected.has(service.id); return (
        <div key={service.id} className={cn("relative rounded-2xl", on && "ring-2 ring-primary")}>
          <ServiceCard service={service} showEligibility={Object.keys(searchProfile).length > 0} />
          <button type="button" aria-pressed={on} aria-label={on ? `Remove ${service.name} from my PDF` : `Add ${service.name} to my PDF`} onClick={() => toggle(service.id, service.category_slug ?? null)} className={cn("chip absolute bottom-4 right-4 min-h-9 border px-3", on ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card")}>
            {on ? <Check className="h-4 w-4" /> : <FileText className="h-4 w-4" />}{on ? "Selected" : "Add to PDF"}
          </button>
        </div>); })}</div> : <div className="soft-card mt-4 p-10 text-center"><Search className="mx-auto h-8 w-8 text-primary" /><h2 className="mt-4 font-display text-xl font-extrabold">No services found</h2><p className="mt-2 text-sm text-muted-foreground">Try another keyword, choose all topics, or turn off the eligibility filter.</p><button type="button" className="btn-secondary mt-5" onClick={() => { setQuery(""); setCategory(null); setOnlyEligible(false); }}>Clear all filters</button></div>}
      {selected.size > 0 && (
        <div className="fixed inset-x-3 bottom-24 z-50 flex flex-col gap-3 rounded-2xl border bg-card p-4 shadow-2xl sm:flex-row sm:items-center sm:justify-between md:sticky md:inset-x-auto md:bottom-4 md:mt-6">
          <p className="text-base font-extrabold">{selected.size} {selected.size === 1 ? "service" : "services"} selected</p>
          <div className="grid grid-cols-[auto_1fr] gap-2 sm:flex">
            <button type="button" className="btn-secondary min-h-14 px-5 text-base" onClick={() => { setSelected(new Map()); setPdfCode(""); }}>Clear</button>
            {pdfCode ? (
              <button type="button" className="btn-primary min-h-14 w-full px-6 text-base" disabled={downloading} onClick={downloadPdf}><Download className="h-4 w-4" />{downloading ? "Downloading…" : "Download my PDF"}</button>
            ) : (
              <button type="button" className="btn-primary min-h-14 w-full px-6 text-base" disabled={creating} onClick={createPdf}><FileText className="h-4 w-4" />{creating ? "Creating…" : "Create my PDF"}</button>
            )}
          </div>
        </div>
      )}
      <CallOfferDialog open={callOfferOpen} onOpenChange={setCallOfferOpen} language={profile.language} />
    </div>
  );
}
