import { Check, ChevronRight, ClipboardCheck, Download, Link2, Loader2, MapPin, Printer, Share2 } from "lucide-react";
import QRCode from "react-qr-code";
import { useState } from "react";
import { useHydrated, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { useGuide } from "@/lib/guide-context";
import { getCopy } from "@/lib/guide-copy";
import { buildChecklist, profileSummary } from "@/lib/guide-utils";
import type { GuideProfile, Service } from "@/lib/guide-types";
import { ServiceCard } from "./ServiceCard";
import { CallOfferDialog } from "./CallOfferDialog";
import { cn } from "@/lib/utils";

export function GuideOverview({ profile, services, onShare, shareCode, sharing = false, readOnly = false }: {
  profile: GuideProfile;
  services: Service[];
  onShare?: () => void;
  shareCode?: string;
  sharing?: boolean;
  readOnly?: boolean;
}) {
  const [callOfferOpen, setCallOfferOpen] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const { completedTasks, toggleTask } = useGuide();
  const copy = getCopy(profile.language);
  const checklist = buildChecklist(profile);
  const hydrated = useHydrated();
  const matching = profile.needs.length > 0 ? services.filter((service) => service.category_slug && profile.needs.includes(service.category_slug)) : services;
  const recommended = (matching.length > 0 ? matching : services).slice(0, 6);
  // The editor preview is private, so QR codes always point at the public site.
  const publicOrigin = hydrated ? (/id-preview--|lovableproject\.com|localhost/.test(window.location.host) ? "https://kunigo-readme-compass.lovable.app" : window.location.origin) : "";
  const shareUrl = hydrated && shareCode ? `${publicOrigin}/api/public/guide-pdf/${shareCode}` : "";

  const copyLink = async () => {
    if (!shareUrl) return;
    await navigator.clipboard.writeText(shareUrl);
    toast.success("PDF link copied");
  };

  // The video-call offer only appears once the PDF has actually been fetched and its download started.
  const downloadPdf = async () => {
    if (!shareCode) return;
    setDownloading(true);
    try {
      const response = await fetch(`/api/public/guide-pdf/${shareCode}`);
      if (!response.ok) throw new Error("PDF download failed");
      const blobUrl = URL.createObjectURL(await response.blob());
      const link = document.createElement("a");
      link.href = blobUrl;
      link.download = `triage-lucerne-guide-${shareCode}.pdf`;
      link.style.display = "none";
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.setTimeout(() => URL.revokeObjectURL(blobUrl), 1000);
      setCallOfferOpen(true);
    } catch {
      toast.error("The PDF could not be downloaded. Please try again.");
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="animate-enter">
      <div className="flex flex-col gap-5 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <p className="mb-2 text-xs font-extrabold uppercase tracking-[0.18em] text-primary">Personalised for you</p>
          <h1 className="page-title">{readOnly ? "A personal guide for Lucerne" : "Your personal guide for Lucerne"}</h1>
          <div className="mt-4 flex flex-wrap gap-2">
            {profileSummary(profile).map((item, index) => <span key={item} className="chip">{index === 3 && <MapPin className="h-3.5 w-3.5" />}{item}</span>)}
          </div>
        </div>
        <div className="no-print flex flex-wrap gap-2">
          {!readOnly && <Link to="/guide" className="btn-secondary min-h-10 px-4 py-2">Edit answers</Link>}
          {onShare && <button type="button" className="btn-secondary min-h-10 px-4 py-2" onClick={onShare} disabled={sharing}>{sharing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Share2 className="h-4 w-4" />}{copy.share}</button>}
          <button type="button" className="btn-secondary min-h-10 px-4 py-2" onClick={() => window.print()}><Printer className="h-4 w-4" />{copy.print}</button>
        </div>
      </div>

      <div className="mt-7 grid items-start gap-6 xl:grid-cols-[minmax(0,1.65fr)_minmax(280px,.75fr)]">
        <div className="grid items-start gap-6 xl:grid-cols-2">
          <section className="soft-card p-5 sm:p-6">
            <div className="flex items-center gap-3"><span className="icon-badge text-success"><ClipboardCheck className="h-6 w-6" /></span><div><h2 className="section-title">{copy.nextSteps}</h2><p className="mt-1 text-sm text-muted-foreground">A simple checklist to get started in Lucerne.</p></div></div>
            {checklist.length > 0 ? <>
              <div className="mt-5 flex items-center justify-between text-xs font-bold"><span>{completedTasks.filter((id) => checklist.some((item) => item.id === id)).length} of {checklist.length} {copy.completed}</span><span>{Math.round((completedTasks.filter((id) => checklist.some((item) => item.id === id)).length / checklist.length) * 100)}%</span></div>
              <div className="mt-2 h-2 overflow-hidden rounded-full bg-muted"><div className="h-full rounded-full bg-success transition-all" style={{ width: `${(completedTasks.filter((id) => checklist.some((item) => item.id === id)).length / checklist.length) * 100}%` }} /></div>
              <div className="mt-4 divide-y divide-border">
                {checklist.map((item) => {
                  const checked = completedTasks.includes(item.id);
                  return <button key={item.id} type="button" disabled={readOnly} className="flex w-full items-center gap-3 py-4 text-left disabled:cursor-default" onClick={() => toggleTask(item.id)}>
                    <span className={cn("flex h-5 w-5 shrink-0 items-center justify-center rounded-md border-2 border-input", checked && "border-success bg-success text-success-foreground")}>{checked && <Check className="h-3.5 w-3.5" />}</span>
                    <span className={cn("flex-1 text-sm font-bold leading-5", checked && "text-muted-foreground line-through")}>{item.title}</span><ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
                  </button>;
                })}
              </div>
            </> : <div className="mt-6 rounded-xl bg-secondary p-4 text-sm text-muted-foreground">Complete the guide and choose your topics to see next steps here.</div>}
          </section>

          <section>
            <div className="mb-4 flex items-center gap-3"><span className="icon-badge text-success"><MapPin className="h-6 w-6" /></span><div><h2 className="section-title">{copy.recommended}</h2><p className="mt-1 text-sm text-muted-foreground">Selected offers in Lucerne based on your situation and needs.</p></div></div>
            <div className="space-y-3">
              {recommended.map((service) => <ServiceCard key={service.id} service={service} compact showEligibility />)}
            </div>
            <Link to="/services" className="btn-secondary mt-4 w-full">Explore all services<ChevronRight className="h-4 w-4" /></Link>
          </section>
        </div>

        <aside className="soft-card no-print p-6 text-center xl:sticky xl:top-24">
          <span className="icon-badge mx-auto"><Share2 className="h-6 w-6" /></span>
          <h2 className="mt-4 font-display text-2xl font-black">Take your guide with you</h2>
          <p className="mx-auto mt-2 max-w-xs text-sm leading-6 text-muted-foreground">Scan the QR code with your phone to download your service list as one PDF — no sign-in needed.</p>
          <div className="mx-auto mt-6 flex min-h-52 max-w-56 items-center justify-center rounded-2xl border border-border bg-card p-5 shadow-sm">
            {shareUrl ? <QRCode value={shareUrl} size={184} /> : <button type="button" className="btn-primary" onClick={onShare} disabled={sharing || !onShare}>{sharing && <Loader2 className="h-4 w-4 animate-spin" />}Create my PDF QR code</button>}
          </div>
          {shareUrl && <button type="button" className="btn-primary mt-5 w-full" disabled={downloading} onClick={() => void downloadPdf()}>{downloading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}{downloading ? "Downloading…" : "Download PDF"}</button>}
          {shareUrl && <div className="mt-5 flex items-center gap-2 rounded-xl border border-border bg-background p-2 pl-3"><Link2 className="h-4 w-4 shrink-0 text-primary" /><span className="min-w-0 flex-1 truncate text-left text-xs font-bold">{shareUrl}</span><button type="button" className="btn-secondary min-h-9 px-3 py-1.5" onClick={() => void copyLink()}>Copy</button></div>}
          <p className="mt-5 text-xs leading-5 text-muted-foreground">The link contains only your topic and eligibility choices — never your name or contact details.</p>
        </aside>
      </div>
      <CallOfferDialog open={callOfferOpen} onOpenChange={setCallOfferOpen} language={profile.language} />
    </div>
  );
}
