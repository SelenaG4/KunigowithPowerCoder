import { Link, useLocation } from "@tanstack/react-router";
import { CheckSquare, Home, Info, MapPin, ShieldCheck } from "lucide-react";
import type { ReactNode } from "react";
import { Logo } from "./Logo";
import { LanguageSwitcher } from "./LanguageSwitcher";
import { useGuide } from "@/lib/guide-context";
import { getCopy } from "@/lib/guide-copy";
import { cn } from "@/lib/utils";

export function AppShell({ children }: { children: ReactNode }) {
  const { profile } = useGuide();
  const copy = getCopy(profile.language);
  const location = useLocation();
  const items = [
    { to: "/my-guide", label: copy.myGuide, icon: Home },
    { to: "/checklist", label: copy.checklist, icon: CheckSquare },
    { to: "/nearby", label: copy.nearby, icon: MapPin },
    { to: "/info", label: copy.info, icon: Info },
  ] as const;

  return (
    <div className="min-h-screen bg-background">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 flex-col border-r border-border bg-sidebar p-5 lg:flex">
        <Logo className="px-2 py-2" />
        <nav className="mt-10 space-y-2" aria-label="Main navigation">
          {items.map(({ to, label, icon: Icon }) => (
            <Link key={to} to={to} className={cn("nav-link", location.pathname === to && "nav-link-active")}>
              <Icon className="h-5 w-5" />{label}
            </Link>
          ))}
        </nav>
        <div className="mt-auto rounded-2xl bg-secondary p-4">
          <ShieldCheck className="h-6 w-6 text-primary" />
          <p className="mt-3 text-sm font-extrabold">Private by design</p>
          <p className="mt-1 text-xs leading-5 text-muted-foreground">No account is needed. Your answers stay in this browser session.</p>
        </div>
        <Link to="/admin" className="mt-3 px-2 text-xs font-bold text-muted-foreground hover:text-primary">Admin sign-in</Link>
      </aside>

      <div className="lg:pl-64">
        <header className="sticky top-0 z-20 flex items-center justify-between border-b border-border bg-background/95 px-4 py-3 backdrop-blur lg:justify-end lg:px-8">
          <div className="lg:hidden"><Logo compact /></div>
          <LanguageSwitcher />
        </header>
        <main className="mx-auto w-full max-w-[1500px] px-4 pb-28 pt-6 sm:px-6 lg:px-8 lg:pb-10 lg:pt-8">{children}</main>
      </div>

      <nav className="safe-bottom fixed inset-x-0 bottom-0 z-30 grid grid-cols-4 border-t border-border bg-card px-1 pt-2 shadow-lg lg:hidden" aria-label="Mobile navigation">
        {items.map(({ to, label, icon: Icon }) => (
          <Link key={to} to={to} className={cn("flex min-h-16 flex-col items-center justify-center gap-1 rounded-xl px-1 text-[10px] font-extrabold text-muted-foreground", location.pathname === to && "bg-secondary text-primary")}>
            <Icon className="h-5 w-5" /><span className="max-w-full truncate">{label}</span>
          </Link>
        ))}
      </nav>
    </div>
  );
}
