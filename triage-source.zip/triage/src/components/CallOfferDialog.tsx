import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { CallSchedule } from "@/components/CallSchedule";
import { TALK_COPY } from "@/lib/talk-copy";
import type { LanguageCode } from "@/lib/guide-types";

// Offered after a self-search person downloads their own PDF list.
// The schedule itself keeps date, time and question in local state only.
export function CallOfferDialog({
  open,
  onOpenChange,
  language,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  language: LanguageCode;
}) {
  const copy = TALK_COPY[language];
  const rtl = language === "ar";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className="max-h-[92vh] w-[min(96vw,46rem)] max-w-none gap-0 overflow-y-auto p-5 sm:p-7"
        aria-describedby="call-offer-description"
      >
        <DialogHeader className="pr-8 text-left" dir={rtl ? "rtl" : undefined}>
          <DialogTitle className="font-display text-xl font-extrabold sm:text-2xl">
            {copy.offerTitle}
          </DialogTitle>
          <DialogDescription id="call-offer-description" className="text-sm leading-6">
            {copy.offerText}
          </DialogDescription>
        </DialogHeader>
        <CallSchedule language={language} />
      </DialogContent>
    </Dialog>
  );
}
