import { useState } from "react";
import { Check, ChevronDown, Globe } from "lucide-react";
import { LANGUAGES } from "@/lib/guide-types";
import { useGuide } from "@/lib/guide-context";
import { cn } from "@/lib/utils";

export function LanguageSwitcher({ light = false }: { light?: boolean }) {
  const [open, setOpen] = useState(false);
  const { profile, updateProfile } = useGuide();

  return (
    <div className="relative">
      <button
        type="button"
        className={cn("language-button", light && "language-button-light")}
        aria-label="Choose language"
        aria-expanded={open}
        onClick={() => setOpen((value) => !value)}
      >
        <Globe className="h-4 w-4" />
        <span className="font-bold uppercase">{profile.language}</span>
        <ChevronDown className={cn("h-3.5 w-3.5 transition-transform", open && "rotate-180")} />
      </button>
      {open && (
        <div className="absolute right-0 top-[calc(100%+0.5rem)] z-50 max-h-80 w-56 overflow-y-auto rounded-2xl border border-border bg-popover p-2 shadow-lg">
          {LANGUAGES.map((language) => (
            <button
              key={language.code}
              type="button"
              className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-sm font-semibold hover:bg-secondary"
              onClick={() => {
                updateProfile({ language: language.code });
                setOpen(false);
              }}
            >
              <span aria-hidden="true">{language.flag}</span>
              <span className="flex-1">{language.label}</span>
              {profile.language === language.code && <Check className="h-4 w-4 text-primary" />}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
