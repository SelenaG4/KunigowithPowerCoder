import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/utils";
import logoAsset from "@/assets/triage-logo.png.asset.json";

export function Logo({ compact = false, className }: { compact?: boolean; className?: string }) {
  return (
    <Link to="/" className={cn("inline-flex items-center", className)} aria-label="Triage home">
      <img src={logoAsset.url} alt="Triage — Your path to the right support." className={cn("w-auto object-contain", compact ? "h-10" : "h-14")} />
    </Link>
  );
}
