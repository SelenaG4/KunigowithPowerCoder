import { useState } from "react";
import { CalendarDays, Clock3, Video, Eye, Pencil, MessageCircle } from "lucide-react";
import { de, enGB, fr, it } from "date-fns/locale";
import { Calendar } from "@/components/ui/calendar";
import { Button } from "@/components/ui/button";
import { ADMIN_ZOOM_BOOKING_URL, SCHEDULE_COPY, canRequestCall, defaultCallLanguage } from "@/lib/call-schedule";
import type { LanguageCode } from "@/lib/guide-types";
import { LANGUAGES } from "@/lib/guide-types";
import { PROTOTYPE_COPY } from "@/lib/schedule-prototype-copy";

const locales = { de, en: enGB, fr, it };

export function CallSchedule({ language }: { language: LanguageCode }) {
  // Date, time and question live in component state only; nothing is stored or sent.
  const [date, setDate] = useState<Date | undefined>();
  const [time, setTime] = useState("");
  const [question, setQuestion] = useState("");
  const [previewLanguage, setPreviewLanguage] = useState<LanguageCode | null>(null);
  const displayLanguage = defaultCallLanguage(language);
  const copy = SCHEDULE_COPY[displayLanguage];
  const prototype = PROTOTYPE_COPY[displayLanguage];
  const previewing = previewLanguage === language;
  const ready = canRequestCall({ date, time, question });
  const needsQuestion = Boolean(date && time) && question.trim().length === 0;

  return (
    <div className="mt-6 border-t border-border pt-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h3 className="flex items-center gap-2 font-display text-lg font-extrabold"><CalendarDays className="h-5 w-5 text-primary" />{copy.title}</h3>
        {!ADMIN_ZOOM_BOOKING_URL && <span className="text-xs font-bold text-muted-foreground">{prototype.badge}</span>}
      </div>
      <div className="mt-5 grid gap-6 lg:grid-cols-[minmax(280px,1fr)_minmax(0,1fr)]">
        <div className="min-w-0">
          <p className="mb-3 text-sm font-bold">{copy.date}</p>
          <Calendar mode="single" selected={date} onSelect={(nextDate) => { setDate(nextDate); setPreviewLanguage(null); }} weekStartsOn={1} locale={locales[displayLanguage]} className="mx-auto rounded-lg border border-border bg-card [--cell-size:2.25rem] sm:[--cell-size:2.5rem]" />
        </div>
        <div className="min-w-0 space-y-4">
          <label className="block text-sm font-bold">
            <span className="mb-3 flex items-center gap-2"><Clock3 className="h-4 w-4 text-primary" />{copy.time}</span>
            <input type="time" value={time} onChange={(event) => { setTime(event.target.value); setPreviewLanguage(null); }} className="form-input" />
          </label>
          <label className="block text-sm font-bold">
            <span className="mb-3 flex items-center gap-2"><MessageCircle className="h-4 w-4 text-primary" />{copy.question}</span>
            <textarea
              value={question}
              onChange={(event) => { setQuestion(event.target.value); setPreviewLanguage(null); }}
              placeholder={copy.questionHint}
              rows={4}
              className="form-input min-h-28 resize-y leading-6"
            />
          </label>
          {needsQuestion && <p className="text-xs font-bold text-destructive">{copy.questionRequired}</p>}
          <p className="text-xs text-muted-foreground">{copy.zone}</p>
          <div aria-live="polite" className="border-l-2 border-primary pl-4">
            <p className="flex items-center gap-2 text-sm font-bold"><Video className="h-4 w-4 text-primary" />{copy.admin} · Zoom</p>
            <p className="mt-2 break-words text-sm">{date ? new Intl.DateTimeFormat(displayLanguage, { dateStyle: "full" }).format(date) : copy.choose}{date && time ? ` · ${time}` : ""}</p>
            {question.trim() && <p className="mt-2 break-words text-sm"><span className="font-bold">{prototype.question}:</span> {question.trim()}</p>}
            <p className="mt-2 text-xs font-bold text-muted-foreground">{copy.draft}</p>
          </div>
          {ADMIN_ZOOM_BOOKING_URL && ready ? (
            <Button asChild className="h-auto min-h-14 w-full whitespace-normal py-3">
              <a href={ADMIN_ZOOM_BOOKING_URL} target="_blank" rel="noopener noreferrer" referrerPolicy="no-referrer"><Video />{copy.continue}</a>
            </Button>
          ) : ADMIN_ZOOM_BOOKING_URL ? <Button disabled className="h-auto min-h-14 w-full whitespace-normal py-3"><Video />{copy.continue}</Button> : (
            <Button disabled={!ready} onClick={() => setPreviewLanguage(language)} className="h-auto min-h-14 w-full whitespace-normal py-3"><Eye />{prototype.preview}</Button>
          )}
          {previewing && !ADMIN_ZOOM_BOOKING_URL && (
            <div role="status" className="space-y-3 border-y border-border py-5">
              <h4 className="font-display text-lg font-extrabold">{prototype.title}</h4>
              <p className="text-sm font-bold">{date ? new Intl.DateTimeFormat(displayLanguage, { dateStyle: "full" }).format(date) : ""} · {time}</p>
              <p className="text-sm">{prototype.language}: {LANGUAGES.find((item) => item.code === language)?.label}</p>
              <p className="break-words text-sm"><span className="font-bold">{prototype.question}:</span> {question.trim()}</p>
              <p className="flex items-center gap-2 text-sm"><Video className="h-4 w-4 text-primary" />{prototype.zoom}</p>
              <p className="text-sm leading-6 text-muted-foreground">{prototype.notice}</p>
              <Button variant="outline" className="min-h-12 h-auto whitespace-normal" onClick={() => setPreviewLanguage(null)}><Pencil />{prototype.edit}</Button>
            </div>
          )}
          {!previewing && <p className="text-sm leading-6 text-muted-foreground">{ADMIN_ZOOM_BOOKING_URL ? copy.note : prototype.notice}</p>}
        </div>
      </div>
    </div>
  );
}
