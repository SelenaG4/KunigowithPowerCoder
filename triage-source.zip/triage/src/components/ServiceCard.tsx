import { ArrowUpRight, CalendarCheck, CheckCircle2, CircleAlert } from "lucide-react";
import { Link } from "@tanstack/react-router";
import type { Service } from "@/lib/guide-types";
import { TOPICS } from "@/lib/guide-types";
import { TopicIcon } from "./TopicIcon";
import { cn } from "@/lib/utils";

const costLabels = { free: "Free", reduced: "Reduced cost", paid: "Paid", varies: "Cost varies" };

export function ServiceCard({ service, showEligibility = false, compact = false }: { service: Service; showEligibility?: boolean; compact?: boolean }) {
  const topic = TOPICS.find((item) => item.slug === service.category_slug);
  const category = topic?.label ?? service.category_slug?.replaceAll("-", " ") ?? "Local service";

  return (
    <Link to="/service/$slug" params={{ slug: service.slug }} className={cn("service-card group", compact && "p-4")}>
      <div className="flex items-start gap-4">
        <span className={cn("icon-badge", service.category_slug === "housing" && "text-warning", service.category_slug === "health-insurance" && "text-destructive", service.category_slug === "finances" && "text-success")}>
          <TopicIcon category={service.category_slug} />
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-[11px] font-extrabold uppercase tracking-wider text-muted-foreground">{category}</p>
              <h3 className="mt-1 font-display text-lg font-extrabold leading-tight text-foreground">{service.name}</h3>
            </div>
            <ArrowUpRight className="h-5 w-5 shrink-0 text-primary transition group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </div>
          <p className="mt-2 text-sm leading-6 text-muted-foreground">{service.short_description}</p>
          <p className="mt-2 text-xs font-bold text-foreground">{service.organisation_name}</p>
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <span className={cn("chip", service.cost_type === "free" && "bg-success-soft text-success")}>{costLabels[service.cost_type]}</span>
            {service.appointment_required && <span className="chip"><CalendarCheck className="h-3.5 w-3.5" />Appointment</span>}
            {showEligibility && (service.eligible ? (
              <span className="chip bg-success-soft text-success"><CheckCircle2 className="h-3.5 w-3.5" />Matches your answers</span>
            ) : (
              <span className="chip"><CircleAlert className="h-3.5 w-3.5" />Check requirements</span>
            ))}
          </div>
        </div>
      </div>
    </Link>
  );
}
