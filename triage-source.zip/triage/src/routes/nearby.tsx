import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { ServiceDirectory } from "@/components/ServiceDirectory";
import { categoriesQueryOptions, servicesQueryOptions } from "@/lib/service-queries";

const initialSearch = { language: "en", profile: {}, onlyEligible: false, limit: 50 };

export const Route = createFileRoute("/nearby")({
  loader: ({ context }) => Promise.all([
    context.queryClient.ensureQueryData(categoriesQueryOptions()),
    context.queryClient.ensureQueryData(servicesQueryOptions(initialSearch)),
  ]),
  head: () => ({
    meta: [
      { title: "Services near me — Triage Lucerne" },
      { name: "description", content: "Explore local and regional services available to residents of Emmen, Lucerne and surrounding municipalities." },
      { property: "og:title", content: "Services near me — Triage Lucerne" },
      { property: "og:description", content: "Find local Lucerne support available where you live." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: NearbyPage,
});

function NearbyPage() {
  return <AppShell><ServiceDirectory nearby /></AppShell>;
}
