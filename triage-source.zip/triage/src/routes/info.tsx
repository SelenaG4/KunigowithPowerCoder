import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, CheckCircle2, HeartHandshake, PlusCircle, Search, Share2, ShieldCheck } from "lucide-react";
import { AppShell } from "@/components/AppShell";

export const Route = createFileRoute("/info")({
  head: () => ({
    meta: [
      { title: "About Triage and privacy — Triage Lucerne" },
      { name: "description", content: "Learn how Triage helps people find local Lucerne support, protects privacy and keeps community service information current." },
      { property: "og:title", content: "About Triage Lucerne" },
      { property: "og:description", content: "Shared local knowledge, multilingual guidance and privacy without registration." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: InfoPage,
});

function InfoPage() {
  return (
    <AppShell>
      <div className="mx-auto max-w-5xl animate-enter">
        <p className="text-xs font-extrabold uppercase tracking-[0.18em] text-primary">About Triage</p>
        <h1 className="page-title mt-2">The right support should be easier to find.</h1>
        <p className="mt-4 max-w-3xl text-lg leading-8 text-muted-foreground">Triage is a shared public guide for people with a migration background, community key persons and local organisations in Lucerne.</p>
        <div className="mt-8 grid gap-4 md:grid-cols-3">
          <InfoCard icon={Search} title="Find" text="Search by everyday topic, language, cost and clear eligibility criteria instead of knowing an organisation's name." />
          <InfoCard icon={HeartHandshake} title="Guide" text="Answer six simple questions to receive a personal checklist and relevant local services." />
          <InfoCard icon={Share2} title="Share" text="Pass on a guide or offer with a short link or QR code — no names or contact details required." />
        </div>
        <section className="soft-card mt-8 p-6 sm:p-8">
          <div className="flex items-start gap-4"><span className="icon-badge"><ShieldCheck className="h-6 w-6" /></span><div><h2 className="section-title">Privacy by design</h2><p className="mt-2 text-sm leading-6 text-muted-foreground">You never need an account to search, create a guide or share it.</p></div></div>
          <div className="mt-6 grid gap-3 sm:grid-cols-2">
            {["No name, email or identity document is requested", "Guide answers stay in this browser session", "Checklist ticks stay on this device", "Shared links contain only service filters and choices"].map((item) => <p key={item} className="flex gap-3 rounded-xl bg-success-soft p-4 text-sm font-semibold"><CheckCircle2 className="h-5 w-5 shrink-0 text-success" />{item}</p>)}
          </div>
        </section>
        <section className="mt-8 overflow-hidden rounded-3xl bg-primary p-7 text-primary-foreground sm:p-10">
          <PlusCircle className="h-8 w-8" />
          <h2 className="mt-4 font-display text-3xl font-black">Know a helpful local offer?</h2>
          <p className="mt-3 max-w-2xl leading-7 opacity-90">Suggest a service so the whole community can benefit. Submissions are reviewed before they appear in the public directory.</p>
          <Link to="/submit" className="mt-6 inline-flex min-h-12 items-center justify-center gap-2 rounded-xl bg-card px-5 py-3 text-sm font-extrabold text-primary">Suggest a service<ArrowRight className="h-4 w-4" /></Link>
        </section>
        <p className="mt-6 text-xs leading-5 text-muted-foreground">The directory is populated from the supplied Fabia and Sentitreff workbooks. Details should be checked with each organisation; unclear rows remain private until reviewed.</p>
      </div>
    </AppShell>
  );
}

function InfoCard({ icon: Icon, title, text }: { icon: typeof Search; title: string; text: string }) {
  return <div className="soft-card p-6"><span className="icon-badge"><Icon className="h-6 w-6" /></span><h2 className="mt-5 font-display text-xl font-extrabold">{title}</h2><p className="mt-2 text-sm leading-6 text-muted-foreground">{text}</p></div>;
}
