import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { GuideOverview } from "@/components/GuideOverview";
import { servicesQueryOptions } from "@/lib/service-queries";
import { createSharedGuide } from "@/lib/services.functions";
import { useGuide } from "@/lib/guide-context";
import { shareableFilters, toSearchProfile } from "@/lib/guide-utils";

const initialSearch = { language: "en", profile: {}, onlyEligible: false, limit: 50 };

export const Route = createFileRoute("/my-guide")({
  loader: ({ context }) => context.queryClient.ensureQueryData(servicesQueryOptions(initialSearch)),
  head: () => ({
    meta: [
      { title: "My personal Lucerne guide — Triage" },
      { name: "description", content: "Your personalised next steps, recommended Lucerne services, checklist and shareable QR guide." },
      { property: "og:title", content: "My personal Lucerne guide — Triage" },
      { property: "og:description", content: "Recommended local services and practical next steps for your situation in Lucerne." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: MyGuide,
});

function MyGuide() {
  const { profile, hasCompletedGuide } = useGuide();
  const [shareCode, setShareCode] = useState("");
  const [sharing, setSharing] = useState(false);
  const createShare = useServerFn(createSharedGuide);
  const { data: services } = useSuspenseQuery(servicesQueryOptions({
    language: profile.language,
    profile: toSearchProfile(profile),
    onlyEligible: false,
    limit: 50,
  }));

  const share = async () => {
    setSharing(true);
    try {
      const result = await createShare({ data: {
        language: profile.language,
        filters: shareableFilters(profile),
        serviceIds: services.map((service) => service.id),
      } });
      setShareCode(result.code);
      toast.success("Your private guide link is ready");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "The guide could not be shared");
    } finally {
      setSharing(false);
    }
  };

  return (
    <AppShell>
      {!hasCompletedGuide && <div className="mb-6 flex flex-col gap-3 rounded-2xl bg-secondary p-4 sm:flex-row sm:items-center sm:justify-between"><p className="text-sm font-bold">Answer six questions to make these recommendations your own.</p><Link to="/guide" className="btn-primary min-h-10 px-4 py-2">Create my guide</Link></div>}
      <GuideOverview profile={profile} services={services} onShare={() => void share()} shareCode={shareCode} sharing={sharing} />
    </AppShell>
  );
}
