import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Globe2, Hand, HeartHandshake, MapPin, Search, ShieldCheck, Signpost } from "lucide-react";
import { Logo } from "@/components/Logo";
import { LanguageSwitcher } from "@/components/LanguageSwitcher";
import { useGuide } from "@/lib/guide-context";
import { getCopy } from "@/lib/guide-copy";
import heroAsset from "@/assets/lucerne-chapel-bridge.png.asset.json";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Triage Lucerne — Welcome" },
      { name: "description", content: "Create a personal guide to local services in Lucerne or search the multilingual service directory without registering." },
      { property: "og:title", content: "Welcome to Triage Lucerne" },
      { property: "og:description", content: "Simple, accessible guidance to the right local support in Lucerne." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  const { profile } = useGuide();
  const copy = getCopy(profile.language);

  return (
    <main className="min-h-screen bg-background px-3 py-3 sm:px-6 sm:py-6 lg:flex lg:items-center lg:justify-center">
      <div className="mx-auto w-full max-w-6xl overflow-hidden rounded-[1.75rem] border border-border bg-card shadow-[0_24px_80px_color-mix(in_oklch,var(--color-navy)_12%,transparent)] lg:grid lg:min-h-[720px] lg:grid-cols-[1.08fr_1fr]">
        <section className="relative min-h-64 overflow-hidden lg:min-h-full">
          <img src={heroAsset.url} alt="Lucerne's Chapel Bridge, water tower and mountains" className="absolute inset-0 h-full w-full object-cover" />
          <div className="absolute inset-0 bg-navy/10" />
          <div className="absolute left-5 top-5 sm:left-7 sm:top-7">
            <Logo />
          </div>
          <div className="absolute bottom-5 left-5 right-5 rounded-2xl bg-card/95 p-4 shadow-lg backdrop-blur sm:bottom-7 sm:left-7 sm:right-7">
            <div className="flex items-center gap-3">
              <span className="icon-badge h-11 w-11"><HeartHandshake className="h-5 w-5" /></span>
              <p className="text-sm font-bold leading-snug text-foreground">Local knowledge, shared with everyone.</p>
            </div>
          </div>
        </section>

        <section className="flex flex-col px-5 py-7 sm:px-9 sm:py-10 lg:justify-center lg:px-12">
          <div className="mb-8 flex items-center justify-between lg:mb-12">
            <span className="lg:hidden" />
            <div className="hidden items-center gap-2 text-sm font-bold text-muted-foreground lg:flex"><MapPin className="h-4 w-4 text-primary" /> Lucerne, Switzerland</div>
            <LanguageSwitcher />
          </div>

          <div className="animate-enter">
            <div className="mb-3 flex items-center gap-2 text-3xl"><span aria-hidden="true">👋</span><span className="text-sm font-extrabold uppercase tracking-[0.18em] text-primary">Triage Lucerne</span></div>
            <h1 className="text-balance font-display text-4xl font-black leading-[1.08] tracking-tight text-foreground sm:text-5xl">{copy.welcome}</h1>
            <p className="mt-5 max-w-xl text-base font-medium leading-7 text-muted-foreground sm:text-lg">{copy.intro}</p>

            <div className="mt-8 space-y-3">
              <Link to="/guide" className="group flex items-center gap-4 rounded-2xl bg-primary p-4 text-primary-foreground shadow-[0_10px_25px_color-mix(in_oklch,var(--color-primary)_25%,transparent)] transition hover:opacity-95">
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary-foreground/15"><Signpost className="h-6 w-6" /></span>
                <span className="min-w-0 flex-1">
                  <span className="block font-display text-lg font-extrabold">{copy.create}</span>
                  <span className="mt-0.5 block text-xs font-medium opacity-85">{copy.createHint}</span>
                </span>
                <ArrowRight className="h-5 w-5 shrink-0 transition group-hover:translate-x-1" />
              </Link>

              <Link to="/services" className="group flex items-center gap-4 rounded-2xl border border-border bg-card p-4 shadow-sm transition hover:border-primary hover:bg-secondary">
                <span className="icon-badge"><Search className="h-6 w-6" /></span>
                <span className="min-w-0 flex-1">
                  <span className="block font-display text-lg font-extrabold">{copy.search}</span>
                  <span className="mt-0.5 block text-xs font-medium text-muted-foreground">{copy.searchHint}</span>
                </span>
                <ArrowRight className="h-5 w-5 shrink-0 text-primary transition group-hover:translate-x-1" />
              </Link>
            </div>
          </div>

          <div className="mt-9 grid grid-cols-3 gap-2 border-t border-border pt-6">
            <div className="text-center"><Globe2 className="mx-auto h-5 w-5 text-primary" /><span className="mt-2 block text-[11px] font-extrabold sm:text-xs">{copy.multilingual}</span></div>
            <div className="text-center"><MapPin className="mx-auto h-5 w-5 text-primary" /><span className="mt-2 block text-[11px] font-extrabold sm:text-xs">{copy.local}</span></div>
            <div className="text-center"><ShieldCheck className="mx-auto h-5 w-5 text-primary" /><span className="mt-2 block text-[11px] font-extrabold sm:text-xs">{copy.noRegistration}</span></div>
          </div>
          <div className="mt-6 flex items-center justify-center gap-2 text-xs font-semibold text-muted-foreground lg:hidden"><Hand className="h-4 w-4" /> Made for your phone, no account needed.</div>
        </section>
      </div>
    </main>
  );
}
