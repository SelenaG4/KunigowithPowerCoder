import { createFileRoute, Link } from "@tanstack/react-router";
import { Check, CheckSquare, ChevronRight, RotateCcw } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { useGuide } from "@/lib/guide-context";
import { buildChecklist } from "@/lib/guide-utils";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/checklist")({
  head: () => ({
    meta: [
      { title: "My Lucerne checklist — Triage" },
      { name: "description", content: "Track practical next steps for registration, health insurance, permits, language courses and life in Lucerne." },
      { property: "og:title", content: "My Lucerne checklist — Triage" },
      { property: "og:description", content: "A simple personal checklist for getting started in Lucerne." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ChecklistPage,
});

function ChecklistPage() {
  const { profile, completedTasks, toggleTask } = useGuide();
  const items = buildChecklist(profile);
  const completed = items.filter((item) => completedTasks.includes(item.id)).length;

  return (
    <AppShell>
      <div className="mx-auto max-w-4xl animate-enter">
        <p className="text-xs font-extrabold uppercase tracking-[0.18em] text-primary">One step at a time</p>
        <h1 className="page-title mt-2">My checklist</h1>
        <p className="mt-3 text-muted-foreground">Your ticks are saved only on this device. No account or personal details are needed.</p>
        <section className="soft-card mt-7 p-5 sm:p-7">
          <div className="flex items-center gap-4"><span className="icon-badge text-success"><CheckSquare className="h-6 w-6" /></span><div className="flex-1"><h2 className="section-title">Getting started in {profile.municipality || "Lucerne"}</h2><p className="mt-1 text-sm text-muted-foreground">{completed} of {items.length} completed</p></div><span className="font-display text-2xl font-black text-primary">{items.length ? Math.round((completed / items.length) * 100) : 0}%</span></div>
          <div className="mt-5 h-2 overflow-hidden rounded-full bg-muted"><div className="h-full bg-success transition-all" style={{ width: `${items.length ? (completed / items.length) * 100 : 0}%` }} /></div>
          {items.length > 0 ? <div className="mt-5 divide-y divide-border">{items.map((item) => {
            const checked = completedTasks.includes(item.id);
            return <div key={item.id} className="flex items-start gap-4 py-5"><button type="button" className={cn("mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border-2 border-input", checked && "border-success bg-success text-success-foreground")} aria-label={`${checked ? "Uncheck" : "Check"} ${item.title}`} onClick={() => toggleTask(item.id)}>{checked && <Check className="h-4 w-4" />}</button><div className="flex-1"><h3 className={cn("font-display text-lg font-extrabold", checked && "text-muted-foreground line-through")}>{item.title}</h3><p className="mt-1 text-sm leading-6 text-muted-foreground">{item.description}</p><Link to="/services" className="mt-3 inline-flex items-center gap-1 text-sm font-extrabold text-primary">Find related services<ChevronRight className="h-4 w-4" /></Link></div></div>;
          })}</div> : <div className="mt-7 rounded-2xl bg-secondary p-8 text-center"><p className="font-bold">Your personalised checklist starts with a few answers.</p><Link to="/guide" className="btn-primary mt-5">Create my guide</Link></div>}
        </section>
        {completed > 0 && <button type="button" className="btn-secondary mt-5" onClick={() => items.filter((item) => completedTasks.includes(item.id)).forEach((item) => toggleTask(item.id))}><RotateCcw className="h-4 w-4" />Reset checklist</button>}
      </div>
    </AppShell>
  );
}
