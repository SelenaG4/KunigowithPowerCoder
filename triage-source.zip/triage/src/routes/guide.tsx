import { useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import {
  ArrowLeft, ArrowRight, Baby, BriefcaseBusiness, Check, ChevronDown, CircleHelp,
  FileText, Globe2, GraduationCap, HandHeart, Heart, Home, Languages, Layers3,
  MapPin, MoreHorizontal, Plane, Search, Users, X, type LucideIcon,
} from "lucide-react";
import { LanguageSwitcher } from "@/components/LanguageSwitcher";
import { useGuide } from "@/lib/guide-context";
import { getCopy } from "@/lib/guide-copy";
import { LANGUAGES, MUNICIPALITIES, TOPICS } from "@/lib/guide-types";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/guide")({
  head: () => ({
    meta: [
      { title: "Create your personal guide — Triage Lucerne" },
      { name: "description", content: "Answer six simple questions to find relevant services and next steps in Lucerne." },
      { property: "og:title", content: "Create your Triage personal guide" },
      { property: "og:description", content: "A few answers help Triage recommend local Lucerne services for your situation." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: GuideWizard,
});

const topicIcons: Record<string, LucideIcon> = {
  users: Users, heart: Heart, briefcase: BriefcaseBusiness, graduation: GraduationCap,
  home: Home, languages: Languages, family: Baby, file: FileText, support: HandHeart, more: MoreHorizontal,
};

function Choice({ icon: Icon, title, subtitle, selected, onClick }: {
  icon?: LucideIcon; title: string; subtitle?: string; selected: boolean; onClick: () => void;
}) {
  return (
    <button type="button" className={cn("choice-card", selected && "choice-card-selected")} onClick={onClick} aria-pressed={selected}>
      {Icon && <span className={cn("icon-badge", selected && "bg-card")}><Icon className="h-6 w-6" /></span>}
      <span className="min-w-0 flex-1"><span className="block font-display text-base font-extrabold">{title}</span>{subtitle && <span className="mt-1 block text-xs leading-5 text-muted-foreground">{subtitle}</span>}</span>
      {selected && <span className="choice-check"><Check className="h-4 w-4" /></span>}
    </button>
  );
}

function GuideWizard() {
  const [step, setStep] = useState(1);
  const { profile, updateProfile, setHasCompletedGuide } = useGuide();
  const navigate = useNavigate();
  const copy = getCopy(profile.language);

  const canContinue =
    step === 1 ? Boolean(profile.language) :
    step === 2 ? Boolean(profile.citizenship) :
    step === 3 ? Boolean(profile.municipality) :
    step === 4 ? Boolean(profile.arrivalStage) :
    step === 5 ? Boolean(profile.permit) : profile.needs.length > 0;

  const next = () => {
    if (!canContinue) return;
    if (step < 6) setStep((value) => value + 1);
    else {
      setHasCompletedGuide(true);
      void navigate({ to: "/my-guide" });
    }
  };

  return (
    <main className="min-h-screen bg-background px-3 py-3 sm:px-6 sm:py-6">
      <div className="mx-auto flex min-h-[calc(100vh-1.5rem)] w-full max-w-2xl flex-col rounded-[1.75rem] border border-border bg-card p-4 shadow-[0_18px_60px_color-mix(in_oklch,var(--color-navy)_9%,transparent)] sm:p-7">
        <div className="flex items-center justify-between">
          <button type="button" className="flex h-10 w-10 items-center justify-center rounded-full hover:bg-secondary" aria-label="Go back" onClick={() => step === 1 ? void navigate({ to: "/" }) : setStep((value) => value - 1)}><ArrowLeft className="h-5 w-5" /></button>
          <LanguageSwitcher />
        </div>

        <div className="mt-4">
          <p className="text-sm font-extrabold">Step {step} of 6</p>
          <div className="mt-3 grid grid-cols-6 gap-2" aria-label={`Step ${step} of 6`}>
            {[1, 2, 3, 4, 5, 6].map((item) => <span key={item} className={cn("h-1.5 rounded-full bg-muted", item < step && "bg-success", item === step && "bg-primary")} />)}
          </div>
        </div>

        <div key={step} className="animate-enter mt-7 flex-1">
          {step === 1 && <>
            <StepHeading icon={Languages} title="Choose your language" description="Select the language for the entire guide." />
            <div className="space-y-2">
              {LANGUAGES.map((language) => (
                <button key={language.code} type="button" className={cn("choice-card py-3", profile.language === language.code && "choice-card-selected")} onClick={() => updateProfile({ language: language.code })}>
                  <span className="w-8 text-2xl" aria-hidden="true">{language.flag}</span><span className="flex-1 font-bold">{language.label}</span>
                  {profile.language === language.code && <span className="choice-check"><Check className="h-4 w-4" /></span>}
                </button>
              ))}
            </div>
          </>}

          {step === 2 && <>
            <StepHeading icon={Globe2} title="What is your citizenship?" description="Select your citizenship to help us find the right services for you." />
            <div className="space-y-3">
              <Choice icon={Globe2} title="EU / EFTA citizen" subtitle="e.g. Germany, France, Italy, Norway, Spain" selected={profile.citizenship === "eu_efta"} onClick={() => updateProfile({ citizenship: "eu_efta" })} />
              <Choice icon={Globe2} title="Non-EU / EFTA citizen" subtitle="e.g. India, Türkiye, Brazil" selected={profile.citizenship === "non_eu_efta"} onClick={() => updateProfile({ citizenship: "non_eu_efta" })} />
              <Choice icon={CircleHelp} title="I'm not sure" subtitle="Help me understand my situation" selected={profile.citizenship === "unsure"} onClick={() => updateProfile({ citizenship: "unsure" })} />
            </div>
            <Hint title="Why do we ask this?" text="Citizenship can affect residence requirements and access to certain services in Switzerland." />
          </>}

          {step === 3 && <>
            <StepHeading icon={MapPin} title="Where do you live?" description="Enter your city or village and we'll automatically show the canton." />
            <label className="form-label" htmlFor="municipality">City or village</label>
            <div className="relative">
              <Search className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
              <input id="municipality" className="form-input pl-12 pr-12" value={profile.municipality} onChange={(event) => updateProfile({ municipality: event.target.value })} placeholder="e.g. Emmen" autoComplete="address-level2" />
              {profile.municipality && <button type="button" className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full p-2 hover:bg-secondary" aria-label="Clear location" onClick={() => updateProfile({ municipality: "" })}><X className="h-4 w-4" /></button>}
            </div>
            <div className="mt-4 space-y-2">
              {MUNICIPALITIES.filter((item) => item.toLowerCase().includes(profile.municipality.toLowerCase())).slice(0, 4).map((municipality) => (
                <Choice key={municipality} icon={MapPin} title={municipality} subtitle="Canton of Lucerne (LU)" selected={profile.municipality === municipality} onClick={() => updateProfile({ municipality })} />
              ))}
            </div>
            <p className="mt-5 flex items-center gap-2 text-sm font-semibold text-muted-foreground"><MapPin className="h-4 w-4 text-primary" /> Can't find your location? Enter it manually above.</p>
          </>}

          {step === 4 && <>
            <StepHeading icon={Layers3} title="What is your current situation?" description="Tell us about your stay in Lucerne for more relevant information." />
            <h3 className="mb-3 text-sm font-extrabold">How long have you been in Switzerland?</h3>
            <div className="space-y-3">
              <Choice icon={Layers3} title="Just arrived" subtitle="Less than 3 months" selected={profile.arrivalStage === "just-arrived"} onClick={() => updateProfile({ arrivalStage: "just-arrived" })} />
              <Choice icon={Layers3} title="Moved recently" subtitle="3 to 12 months ago" selected={profile.arrivalStage === "recent"} onClick={() => updateProfile({ arrivalStage: "recent" })} />
              <Choice icon={Home} title="Already living here" subtitle="More than 1 year" selected={profile.arrivalStage === "settled"} onClick={() => updateProfile({ arrivalStage: "settled" })} />
              <Choice icon={Plane} title="Planning to move" subtitle="I'm not living in Switzerland yet" selected={profile.arrivalStage === "planning"} onClick={() => updateProfile({ arrivalStage: "planning" })} />
            </div>
          </>}

          {step === 5 && <>
            <StepHeading icon={FileText} title="Do you have a residence permit?" description="This helps us check which services may be open to you. You can also choose 'Not sure'." />
            <label className="form-label" htmlFor="permit">Residence permit (if you have one)</label>
            <div className="relative">
              <FileText className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
              <select id="permit" className="form-input appearance-none pl-12 pr-12" value={profile.permit} onChange={(event) => updateProfile({ permit: event.target.value })}>
                <option value="">Select your permit type</option>
                {["B", "C", "L", "F", "N", "S", "G", "Ci"].map((permit) => <option key={permit} value={permit}>Permit {permit}</option>)}
                <option value="none">No valid residence permit</option>
                <option value="unsure">Not sure</option>
              </select>
              <ChevronDown className="pointer-events-none absolute right-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
            </div>
            <Hint title="Your answer stays private" text="We use this only to match services during this session. We never ask for your name or identity document." />
          </>}

          {step === 6 && <>
            <StepHeading icon={Layers3} title="What do you need help with?" description="Choose one or more topics to get personalised guidance and services." />
            <div className="grid gap-3 sm:grid-cols-2">
              {TOPICS.map((topic) => {
                const selected = profile.needs.includes(topic.slug);
                const Icon = topicIcons[topic.icon] ?? MoreHorizontal;
                return <Choice key={topic.slug} icon={Icon} title={topic.label} selected={selected} onClick={() => updateProfile({ needs: selected ? profile.needs.filter((item) => item !== topic.slug) : [...profile.needs, topic.slug] })} />;
              })}
            </div>
          </>}
        </div>

        <div className="mt-8 flex items-center justify-between gap-3 border-t border-border pt-5">
          <button type="button" className="btn-secondary" onClick={() => step === 1 ? void navigate({ to: "/" }) : setStep((value) => value - 1)}><ArrowLeft className="h-4 w-4" />{copy.back}</button>
          <button type="button" className="btn-primary min-w-36" disabled={!canContinue} onClick={next}>{step === 6 ? copy.showGuide : copy.continue}<ArrowRight className="h-4 w-4" /></button>
        </div>
      </div>
    </main>
  );
}

function StepHeading({ icon: Icon, title, description }: { icon: LucideIcon; title: string; description: string }) {
  return <div className="mb-6 flex items-start gap-4"><span className="icon-badge"><Icon className="h-7 w-7" /></span><div><h1 className="font-display text-2xl font-black leading-tight tracking-tight">{title}</h1><p className="mt-2 text-sm font-medium leading-6 text-muted-foreground">{description}</p></div></div>;
}

function Hint({ title, text }: { title: string; text: string }) {
  return <div className="mt-5 flex gap-3 rounded-2xl bg-secondary p-4"><CircleHelp className="h-5 w-5 shrink-0 text-primary" /><div><p className="text-sm font-extrabold">{title}</p><p className="mt-1 text-xs leading-5 text-muted-foreground">{text}</p></div></div>;
}
