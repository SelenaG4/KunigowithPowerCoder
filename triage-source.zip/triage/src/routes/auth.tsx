import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Lock } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Logo } from "@/components/Logo";

export const Route = createFileRoute("/auth")({
  validateSearch: (s: Record<string, unknown>) => ({ redirect: typeof s["redirect"] === "string" && s["redirect"].startsWith("/") ? s["redirect"] : "/admin" }),
  head: () => ({
    meta: [
      { title: "Admin sign-in — Triage Lucerne" },
      { name: "description", content: "Sign in to manage the Triage Lucerne service directory." },
      { property: "og:title", content: "Admin sign-in — Triage Lucerne" },
      { property: "og:description", content: "Sign in to manage the Triage Lucerne service directory." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const { redirect } = Route.useSearch();
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      if (mode === "signin") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        navigate({ to: redirect });
      } else {
        const { error } = await supabase.auth.signUp({ email, password, options: { emailRedirectTo: `${window.location.origin}/auth` } });
        if (error) throw error;
        toast.success("Check your email to confirm your account, then sign in.");
        setMode("signin");
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Sign-in failed");
    } finally { setBusy(false); }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <form onSubmit={submit} className="soft-card w-full max-w-md p-8">
        <Logo />
        <div className="mt-6 flex items-center gap-2"><Lock className="h-5 w-5 text-primary" /><h1 className="font-display text-2xl font-extrabold">{mode === "signin" ? "Admin sign-in" : "Create admin account"}</h1></div>
        <p className="mt-2 text-sm text-muted-foreground">For the team that manages the service directory. Visitors don't need an account.</p>
        <label className="mt-6 block text-sm font-bold" htmlFor="email">Email</label>
        <input id="email" type="email" required className="form-input mt-2" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
        <label className="mt-4 block text-sm font-bold" htmlFor="password">Password</label>
        <input id="password" type="password" required minLength={8} className="form-input mt-2" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete={mode === "signin" ? "current-password" : "new-password"} />
        <button type="submit" className="btn-primary mt-6 min-h-12 w-full" disabled={busy}>{busy ? "Please wait…" : mode === "signin" ? "Sign in" : "Create account"}</button>
        <button type="button" className="mt-4 w-full text-sm font-bold text-primary" onClick={() => setMode(mode === "signin" ? "signup" : "signin")}>{mode === "signin" ? "No account yet? Create one" : "Already have an account? Sign in"}</button>
      </form>
    </div>
  );
}
