import { createFileRoute } from "@tanstack/react-router";
import { createClient } from "@supabase/supabase-js";
import { buildChecklist, filtersFromSharedGuide } from "@/lib/guide-utils";
import type { ShareFilters } from "@/lib/guide-types";

const FONT_BASE = "https://cdn.jsdelivr.net/gh/notofonts/notofonts.github.io/fonts/NotoSans/hinted/ttf";

type Row = { id: string; name: string; short_description: string | null; direct_url: string | null; contact_details: Record<string, unknown> | null; organisation_id: string | null; category_id: string | null };

export const Route = createFileRoute("/api/public/guide-pdf/$code")({
  server: {
    handlers: {
      GET: async ({ params }) => {
        if (!/^[a-f0-9]{8}$/.test(params.code)) return new Response("Not found", { status: 404 });
        const db = createClient(process.env["SUPABASE_URL"]!, process.env["SUPABASE_PUBLISHABLE_KEY"]!, { auth: { persistSession: false } });
        const { data: guide } = await db.from("shared_guides").select("code, language, filters, service_ids").eq("code", params.code).maybeSingle();
        if (!guide) return new Response("Not found", { status: 404 });
        const ids = ((guide.service_ids as string[] | null) ?? []).slice(0, 80);
        // Arabic needs right-to-left shaping the PDF font cannot do; fall back to English there.
        const language = guide.language === "ar" ? "en" : String(guide.language);
        const { data: rows } = ids.length ? await db.from("services").select("id, name, short_description, direct_url, contact_details, organisation_id, category_id").in("id", ids).eq("service_status", "active") : { data: [] };
        const services = (rows ?? []) as unknown as Row[];
        const orgIds = [...new Set(services.map((s) => s.organisation_id).filter(Boolean))] as string[];
        const catIds = [...new Set(services.map((s) => s.category_id).filter(Boolean))] as string[];
        const { data: cats } = catIds.length ? await db.from("categories").select("id, slug").in("id", catIds) : { data: [] as { id: string; slug: string }[] };
        const catSlug = new Map((cats ?? []).map((c) => [c.id, c.slug]));
        const [{ data: orgs }, { data: tr }] = await Promise.all([
          orgIds.length ? db.from("organisations").select("id, name, address").in("id", orgIds) : Promise.resolve({ data: [] as { id: string; name: string; address: string | null }[] }),
          language !== "de" && ids.length ? db.from("translations").select("service_id, translated_name, translated_short_description").eq("language", language).in("service_id", ids) : Promise.resolve({ data: [] as { service_id: string; translated_name: string | null; translated_short_description: string | null }[] }),
        ]);
        const orgMap = new Map((orgs ?? []).map((o) => [o.id, o]));
        const trMap = new Map((tr ?? []).map((t) => [t.service_id, t]));
        const ordered = ids.map((id) => services.find((s) => s.id === id)).filter(Boolean) as Row[];

        const { PDFDocument, rgb } = await import("pdf-lib");
        const fontkit = (await import("@pdf-lib/fontkit")).default;
        const pdf = await PDFDocument.create();
        pdf.registerFontkit(fontkit);
        const load = async (w: string) => pdf.embedFont(await (await fetch(`${FONT_BASE}/NotoSans-${w}.ttf`)).arrayBuffer(), { subset: true });
        const [reg, bold] = await Promise.all([load("Regular"), load("Bold")]);
        const W = 595, H = 842, M = 50, maxW = W - 2 * M;
        let page = pdf.addPage([W, H]);
        let y = H - M;
        const clean = (t: string) => t.replace(/\s+/g, " ").trim();
        const wrap = (text: string, font: typeof reg, size: number) => {
          const lines: string[] = []; let line = "";
          for (const word of clean(text).split(" ")) {
            const next = line ? `${line} ${word}` : word;
            if (font.widthOfTextAtSize(next, size) > maxW && line) { lines.push(line); line = word; } else line = next;
          }
          if (line) lines.push(line);
          return lines;
        };
        const write = (text: string, font: typeof reg, size: number, color = rgb(0.1, 0.12, 0.16)) => {
          for (const l of wrap(text, font, size)) {
            if (y < M + size) { page = pdf.addPage([W, H]); y = H - M; }
            page.drawText(l, { x: M, y: y - size, size, font, color });
            y -= size * 1.4;
          }
        };
        const listOnly = (guide.filters as Record<string, unknown> | null)?.["pdf_mode"] === "list";
        const steps = listOnly ? [] : buildChecklist(filtersFromSharedGuide({ filters: (guide.filters ?? {}) as ShareFilters, language: String(guide.language) }));
        const used = new Set<string>();
        const groups = steps.map((st) => {
          const list = ordered.filter((s) => !used.has(s.id) && s.category_id && catSlug.get(s.category_id) === st.category);
          list.forEach((s) => used.add(s.id));
          return { title: st.title, description: st.description, list };
        });
        const rest = ordered.filter((s) => !used.has(s.id));
        if (rest.length) groups.push({ title: groups.length ? "Other helpful services" : "Contact the services that fit you", description: "Look through these offers and contact the ones that match your situation.", list: rest });

        const writeService = (s: Row) => {
          const t = trMap.get(s.id); const org = s.organisation_id ? orgMap.get(s.organisation_id) : undefined;
          const c = s.contact_details ?? {};
          if (y < M + 70) { page = pdf.addPage([W, H]); y = H - M; }
          write(`• ${t?.translated_name ?? s.name}`, bold, 11);
          if (org?.name) write(org.name, reg, 9.5, rgb(0.35, 0.35, 0.4));
          const desc = t?.translated_short_description ?? s.short_description;
          if (desc) write(desc, reg, 9.5);
          const contact = [org?.address, typeof c["phone"] === "string" ? c["phone"] : null, typeof c["email"] === "string" ? c["email"] : null, s.direct_url].filter(Boolean).join(" · ");
          if (contact) write(contact, reg, 8.5, rgb(0.1, 0.35, 0.6));
          y -= 6;
        };

        if (listOnly) {
          write("Triage Lucerne — your service list", bold, 20);
          write(`${ordered.length} ${ordered.length === 1 ? "service" : "services"} · ${new Date().toISOString().slice(0, 10)}`, reg, 10, rgb(0.4, 0.4, 0.45));
          y -= 10;
          ordered.forEach(writeService);
        } else {
        write("Triage Lucerne — your next steps", bold, 20);
        write(`${groups.length} ${groups.length === 1 ? "step" : "steps"} · ${ordered.length} services · ${new Date().toISOString().slice(0, 10)}`, reg, 10, rgb(0.4, 0.4, 0.45));
        y -= 6;
        write("Overview", bold, 13);
        groups.forEach((g, i) => write(`[  ]  Step ${i + 1}: ${g.title}`, reg, 10.5));
        y -= 12;
        groups.forEach((g, i) => {
          if (y < M + 120) { page = pdf.addPage([W, H]); y = H - M; }
          page.drawRectangle({ x: M, y: y - 4, width: maxW, height: 1, color: rgb(0.1, 0.35, 0.6) });
          y -= 12;
          write(`Step ${i + 1}: ${g.title}`, bold, 14.5, rgb(0.1, 0.35, 0.6));
          write(`What to do: ${g.description}`, reg, 10);
          y -= 4;
          if (g.list.length) { write("Where to get help:", bold, 10.5); g.list.forEach(writeService); }
          else write("Ask any general advice service in the list for help with this step.", reg, 9.5, rgb(0.4, 0.4, 0.45));
          y -= 10;
        });
        }
        const bytes = await pdf.save();
        return new Response(bytes as unknown as BodyInit, { headers: { "Content-Type": "application/pdf", "Content-Disposition": `attachment; filename="triage-lucerne-services-${params.code}.pdf"`, "Cache-Control": "public, max-age=300" } });
      },
    },
  },
});
