import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { ArrowLeft, ArrowUpRight, CalendarCheck, CheckCircle2, Globe2, Mail, MapPin, Phone, ShieldCheck } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { TopicIcon } from "@/components/TopicIcon";
import { serviceDetailQueryOptions } from "@/lib/service-queries";
import { useGuide } from "@/lib/guide-context";

const costLabels = { free: "Free", reduced: "Reduced cost", paid: "Paid", varies: "Cost varies" };

export const Route = createFileRoute("/service/$slug")({
  loader: async ({ context, params }) => {
    const service = await context.queryClient.ensureQueryData(serviceDetailQueryOptions(params.slug));
    if (!service) throw notFound();
  },
  head: () => ({
    meta: [
      { title: "Local service details — Triage Lucerne" },
      { name: "description", content: "Service description, contact details, languages, costs and eligibility information for a local Lucerne offer." },
      { property: "og:title", content: "Local service details — Triage Lucerne" },
      { property: "og:description", content: "Clear information about a local support service in Lucerne." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ServiceDetailPage,
});

function ServiceDetailPage() {
  const { slug } = Route.useParams();
  const { profile } = useGuide();
  const { data: service } = useSuspenseQuery(serviceDetailQueryOptions(slug, profile.language));
  if (!service) return null;
  const contact = service.contact_details;

  return (
    <AppShell>
      <div className="mx-auto max-w-5xl animate-enter">
        <Link to="/services" className="inline-flex items-center gap-2 text-sm font-extrabold text-primary"><ArrowLeft className="h-4 w-4" />Back to all services</Link>
        <div className="mt-6 grid items-start gap-6 lg:grid-cols-[minmax(0,1.5fr)_minmax(280px,.75fr)]">
          <article className="soft-card p-6 sm:p-8">
            <span className="icon-badge"><TopicIcon category={service.categories?.slug ?? null} /></span>
            <p className="mt-5 text-xs font-extrabold uppercase tracking-wider text-primary">{service.categories?.name_i18n[profile.language] ?? service.categories?.name_i18n["en"] ?? service.categories?.name ?? "Local service"}</p>
            <h1 className="page-title mt-2">{service.name}</h1>
            <p className="mt-3 text-lg font-bold text-muted-foreground">{service.organisations.name}</p>
            <p className="mt-6 text-base leading-8 text-muted-foreground">{service.full_description ?? service.short_description}</p>
            <div className="mt-6 flex flex-wrap gap-2">
              <span className="chip bg-success-soft text-success">{costLabels[service.cost_type]}</span>
              {service.appointment_required && <span className="chip"><CalendarCheck className="h-4 w-4" />Appointment required</span>}
            </div>
            <section className="mt-8 border-t border-border pt-7">
              <h2 className="section-title">Who can use this service?</h2>
              {service.eligibility_rules.length > 0 ? <div className="mt-4 space-y-3">{service.eligibility_rules.map((rule) => <div key={`${rule.rule_type}-${rule.condition}-${rule.value}`} className="flex gap-3 rounded-xl bg-secondary p-4"><ShieldCheck className="h-5 w-5 shrink-0 text-primary" /><p className="text-sm leading-6">{rule.explanation}</p></div>)}</div> : <div className="mt-4 flex gap-3 rounded-xl bg-success-soft p-4"><CheckCircle2 className="h-5 w-5 shrink-0 text-success" /><p className="text-sm leading-6">No specific eligibility rules are listed. Contact the organisation to confirm whether the offer fits your situation.</p></div>}
              <p className="mt-4 text-xs leading-5 text-muted-foreground">Always confirm current requirements with the organisation before visiting.</p>
            </section>
          </article>

          <aside className="soft-card p-6 lg:sticky lg:top-24">
            <h2 className="section-title">Contact & next steps</h2>
            <div className="mt-5 space-y-4 text-sm">
              {(contact["address"] ?? service.organisations.address) && <p className="flex gap-3"><MapPin className="h-5 w-5 shrink-0 text-primary" /><span>{contact["address"] ?? service.organisations.address}</span></p>}
              {(contact["opening_hours"]) && <p className="flex gap-3"><CalendarCheck className="h-5 w-5 shrink-0 text-primary" /><span>{contact["opening_hours"]}</span></p>}
              {service.organisations.phone && <p className="flex gap-3"><Phone className="h-5 w-5 shrink-0 text-primary" /><a href={`tel:${service.organisations.phone}`} className="font-bold text-primary">{service.organisations.phone}</a></p>}
              {service.organisations.email && <p className="flex gap-3"><Mail className="h-5 w-5 shrink-0 text-primary" /><a href={`mailto:${service.organisations.email}`} className="font-bold text-primary">{service.organisations.email}</a></p>}
              <p className="flex gap-3"><Globe2 className="h-5 w-5 shrink-0 text-primary" /><span>{service.geographical_coverage.replaceAll("_", " ")}</span></p>
            </div>
            {(service.direct_url ?? service.organisations.website) && <a href={service.direct_url ?? service.organisations.website ?? ""} target="_blank" rel="noreferrer" className="btn-primary mt-6 w-full">Visit organisation website<ArrowUpRight className="h-4 w-4" /></a>}
            <p className="mt-5 text-xs leading-5 text-muted-foreground">Details come from the supplied directory and should be checked with the organisation.</p>
          </aside>
        </div>
      </div>
    </AppShell>
  );
}
