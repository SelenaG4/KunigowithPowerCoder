import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { ServiceDirectory } from "@/components/ServiceDirectory";
import { categoriesQueryOptions, servicesQueryOptions } from "@/lib/service-queries";

const initialSearch = { language: "en", profile: {}, onlyEligible: false, limit: 50 };

export const Route = createFileRoute("/services")({
  loader: ({ context }) => Promise.all([
    context.queryClient.ensureQueryData(categoriesQueryOptions()),
    context.queryClient.ensureQueryData(servicesQueryOptions(initialSearch)),
  ]),
  head: () => ({
    meta: [
      { title: "Search local services — Triage Lucerne" },
      { name: "description", content: "Search Lucerne services by topic, language, cost and personal eligibility, without creating an account." },
      { property: "og:title", content: "Search local services — Triage Lucerne" },
      { property: "og:description", content: "Find clear, relevant local support in Lucerne by topic and eligibility." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ServicesPage,
});

function ServicesPage() {
  return <AppShell><ServiceDirectory /></AppShell>;
}
