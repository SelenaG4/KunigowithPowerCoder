import { createFileRoute, notFound } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { AppShell } from "@/components/AppShell";
import { GuideOverview } from "@/components/GuideOverview";
import { servicesQueryOptions, sharedGuideQueryOptions } from "@/lib/service-queries";
import { filtersFromSharedGuide, toSearchProfile } from "@/lib/guide-utils";

export const Route = createFileRoute("/shared/$code")({
  loader: async ({ context, params }) => {
    const guide = await context.queryClient.ensureQueryData(sharedGuideQueryOptions(params.code));
    if (!guide) throw notFound();
    const profile = filtersFromSharedGuide(guide);
    await context.queryClient.ensureQueryData(servicesQueryOptions({ language: profile.language, profile: toSearchProfile(profile), onlyEligible: false, limit: 50 }));
  },
  head: () => ({
    meta: [
      { title: "Shared personal guide — Triage Lucerne" },
      { name: "description", content: "Open a shared Triage guide with recommended Lucerne services and practical next steps." },
      { property: "og:title", content: "A shared Triage guide for Lucerne" },
      { property: "og:description", content: "Recommended local support and next steps, shared without names or contact details." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SharedGuidePage,
});

function SharedGuidePage() {
  const { code } = Route.useParams();
  const { data: guide } = useSuspenseQuery(sharedGuideQueryOptions(code));
  if (!guide) return null;
  const profile = filtersFromSharedGuide(guide);
  const { data: services } = useSuspenseQuery(servicesQueryOptions({ language: profile.language, profile: toSearchProfile(profile), onlyEligible: false, limit: 50 }));
  return <AppShell><GuideOverview profile={profile} services={services} shareCode={guide.code} readOnly /></AppShell>;
}
