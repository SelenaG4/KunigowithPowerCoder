import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useRef, useState } from "react";
import { toast } from "sonner";
import { CheckCircle2, FileSpreadsheet, Languages, LogOut, Upload, XCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { translateMissing } from "@/lib/admin.functions";
import { Logo } from "@/components/Logo";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "Admin — update the service directory · Triage Lucerne" },
      { name: "description", content: "Upload Excel lists from partner organisations and publish new services." },
      { property: "og:title", content: "Admin — Triage Lucerne" },
      { property: "og:description", content: "Upload Excel lists and publish new services." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminPage,
});

const LANGS = ["en", "it", "fr", "es", "ar", "uk", "pt", "tr"];
const statusLabel: Record<string, string> = { ready: "Ready", needs_review: "Needs a check", approved: "Approved", duplicate: "Already listed", published: "Live", skipped: "Left out" };
type Row = { id: string; row_number: number; status: string; issues: string[]; parsed: Record<string, unknown> };

function AdminPage() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [batchId, setBatchId] = useState<string | null>(null);
  const [filter, setFilter] = useState("needs_review");
  const [publishing, setPublishing] = useState(false);
  const [progress, setProgress] = useState("");
  const translate = useServerFn(translateMissing);

  const me = useQuery({ queryKey: ["admin-me"], queryFn: async () => {
    const { data: u } = await supabase.auth.getUser();
    const { data } = await supabase.from("admin_users").select("user_id, full_name").eq("user_id", u.user?.id ?? "").maybeSingle();
    return { email: u.user?.email ?? "", isAdmin: !!data };
  } });
  const batches = useQuery({ enabled: !!me.data?.isAdmin, queryKey: ["batches"], queryFn: async () => {
    const { data } = await supabase.from("import_batches").select("id, file_name, sheet_name, status, created_at").order("created_at", { ascending: false }).limit(20);
    return data ?? [];
  } });
  const rows = useQuery({ enabled: !!batchId, queryKey: ["rows", batchId], queryFn: async () => {
    const { data } = await supabase.from("import_rows").select("id, row_number, status, issues, parsed").eq("batch_id", batchId!).not("status", "in", "(section,note)").order("row_number");
    return (data ?? []) as unknown as Row[];
  } });

  const signOut = async () => { await qc.cancelQueries(); qc.clear(); await supabase.auth.signOut(); navigate({ to: "/auth", search: { redirect: "/admin" }, replace: true }); };

  const upload = async (file: File) => {
    setUploading(true);
    try {
      const XLSX = await import("xlsx");
      const wb = XLSX.read(await file.arrayBuffer());
      let first: string | null = null; let staged = 0;
      for (const name of wb.SheetNames) {
        const ws = wb.Sheets[name]; if (!ws) continue;
        const data = XLSX.utils.sheet_to_json<string[]>(ws, { header: 1, defval: "", raw: false }).map((r) => r.map((c) => String(c ?? "")));
        if (data.filter((r) => r.some((c) => c.trim())).length < 2) continue;
        const { data: id, error } = await supabase.rpc("import_stage_sheet", { p_file_name: file.name, p_sheet_name: name, p_rows: data });
        if (error) { toast.error(`Sheet "${name}": ${error.message.includes("header") ? "no column names found (e.g. Name, Kontakt, Website)" : error.message}`); continue; }
        first ??= id as string; staged++;
      }
      if (staged) { toast.success(`${staged} ${staged === 1 ? "sheet" : "sheets"} read. Please check the rows below.`); setBatchId(first); setFilter("needs_review"); }
      await qc.invalidateQueries({ queryKey: ["batches"] });
    } catch { toast.error("This file could not be read. Please upload an Excel (.xlsx) file."); }
    finally { setUploading(false); if (fileRef.current) fileRef.current.value = ""; }
  };

  const setStatus = async (ids: string[], status: "approved" | "skipped") => {
    const { error } = await supabase.from("import_rows").update({ status }).in("id", ids);
    if (error) toast.error("Could not save the change."); else await qc.invalidateQueries({ queryKey: ["rows", batchId] });
  };

  const publish = async () => {
    if (!batchId) return;
    setPublishing(true);
    try {
      const { data, error } = await supabase.rpc("import_publish_batch", { p_batch_id: batchId, p_activate: true });
      if (error) throw error;
      const created = (data as { services_created?: number } | null)?.services_created ?? 0;
      toast.success(`${created} new ${created === 1 ? "service is" : "services are"} now live on the website.`);
      await qc.invalidateQueries();
      for (const language of LANGS) {
        let remaining = 1;
        while (remaining > 0) {
          setProgress(`Translating into ${language.toUpperCase()}…`);
          const r = await translate({ data: { language } });
          remaining = r.translated ? r.remaining : 0;
        }
      }
      setProgress(""); toast.success("Translations are up to date in every language.");
    } catch (e) { setProgress(""); toast.error(e instanceof Error ? e.message : "Publishing failed."); }
    finally { setPublishing(false); }
  };

  if (me.isLoading) return <div className="p-10 text-center text-muted-foreground">Loading…</div>;
  if (!me.data?.isAdmin) return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4"><div className="soft-card max-w-md p-8 text-center">
      <h1 className="font-display text-2xl font-extrabold">No admin access</h1>
      <p className="mt-2 text-sm text-muted-foreground">{me.data?.email} is signed in but is not an administrator. Ask an existing administrator to give you access.</p>
      <button type="button" className="btn-secondary mt-6" onClick={signOut}><LogOut className="h-4 w-4" />Sign out</button>
    </div></div>
  );

  const list = rows.data ?? [];
  const counts = list.reduce<Record<string, number>>((a, r) => { a[r.status] = (a[r.status] ?? 0) + 1; return a; }, {});
  const shown = list.filter((r) => r.status === filter);
  const publishable = (counts["ready"] ?? 0) + (counts["approved"] ?? 0);

  return (
    <div className="min-h-screen bg-background">
      <header className="flex items-center justify-between border-b border-border bg-card px-4 py-3 sm:px-8">
        <Link to="/"><Logo compact /></Link>
        <div className="flex items-center gap-3"><span className="hidden text-sm text-muted-foreground sm:inline">{me.data.email}</span><button type="button" className="btn-secondary" onClick={signOut}><LogOut className="h-4 w-4" />Sign out</button></div>
      </header>
      <main className="mx-auto max-w-6xl px-4 py-8 sm:px-8">
        <p className="text-xs font-extrabold uppercase tracking-[0.18em] text-primary">Admin</p>
        <h1 className="page-title mt-2">Update the service directory</h1>
        <p className="mt-3 max-w-2xl text-muted-foreground">Upload an Excel list from a partner organisation. Check the rows, then publish — new services appear on the website and are translated automatically.</p>

        <section className="soft-card mt-6 p-6">
          <h2 className="section-title">1. Upload an Excel file</h2>
          <label className={cn("mt-4 flex cursor-pointer flex-col items-center justify-center gap-3 rounded-2xl border-2 border-dashed border-border p-10 text-center hover:border-primary", uploading && "opacity-60")}
            onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); const f = e.dataTransfer.files[0]; if (f) void upload(f); }}>
            <Upload className="h-8 w-8 text-primary" />
            <span className="font-bold">{uploading ? "Reading the file…" : "Drop an .xlsx file here or click to choose"}</span>
            <span className="text-xs text-muted-foreground">Every sheet is read. Columns like Name, Angebot, Kontakt, Website, Telefon are recognised.</span>
            <input ref={fileRef} type="file" accept=".xlsx,.xls" className="sr-only" disabled={uploading} onChange={(e) => { const f = e.target.files?.[0]; if (f) void upload(f); }} />
          </label>
        </section>

        <section className="soft-card mt-6 p-6">
          <h2 className="section-title">2. Choose an upload to check</h2>
          <div className="mt-4 grid gap-2">
            {(batches.data ?? []).length === 0 && <p className="text-sm text-muted-foreground">No uploads yet.</p>}
            {(batches.data ?? []).map((b) => (
              <button key={b.id} type="button" onClick={() => { setBatchId(b.id); setFilter("needs_review"); }} className={cn("flex items-center justify-between gap-3 rounded-xl border p-3 text-left", batchId === b.id ? "border-primary bg-secondary" : "border-border")}>
                <span className="flex items-center gap-3"><FileSpreadsheet className="h-5 w-5 text-primary" /><span><span className="block text-sm font-bold">{b.file_name}{b.sheet_name ? ` — ${b.sheet_name}` : ""}</span><span className="text-xs text-muted-foreground">{new Date(b.created_at).toLocaleString()}</span></span></span>
                <span className="chip">{b.status === "published" ? "Published" : b.status === "partly_published" ? "Partly published" : "Waiting"}</span>
              </button>
            ))}
          </div>
        </section>

        {batchId && (
          <section className="soft-card mt-6 p-6">
            <h2 className="section-title">3. Check the rows</h2>
            <div className="mt-4 flex flex-wrap gap-2">
              {["needs_review", "ready", "approved", "duplicate", "skipped", "published"].map((s) => (
                <button key={s} type="button" onClick={() => setFilter(s)} className={cn("chip min-h-10 px-4", filter === s && "bg-primary text-primary-foreground")}>{statusLabel[s]} ({counts[s] ?? 0})</button>
              ))}
            </div>
            {filter === "needs_review" && shown.length > 0 && <button type="button" className="btn-secondary mt-4" onClick={() => setStatus(shown.map((r) => r.id), "approved")}><CheckCircle2 className="h-4 w-4" />Approve all {shown.length}</button>}
            <div className="mt-4 divide-y divide-border rounded-xl border border-border">
              {rows.isLoading && <p className="p-4 text-sm text-muted-foreground">Loading rows…</p>}
              {!rows.isLoading && shown.length === 0 && <p className="p-4 text-sm text-muted-foreground">Nothing in this group.</p>}
              {shown.map((r) => (
                <div key={r.id} className="flex flex-col gap-3 p-4 sm:flex-row sm:items-start sm:justify-between">
                  <div className="min-w-0">
                    <p className="font-bold">{String(r.parsed["service_name"] ?? r.parsed["organisation_name"] ?? `Row ${r.row_number}`)}</p>
                    <p className="text-xs text-muted-foreground">{String(r.parsed["organisation_name"] ?? "")} · row {r.row_number}{r.parsed["website"] ? ` · ${String(r.parsed["website"])}` : ""}</p>
                    {r.issues.length > 0 && <ul className="mt-2 list-disc pl-5 text-xs text-warning">{r.issues.map((i) => <li key={i}>{i}</li>)}</ul>}
                  </div>
                  {(r.status === "needs_review" || r.status === "ready" || r.status === "skipped" || r.status === "approved") && (
                    <div className="flex shrink-0 gap-2">
                      {r.status !== "approved" && r.status !== "ready" && <button type="button" className="btn-secondary" onClick={() => setStatus([r.id], "approved")}><CheckCircle2 className="h-4 w-4" />Approve</button>}
                      {r.status !== "skipped" && <button type="button" className="btn-secondary" onClick={() => setStatus([r.id], "skipped")}><XCircle className="h-4 w-4" />Leave out</button>}
                    </div>
                  )}
                </div>
              ))}
            </div>
            <div className="mt-6 flex flex-col gap-3 rounded-2xl bg-secondary p-4 sm:flex-row sm:items-center sm:justify-between">
              <p className="text-sm font-bold">{publishable} {publishable === 1 ? "row is" : "rows are"} ready to go live.{progress && <span className="ml-2 inline-flex items-center gap-1 text-primary"><Languages className="h-4 w-4" />{progress}</span>}</p>
              <button type="button" className="btn-primary min-h-12 px-6" disabled={publishing || publishable === 0} onClick={publish}>{publishing ? "Publishing…" : "4. Publish to the website"}</button>
            </div>
          </section>
        )}
      </main>
    </div>
  );
}
