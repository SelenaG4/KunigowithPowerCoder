import { useState, type FormEvent, type ReactNode } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useSuspenseQuery } from "@tanstack/react-query";
import { ArrowLeft, CheckCircle2, Send } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { categoriesQueryOptions } from "@/lib/service-queries";
import { submitService } from "@/lib/services.functions";
import { LANGUAGES } from "@/lib/guide-types";
import { cn } from "@/lib/utils";

const initialForm = {
  organisationName: "", serviceName: "", description: "", categoryId: "",
  website: "", contact: "", eligibilityNotes: "", languages: ["de"] as string[], submitterNote: "",
};

export const Route = createFileRoute("/submit")({
  loader: ({ context }) => context.queryClient.ensureQueryData(categoriesQueryOptions()),
  head: () => ({
    meta: [
      { title: "Suggest a local service — Triage Lucerne" },
      { name: "description", content: "Suggest a Lucerne support service for community review without creating an account." },
      { property: "og:title", content: "Suggest a service for Triage Lucerne" },
      { property: "og:description", content: "Help keep the shared Lucerne service directory useful and current." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SubmitPage,
});

function SubmitPage() {
  const { data: categories } = useSuspenseQuery(categoriesQueryOptions());
  const [form, setForm] = useState(initialForm);
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const submit = useServerFn(submitService);
  const set = (key: keyof typeof initialForm, value: string | string[]) => setForm((current) => ({ ...current, [key]: value }));

  const onSubmit = async (event: FormEvent) => {
    event.preventDefault();
    if (!form.organisationName.trim() || !form.serviceName.trim()) {
      toast.error("Enter the organisation and service name");
      return;
    }
    setSending(true);
    try {
      await submit({ data: {
        organisationName: form.organisationName,
        serviceName: form.serviceName,
        description: form.description,
        categoryId: form.categoryId || null,
        website: form.website,
        contact: form.contact,
        eligibilityNotes: form.eligibilityNotes,
        languages: form.languages,
        submitterNote: form.submitterNote,
      } });
      setSent(true);
      setForm(initialForm);
      toast.success("Thank you — your suggestion was sent for review");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Your suggestion could not be sent");
    } finally {
      setSending(false);
    }
  };

  return (
    <AppShell>
      <div className="mx-auto max-w-3xl animate-enter">
        <Link to="/info" className="inline-flex items-center gap-2 text-sm font-extrabold text-primary"><ArrowLeft className="h-4 w-4" />Back to information</Link>
        <h1 className="page-title mt-6">Suggest a service</h1>
        <p className="mt-3 leading-7 text-muted-foreground">Share what you know about a helpful local offer. You do not need to leave your name or email address.</p>
        {sent && <div className="mt-5 flex gap-3 rounded-2xl bg-success-soft p-4"><CheckCircle2 className="h-6 w-6 shrink-0 text-success" /><div><p className="font-extrabold text-success">Suggestion received</p><p className="mt-1 text-sm text-muted-foreground">It will be reviewed before anything is published.</p></div></div>}
        <form className="soft-card mt-7 space-y-5 p-5 sm:p-7" onSubmit={(event) => void onSubmit(event)}>
          <div className="grid gap-5 sm:grid-cols-2">
            <Field label="Organisation name *"><input className="form-input" required maxLength={160} value={form.organisationName} onChange={(event) => set("organisationName", event.target.value)} placeholder="e.g. Caritas Luzern" /></Field>
            <Field label="Service name *"><input className="form-input" required maxLength={160} value={form.serviceName} onChange={(event) => set("serviceName", event.target.value)} placeholder="e.g. Housing advice" /></Field>
          </div>
          <Field label="What does the service offer?"><textarea className="form-input min-h-28 resize-y" maxLength={2000} value={form.description} onChange={(event) => set("description", event.target.value)} placeholder="Describe it in simple language." /></Field>
          <div className="grid gap-5 sm:grid-cols-2">
            <Field label="Topic"><select className="form-input" value={form.categoryId} onChange={(event) => set("categoryId", event.target.value)}><option value="">Choose a topic</option>{categories.map((category) => <option key={category.id} value={category.id}>{category.name_i18n["en"] ?? category.name}</option>)}</select></Field>
            <Field label="Website"><input type="url" className="form-input" maxLength={500} value={form.website} onChange={(event) => set("website", event.target.value)} placeholder="https://…" /></Field>
          </div>
          <Field label="Public contact or opening hours"><textarea className="form-input min-h-24 resize-y" maxLength={500} value={form.contact} onChange={(event) => set("contact", event.target.value)} placeholder="Phone, public email, address or opening hours (optional)" /></Field>
          <Field label="Who can use it?"><textarea className="form-input min-h-24 resize-y" maxLength={1500} value={form.eligibilityNotes} onChange={(event) => set("eligibilityNotes", event.target.value)} placeholder="Residence, permit, age, cost or other requirements" /></Field>
          <fieldset><legend className="form-label">Available languages</legend><div className="flex flex-wrap gap-2">{LANGUAGES.map((language) => {
            const selected = form.languages.includes(language.code);
            return <button key={language.code} type="button" className={cn("chip min-h-10 px-4", selected && "bg-primary text-primary-foreground")} aria-pressed={selected} onClick={() => set("languages", selected ? form.languages.filter((item) => item !== language.code) : [...form.languages, language.code])}>{language.flag} {language.label}</button>;
          })}</div></fieldset>
          <Field label="Note for the review team"><textarea className="form-input min-h-20 resize-y" maxLength={1000} value={form.submitterNote} onChange={(event) => set("submitterNote", event.target.value)} placeholder="Anything that will help us verify this suggestion (optional)" /></Field>
          <div className="flex flex-col gap-4 border-t border-border pt-5 sm:flex-row sm:items-center sm:justify-between"><p className="text-xs leading-5 text-muted-foreground">Submissions are not public until reviewed.</p><button type="submit" className="btn-primary" disabled={sending}><Send className="h-4 w-4" />{sending ? "Sending…" : "Send for review"}</button></div>
        </form>
      </div>
    </AppShell>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return <label className="block"><span className="form-label">{label}</span>{children}</label>;
}
